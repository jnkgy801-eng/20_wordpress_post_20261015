# -*- coding: utf-8 -*-
"""
📝 FANZA同人 → WordPress 記事自動生成・下書き投稿ツール

DMMアフィリエイトAPI(v3)で同人作品情報を取得し、作品ごとに
記事（1作品=1記事）を生成して、WordPress REST APIへ
「下書き（draft）」として投稿します。
--------------------------------------------------------------
"""

import os
import random
import re
import sys
import urllib.parse

# ================================================================
# 📌 スクリプトバージョン（デプロイ確認用）
#    「投稿によって結果が違う」といった不整合が起きた際、
#    どのバージョンのコードで生成された投稿かを確認できるようにする。
#    コードを修正するたびに、この日付/番号を更新すること。
# ================================================================
SCRIPT_VERSION = '2026-10-08-06'
import json
import datetime
JST = datetime.timezone(datetime.timedelta(hours=9))
import requests
from pathlib import Path
from xml.sax.saxutils import escape

from age_safety_filter import is_safe
from indexnow import submit_url
import quality_gate

# ================================================================
# ⚙️ 設定（環境変数から読み込み）
# ================================================================

# ----------------------------------------------------------------
# 🔀 取得元の切り替え（dmm / duga / mgs / sokmil）
# ----------------------------------------------------------------
SOURCE = os.environ.get('SOURCE', 'dmm').strip().lower()
if SOURCE not in ('dmm', 'duga', 'mgs', 'sokmil'):
    print(f'⚠️ SOURCE="{SOURCE}" は不明な値です。dmm にフォールバックします。')
    SOURCE = 'dmm'
print(f'🔀 取得元: {SOURCE}')

DUGA_SORT = os.environ.get('DUGA_SORT', 'new').strip()  # new/favorite/release/price/rating/mylist
MGS_SLEEP_SECONDS = float(os.environ.get('MGS_SLEEP_SECONDS', '1.0'))
SOKMIL_SORT = os.environ.get('SOKMIL_SORT', 'date').strip()

DMM_API_ID       = os.environ.get('DMM_API_ID', '')
DMM_AFFILIATE_ID = os.environ.get('DMM_AFFILIATE_ID', '')

WP_URL           = os.environ.get('WP_URL', '').rstrip('/')      # 例: https://example.com
WP_USERNAME      = os.environ.get('WP_USERNAME', '')             # WordPressのログインユーザー名
WP_APP_PASSWORD  = os.environ.get('WP_APP_PASSWORD', '')         # アプリケーションパスワード（通常のログインパスワードとは別物）

# 投稿ステータス。draft（下書き）/ pending（承認待ち）/ publish（本公開）から選択。
# publishを選ぶと人間の目視確認なしにそのままサイトに公開されるため、
# 記事内容・画像・年齢確認フィルターの精度に十分自信がある場合のみ使用してください。
WP_POST_STATUS   = os.environ.get('WP_POST_STATUS', 'draft').lower()

GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', '')
GEMINI_MODEL   = os.environ.get('GEMINI_MODEL', 'gemini-3.5-flash')

# SEOタイトル／メタディスクリプションの冒頭にフォーカスキーフレーズ（出演者名・
# ジャンル名等）を挿入するかどうか。true（デフォルト）なら従来どおり挿入する。
# false にすると、SEOタイトルは作品タイトルそのまま、メタディスクリプションは
# 作品の説明文（AI生成OVERVIEWの冒頭）のみになり、キーフレーズは一切含まれない。
SEO_INCLUDE_KEYPHRASE = os.environ.get('SEO_INCLUDE_KEYPHRASE', 'true').strip().lower() not in ('false', '0', 'no')

if SOURCE == 'dmm' and (not DMM_API_ID or not DMM_AFFILIATE_ID):
    print('❌ 環境変数 DMM_API_ID / DMM_AFFILIATE_ID が設定されていません。')
    sys.exit(1)

if not WP_URL or not WP_USERNAME or not WP_APP_PASSWORD:
    print('❌ 環境変数 WP_URL / WP_USERNAME / WP_APP_PASSWORD が設定されていません。')
    sys.exit(1)

if WP_POST_STATUS not in ('draft', 'pending', 'publish'):
    print(f'⚠️ WP_POST_STATUS="{WP_POST_STATUS}" は不明な値です。'
          f' draft / pending / publish のいずれかを指定してください。draft にフォールバックします。')
    WP_POST_STATUS = 'draft'

print('✅ 認証情報を読み込みました。')
if WP_POST_STATUS == 'publish':
    print('🚨 投稿ステータス: publish（本公開）が指定されています。'
          '生成された記事は目視確認なしにそのままサイトへ公開されます。')
else:
    print(f'📌 投稿ステータス: {WP_POST_STATUS}（公開は必ず手動で行ってください）')

DMM_API_BASE = 'https://api.dmm.com/affiliate/v3'

# コンテンツ種別（同人 / AV）を選択。CONTENT_TYPE環境変数で切り替え可能。
#   doujin : FANZA同人（デフォルト）
#   av     : FANZA動画（アダルトビデオ）
CONTENT_TYPE = os.environ.get('CONTENT_TYPE', 'doujin').strip().lower()
_CONTENT_TYPE_TARGETS = {
    'doujin': {'service': 'doujin', 'floor': 'digital_doujin', 'label': 'FANZA同人'},
    'av':     {'service': 'digital', 'floor': 'videoa', 'label': 'FANZA動画'},
}
if CONTENT_TYPE not in _CONTENT_TYPE_TARGETS:
    print(f'⚠️ CONTENT_TYPE="{CONTENT_TYPE}" は不明な値です。doujin にフォールバックします。')
    CONTENT_TYPE = 'doujin'
SERVICE       = _CONTENT_TYPE_TARGETS[CONTENT_TYPE]['service']
FLOOR         = _CONTENT_TYPE_TARGETS[CONTENT_TYPE]['floor']
CONTENT_LABEL = _CONTENT_TYPE_TARGETS[CONTENT_TYPE]['label']
print(f'🏷️ スクリプトバージョン: {SCRIPT_VERSION}')
print(f'📌 コンテンツ種別: {CONTENT_LABEL}（service={SERVICE}, floor={FLOOR}）')

RANK_FETCH_LIMIT = int(os.environ.get('RANK_FETCH_LIMIT', '500'))
DATE_WINDOW_DAYS = int(os.environ.get('DATE_WINDOW_DAYS', '14'))

# DMM APIへ渡すsortパラメータ。rank（人気順）/ date（新着順）から選択。
DMM_SORT_MODE = os.environ.get('DMM_SORT_MODE', 'rank').strip().lower()
if DMM_SORT_MODE not in ('rank', 'date'):
    print(f'⚠️ DMM_SORT_MODE="{DMM_SORT_MODE}" は不明な値です。rank にフォールバックします。')
    DMM_SORT_MODE = 'rank'
_SORT_LABEL = {'rank': '人気順', 'date': '新着順'}[DMM_SORT_MODE]

print(f'📌 {_SORT_LABEL}（sort={DMM_SORT_MODE}）で上位{RANK_FETCH_LIMIT}件を取得し、'
      f'発売日/配信日が実行日時より過去（今日から過去{DATE_WINDOW_DAYS}日以内）の作品のみ投稿対象にします。')

# 価格フィルタ（円）。未設定なら制限なし。price_numが取得できない商品は対象外にはしない。
def _parse_price_env(name: str):
    raw = os.environ.get(name, '').strip()
    if raw.isdigit():
        return int(raw)
    return None

PRICE_MIN = _parse_price_env('PRICE_MIN')
PRICE_MAX = _parse_price_env('PRICE_MAX')
if PRICE_MIN is not None or PRICE_MAX is not None:
    print(f'📌 価格フィルタ: {PRICE_MIN if PRICE_MIN is not None else "指定なし"}円 〜 '
          f'{PRICE_MAX if PRICE_MAX is not None else "指定なし"}円')

# AVでVRコンテンツを除外するかどうか。デフォルトは除外（True）。
# EXCLUDE_VR=false を指定すれば無効化できる（doujinの場合は元々関係なし）。
EXCLUDE_VR = os.environ.get('EXCLUDE_VR', 'true').strip().lower() not in ('false', '0', 'no')
if CONTENT_TYPE == 'av':
    print(f'📌 VR作品の除外: {"する" if EXCLUDE_VR else "しない"}')


def _is_vr_product(product: dict) -> bool:
    """ジャンル名・タイトルにVRを示すキーワードが含まれる作品かどうかを判定する。"""
    vr_keywords = ('VR', 'ＶＲ')
    for genre in product.get('genres', []) or []:
        if any(kw in genre for kw in vr_keywords):
            return True
    title = product.get('title', '') or ''
    if any(kw in title for kw in vr_keywords):
        return True
    return False


FETCH_COUNT = int(os.environ.get('FETCH_COUNT', '100'))
MAX_ARTICLES = int(os.environ.get('MAX_ARTICLES', '5'))  # 1回の実行で投稿する記事数の上限

# 投稿済み作品の重複防止用履歴ファイル
POSTED_HISTORY_FILE = Path(os.environ.get('POSTED_HISTORY_FILE', 'outputs/posted_history.json'))

# ================================================================
# 🗂️ 投稿履歴管理（重複投稿防止）
# ================================================================

def load_posted_history() -> dict:
    """投稿済みID集合（'posted'）に加えて、直近記事の書き出し冒頭リスト
    （'recent_openings'）も一緒に読み込む。後者はAIへの自己模倣防止プロンプトに使う。"""
    if not POSTED_HISTORY_FILE.exists():
        return {'posted': set(), 'recent_openings': []}
    try:
        with open(POSTED_HISTORY_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return {
            'posted': set(data.get('posted', [])),
            'recent_openings': list(data.get('recent_openings', [])),
        }
    except Exception as e:
        print(f'⚠️ 投稿履歴の読み込みに失敗しました（新規履歴として扱います）: {e}')
        return {'posted': set(), 'recent_openings': []}


def save_posted_history(posted: set, recent_openings: list = None) -> None:
    POSTED_HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(POSTED_HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(
                {
                    'posted': sorted(posted),
                    'recent_openings': (recent_openings or [])[-_RECENT_OPENINGS_KEEP:],
                },
                f, ensure_ascii=False, indent=2,
            )
    except Exception as e:
        print(f'⚠️ 投稿履歴の保存に失敗しました: {e}')


def product_history_key(product: dict) -> str:
    return product.get('content_id') or f"title:{product.get('title', '')}"


# 直近何件分の「書き出し冒頭」を履歴として保持し、AIへの
# 自己模倣防止プロンプトに使うか。多すぎるとプロンプトが長くなるため8件程度に留める。
_RECENT_OPENINGS_KEEP = 8


def _stable_variant_index(key: str, salt: str, mod: int) -> int:
    """content_id等のキーと軸ごとのsaltから、実行のたびに変わらない安定した
    バリエーション番号（0〜mod-1）を算出する。
    同じ作品は常に同じ番号になるが、salt（'structure'/'heading'/'appeal'等）を
    変えることで、構成順・見出し・訴求パターンといった各軸を互いに独立して
    ばらつかせることができる（全軸が常に同じ組み合わせになるのを防ぐ）。"""
    if not key or mod <= 1:
        return 0
    combined = f'{key}::{salt}'
    return sum(ord(c) for c in combined) % mod


# ================================================================
# 🔧 DMM API 関連（既存スクリプトと同じロジックを踏襲）
# ================================================================

def fetch_dmm_products(offset: int, sort: str = None, hits: int = None,
                        gte_date: str = None, lte_date: str = None):
    params = {
        'api_id':       DMM_API_ID,
        'affiliate_id': DMM_AFFILIATE_ID,
        'site':         'FANZA',
        'service':      SERVICE,
        'floor':        FLOOR,
        'hits':         hits or FETCH_COUNT,
        'offset':       offset,
        'sort':         sort or 'rank',
        'output':       'json',
    }
    # 発売日/配信日の範囲をDMM API側で絞り込む（未来の予約作品を最初から除外するため）。
    # 形式は 'YYYY-MM-DDTHH:MM:SS'。
    if gte_date:
        params['gte_date'] = gte_date
    if lte_date:
        params['lte_date'] = lte_date
    try:
        resp = requests.get(f'{DMM_API_BASE}/ItemList', params=params, timeout=15)
        data = resp.json()
        items = data.get('result', {}).get('items', [])
        if isinstance(items, dict):
            items = items.get('item', [])
        print(f'✅ DMM APIから {len(items)} 件取得しました（offset={offset}）。')
        return items
    except Exception as e:
        print(f'❌ DMM APIエラー（offset={offset}）: {e}')
        return []


_TITLE_PREFIX_RE = re.compile(r'^【[^】]{1,20}】\s*')


def fetch_rank_items(limit: int, sort: str = None,
                      gte_date: str = None, lte_date: str = None) -> list:
    """指定sort順（rank=人気順 / date=新着順）・指定日付範囲内の上位limit件の
    生アイテム（dict）をリストで返す。"""
    sort = sort or DMM_SORT_MODE
    items_out = []
    offset = 1
    while len(items_out) < limit:
        items = fetch_dmm_products(offset, sort=sort, gte_date=gte_date, lte_date=lte_date)
        if not items:
            break
        items_out.extend(items)
        offset += FETCH_COUNT
    return items_out[:limit]


def _strip_redundant_title_prefix(title: str) -> str:
    """DMMの商品タイトルは【ハイビジョン・独占配信・巨乳】のような接頭辞の直後に、
    同じキーワードを読点区切りでそのまま繰り返す形式が多い。
    一覧表示で全作品のタイトルが同じ書き出しに見えてしまう原因になるため、
    この冒頭の【...】タグ部分だけを取り除く（ジャンル情報はバッジ/カテゴリーで別途表示されるため
    情報は失われない）。"""
    if not title:
        return title
    return _TITLE_PREFIX_RE.sub('', title, count=1).strip()


def _build_affiliate_url(raw_url: str) -> str:
    """DMM APIのレスポンスに 'affiliateURL' が含まれない商品（同人カテゴリ等で
    まれに発生）向けに、計測付きの正しいアフィリエイトリンク（al.dmm.co.jp形式）を
    自前で組み立てる。
    ここを経由しないと、'URL' フィールド（utm_*パラメータ付きだが
    アフィリエイト計測は乗っていない生リンク）がそのまま使われてしまい、
    クリックされても報酬が一切発生しない、という不具合になる。
    """
    if not raw_url:
        return ''
    # utm_* パラメータ（アフィリエイト計測とは無関係）は取り除いてからlurlに使う
    parsed = urllib.parse.urlsplit(raw_url)
    clean_query = '&'.join(
        kv for kv in parsed.query.split('&')
        if kv and not kv.startswith('utm_')
    )
    clean_url = urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, parsed.path, clean_query, '')
    )
    encoded = urllib.parse.quote(clean_url, safe='')
    return f'https://al.dmm.co.jp/?lurl={encoded}&af_id={DMM_AFFILIATE_ID}&ch=api&ch_id=link'


def _resolve_affiliate_url(item: dict) -> str:
    """DMM APIが返す 'affiliateURL' を、そのまま信用せずに検証する。

    同人カテゴリ等: 'affiliateURL' が空で返ってくることがある。
    AV(video.dmm.co.jp)等: 'affiliateURL' が空ではないが、中身が
        utm_*パラメータだけの計測なしURL（al.dmm.co.jpを経由していない）
        のまま返ってくることがある。
    どちらの場合も、クリックされてもアフィリエイト報酬が発生しない生リンクに
    なってしまうため、'al.dmm.co.jp' を経由した正しい形式でなければ、
    自前で組み立て直す。
    """
    raw_affiliate = item.get('affiliateURL', '')
    # DMM APIは商品によって、正しい計測付きリンクを 'al.dmm.co.jp' ではなく
    # 'al.fanza.co.jp' というドメインで返してくることがある。
    # ここを見落とすと、すでに正しいリンクをもう一度 al.dmm.co.jp で
    # 二重に包んでしまい（lurlの中にlurlが入れ子になる）、404の原因になる。
    if raw_affiliate and ('al.dmm.co.jp' in raw_affiliate or 'al.fanza.co.jp' in raw_affiliate):
        return raw_affiliate
    # affiliateURLが空、または計測なしの生リンクだった場合は、
    # 手元にあるURL（affiliateURLかURLフィールド）から正しい形式を組み立て直す
    fallback_source = raw_affiliate or item.get('URL', '')
    return _build_affiliate_url(fallback_source)


def _parse_volume_minutes(raw):
    """DMM APIのvolume（収録時間）を分(int)にして返す。取れなければ0。
    '120' / '120分' / '02:00:00' のどの形式でも対応する。"""
    s = str(raw or '').strip()
    if not s:
        return 0
    if ':' in s:
        parts = [p for p in s.split(':') if p.isdigit()]
        try:
            nums = [int(p) for p in parts]
        except ValueError:
            return 0
        if len(nums) == 3:
            return nums[0] * 60 + nums[1]
        if len(nums) == 2:
            return nums[0]
        return 0
    digits = ''.join(c for c in s if c.isdigit())
    return int(digits) if digits else 0


def parse_product(item):
    content_id    = item.get('content_id', '') or item.get('product_id', '')
    title         = _strip_redundant_title_prefix(item.get('title', ''))
    affiliate_url = _resolve_affiliate_url(item)
    prices        = item.get('prices', {})
    price_str, price_num = '', None
    if prices:
        price_val = prices.get('price') or prices.get('list_price') or ''
        if price_val:
            digits = ''.join(c for c in str(price_val) if c.isdigit())
            if digits:
                price_num = int(digits)
                price_str = f'¥{price_num:,}'

    iteminfo = item.get('iteminfo', {}) or {}
    # ジャンルは[:5]で切り捨てず全件保持する（プロンプト側で作品の差別化に使うため）
    genres   = [g.get('name', '') for g in (iteminfo.get('genre') or [])]
    maker    = ((iteminfo.get('maker') or [{}])[0]).get('name', '')
    actors   = [a.get('name', '') for a in (iteminfo.get('actress') or []) if a.get('name')][:3]

    # 作品固有の差別化情報（シリーズ・レーベル・監督）。
    # 存在しない作品も多いため、無ければ空文字にフォールバックする。
    series   = ((iteminfo.get('series') or [{}])[0]).get('name', '')
    label    = ((iteminfo.get('label') or [{}])[0]).get('name', '')
    director = ((iteminfo.get('director') or [{}])[0]).get('name', '')

    # サンプル動画URL（記事に埋め込み用）。取得できるサイズを優先度順に探す。
    sample_movie_url = ''
    movie_block = item.get('sampleMovieURL', {}) or {}
    for key in ('size_720_480', 'size_644_414', 'size_560_360', 'size_476_306'):
        if movie_block.get(key):
            sample_movie_url = movie_block[key]
            break

    review_info = item.get('review', {}) or {}
    try:
        review_avg   = float(review_info.get('average', 0) or 0)
        review_count = int(review_info.get('count', 0) or 0)
    except (ValueError, TypeError):
        review_avg, review_count = 0.0, 0
    review_avg   = round(review_avg, 2) if review_avg else None
    review_count = review_count if review_count else None

    img = item.get('imageURL', {}) or {}
    package_image = img.get('large') or img.get('small') or ''

    sample_images = []
    sample_url_block = item.get('sampleImageURL', {}) or {}
    for key in ('sample_l', 'sample_s'):
        block = sample_url_block.get(key) or {}
        images = block.get('image') or []
        if isinstance(images, str):
            images = [images]
        if images:
            sample_images = [u for u in images if u]
            break

    return {
        'content_id':    content_id,
        'title':         title,
        'affiliate_url': affiliate_url,
        'price':         price_str,
        'price_num':     price_num,
        'genres':        genres,
        'maker':         maker,
        'actors':        actors,
        'review_avg':    review_avg,
        'review_count':  review_count,
        'package_image': package_image,
        'sample_images': sample_images,
        'sample_movie_url': sample_movie_url,
        'series':        series,
        'label':         label,
        'director':      director,
        'date':          item.get('date', ''),
        'volume':        _parse_volume_minutes(item.get('volume')),
        # DMM APIは作品の紹介文を返さない。空のままにして、記事生成を「内容を想像で書かない」モードにする
        'real_summary':  '',
    }


# ================================================================
# 📝 記事本文生成（元スクリプトと同じロジック）
# ================================================================

def get_article_body_ai(product: dict, focus_keyphrase: str = '', appeal_pattern: dict = None,
                         length_variant: dict = None, opening_pattern: dict = None,
                         recent_openings: list = None) -> dict:
    if GEMINI_API_KEY:
        try:
            body = _get_article_body_from_api(
                product, focus_keyphrase,
                appeal_pattern=appeal_pattern, length_variant=length_variant,
                opening_pattern=opening_pattern,
                recent_openings=recent_openings,
            )
            body['generated_by'] = 'ai'
            return body
        except Exception as e:
            print(f'    ⚠️ AI記事生成エラー（テンプレート使用）: {e}')
    else:
        # GEMINI_API_KEY未設定に気づかないままテンプレート運用が続く事故を防ぐため、
        # 実行のたびに明示的に警告を出す。
        print('    ⚠️ GEMINI_API_KEY未設定のため、テンプレート文章を使用します。')
    body = _get_article_body_template(product, focus_keyphrase, appeal_pattern=appeal_pattern)
    body['generated_by'] = 'template'
    return body


def _get_article_body_from_api(product: dict, focus_keyphrase: str = '', appeal_pattern: dict = None,
                                length_variant: dict = None, opening_pattern: dict = None,
                                recent_openings: list = None) -> dict:
    appeal_pattern = appeal_pattern or _APPEAL_PATTERNS[0]
    length_variant = length_variant or _LENGTH_VARIANTS[1]
    opening_pattern = opening_pattern or _OPENING_STYLE_VARIANTS[0]
    # 公式の紹介文（実データ）。無い場合は「内容を想像で書かない」モードにする。
    real_summary = (product.get('real_summary') or '').strip()
    if not real_summary and opening_pattern.get('name') == '情景描写から入る':
        # 作品内の場面を描写させる書き出しは、紹介文が無いと捏造になるため使わない
        opening_pattern = _OPENING_STYLE_VARIANTS[1]
    if real_summary:
        grounding_block = (
            "【公式の作品紹介文（作品内容に関する唯一の根拠）】\n"
            f"{real_summary}\n"
        )
        grounding_rules = (
            "- 作品の内容（登場人物・設定・展開・シーン）は、上の公式紹介文に書かれている事実だけを根拠にする。\n"
            "  紹介文にない設定・展開・描写・セリフを足さない\n"
            "- 紹介文の文言を長く引き写さず、読者の判断に役立つ形に言い換えて整理する\n"
        )
    else:
        grounding_block = "【公式の作品紹介文】なし（この作品の内容に関する情報は提供されていません）\n"
        grounding_rules = (
            "- この作品のストーリー・登場人物・シーン・展開を想像で書くことは禁止。内容を推測して断定する表現も禁止\n"
            "- 書いてよいのは、渡された情報（ジャンル・メーカー・シリーズ・価格・レビュー・収録時間）から言えることと、\n"
            "  そのジャンル全般の選び方の観点に限る\n"
            "- 内容が分からない点は『詳細は販売ページで確認してください』と正直に書く\n"
        )
    # ジャンルは全件使う（切り捨てない）。作品ごとの差別化に使う情報のため。
    genre_str = '・'.join(product['genres']) if product['genres'] else '不明'
    review_str = (
        f"平均{product['review_avg']}点（{product['review_count']}件のレビュー）"
        if product.get('review_avg') and product.get('review_count')
        else '不明'
    )

    # 作品固有の差別化情報（シリーズ・レーベル・監督）。無ければその旨を明記し、
    # AIが実在しない情報を捏造しないようにする。
    unique_info_lines = []
    if product.get('series'):
        unique_info_lines.append(f"シリーズ: {product['series']}")
    if product.get('label'):
        unique_info_lines.append(f"レーベル: {product['label']}")
    if product.get('director'):
        unique_info_lines.append(f"監督: {product['director']}")
    unique_info_str = '\n'.join(unique_info_lines) if unique_info_lines else '（シリーズ・レーベル情報なし）'

    keyphrase_instruction = ''
    if focus_keyphrase:
        keyphrase_instruction = (
            f"- 「{focus_keyphrase}」というキーフレーズを、OVERVIEWの最初の一文に必ず含め、\n"
            "  かつ本文（OVERVIEW+POINTS）全体でもう1回以上、自然な形で登場させる\n"
        )

    # 訴求パターン（利用シーン/ジャンル比較/作者・レーベル/読者タイプ）を作品ごとに
    # 固定でローテーションさせ、記事間で切り口が単調に揃わないようにする。
    appeal_instruction = appeal_pattern['instruction']

    # 書き出しの「型」（情景描写/問いかけ/核心の一言/対比/読者の状況、等）も
    # appeal_patternとは独立にローテーションさせ、冒頭の構文が毎回
    # 同じパターン（例:「◯◯系の作品です。」で始まる等）にならないようにする。
    opening_instruction = opening_pattern['instruction']

    # 直近の記事の書き出しパターンをAIに伝え、同じ言い回し・構文の繰り返しを避けさせる
    # （内容の使い回し防止ではなく、あくまで「書き出しの型」の重複防止が目的）。
    avoid_repetition_instruction = ''
    if recent_openings:
        sample = recent_openings[-5:]
        bullet_lines = '\n'.join(f'  - 「{op}…」' for op in sample)
        avoid_repetition_instruction = (
            "- 直近の記事は次のような書き出しで始まっています。同じ言い回し・"
            "同じ文構造の書き出しは避けてください（内容自体の使い回し防止ではなく、"
            "書き出しパターンの単調な重複を避ける目的です）:\n"
            f"{bullet_lines}\n"
        )

    prompt = (
        f"あなたは{CONTENT_LABEL}（成人向け）ジャンルを専門とする、読者の意思決定を助ける\n"
        "レビューライターです。以下の作品について、読者が『自分に合う作品かどうか』を\n"
        "具体的に判断できるような紹介記事の本文材料を作成してください。\n"
        "ゴールは読者を煽って購入させることではなく、正直で具体的な情報を提供し、\n"
        "結果として『自分に合っている』と納得した読者が自然に購入を検討できる状態を\n"
        "作ることです。\n\n"
        f"作品名: {product['title']}\n"
        f"ジャンル: {genre_str}\n"
        f"{'サークル' if CONTENT_TYPE == 'doujin' else 'メーカー/レーベル'}: {product.get('maker') or '不明'}\n"
        f"{unique_info_str}\n"
        f"{grounding_block}"
        f"価格: {product.get('price') or '不明'}\n"
        f"レビュー: {review_str}\n\n"
        "本文の書き方:\n"
        "1. この作品ならではの特徴（シリーズものならその中での位置づけ・過去作との違い、\n"
        "   レーベル/監督が分かる場合はその作風の傾向）を、憶測ではなく分かる範囲で明記する。\n"
        "   情報がない場合は無理に触れなくてよい（存在しない情報を作らない）\n"
        "2. 提供された情報の範囲で、どんな方向性の作品かを整理する（情報にない状況・関係性・展開は描写しない）\n"
        "3. 『こんな人には特に向いている』『逆にこういう好みの人には物足りないかもしれない』\n"
        "   という判断材料を両方入れる（誇大な断定は避ける）\n"
        "4. 価格情報の円額そのものはOVERVIEW本文では言及しない（別欄表示のため）\n\n"
        "条件:\n"
        f"{keyphrase_instruction}"
        f"{grounding_rules}"
        f"{appeal_instruction}"
        f"{opening_instruction}"
        f"{avoid_repetition_instruction}"
        "- 文体は親しみやすく具体的に。読者の判断を助けることを最優先する\n"
        "- 抽象的な誉め言葉（『魅力的』『必見』等）だけで終わらせず、提供された情報に基づく具体的な記述を入れる（情報にない描写は足さない）\n"
        "- 文の長さにメリハリをつける（短い一文と、情景描写の長めの文を混在させる）。\n"
        "  全ての文が同じような長さ・同じようなリズムになるのを避ける\n"
        "- 次のような『いかにもAIが書いた感のある』定型フレーズは一切使わない:\n"
        "  「気づいたら◯◯している」「見逃せない」「唯一無二」「琴線に触れる」\n"
        "  「深く考えさせられる」「非常に」「まさに」「言うまでもなく」\n"
        "- 『業界No.1』『絶対』『必ず満足』『今だけ』『期間限定』など、検証不可能な\n"
        "  断定・優良誤認・実際にはない限定性を匂わせる表現（景品表示法に抵触しうる\n"
        "  表現）は使わない\n"
        "- 未成年を想起させる表現は一切使わない（成人向け作品であることを前提にする）\n"
        "- OVERVIEWは作品タイトルを本文中で繰り返さない（タイトルは見出しに既に表示されている）\n"
        "- POINTSに価格やレビュー点数など数値情報は含めない（別欄に表示済みのため）\n"
        "- POINTSは『○○要素が中心のストーリー』のような機械的な言い回しを避け、\n"
        "  各項目で違う切り口・違う言い回しにする\n"
        "- 出力は必ず次のプレーンテキスト形式のみ。前置きや説明・Markdown記法は禁止。\n\n"
        "===OVERVIEW===\n"
        f"({length_variant['paragraphs']}で、上記の書き方に沿って段落間は空行で区切る)\n"
        "===POINTS===\n"
        f"(「ここがポイント」として{length_variant['points_count']}、1行1項目、先頭に「- 」を付ける。各項目は60〜100文字程度で)\n"
    )

    # Gemini API呼び出し（課金設定をしない限り無料枠で利用可能）
    # 成人向け作品の紹介文であるため、性的表現に関する安全フィルタの閾値を
    # 緩めておく（デフォルトのままだと、正当な業務利用でも出力がブロックされ
    # 空文字やフォーマット崩れの応答になりやすい）。
    #
    # 「現在混雑しています」等の一時的なエラー（500/502/503/504）は、
    # 数秒待てば解消することが多いため、即フォールバックせず軽くリトライする。
    # 一方、429（RESOURCE_EXHAUSTED＝無料枠/レート上限に到達）は、数秒待っても
    # 解消しない（多くは日次/分次のクォータが回復するまで直らない）ため、
    # リトライしても無駄であり、原因をログで明示した上で即座にテンプレートへ
    # フォールバックする。
    import time as _time
    _RETRYABLE_STATUS_CODES = (500, 502, 503, 504)
    _MAX_RETRIES = 2
    resp = None
    for _attempt in range(_MAX_RETRIES + 1):
        resp = requests.post(
            f'https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent',
            params={'key': GEMINI_API_KEY},
            headers={'content-type': 'application/json'},
            json={
                'contents': [{'parts': [{'text': prompt}]}],
                'generationConfig': {
                    # 800〜1200字の本文＋POINTSを日本語で出力するには1600では不足しがちなため増量。
                    'maxOutputTokens': 4096,
                    'temperature': 0.9,
                    # 内部思考（thinking）にトークンを消費させず、全予算を実際の出力に充てる。
                    # thinkingBudget未対応のモデルの場合はこのフィールドは無視される想定。
                    'thinkingConfig': {'thinkingBudget': 0},
                },
                'safetySettings': [
                    {'category': 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold': 'BLOCK_NONE'},
                    {'category': 'HARM_CATEGORY_HARASSMENT',        'threshold': 'BLOCK_ONLY_HIGH'},
                    {'category': 'HARM_CATEGORY_HATE_SPEECH',       'threshold': 'BLOCK_ONLY_HIGH'},
                    {'category': 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold': 'BLOCK_ONLY_HIGH'},
                ],
            },
            timeout=20,
        )

        if resp.status_code == 429:
            # 429はさらに「無料枠/レート上限（RESOURCE_EXHAUSTED）」と
            # 「一時的なレート制限」の両方があり得るため、レスポンス内容で判別する。
            try:
                err_body = resp.json()
            except ValueError:
                err_body = {}
            err_status = (err_body.get('error') or {}).get('status', '')
            err_message = (err_body.get('error') or {}).get('message', '')
            if err_status == 'RESOURCE_EXHAUSTED' or 'quota' in err_message.lower():
                print(f'    🚫 Gemini APIの無料枠/レート上限に到達している可能性が高いです'
                      f'（RESOURCE_EXHAUSTED）。リトライせずテンプレートにフォールバックします。'
                      f'\n       APIキーの利用状況は https://aistudio.google.com/app/apikey や'
                      f' Google Cloud Consoleの割り当てページで確認できます。'
                      f'\n       詳細: {err_message[:200]}')
                break
            # クォータ超過ではない429（一時的なレート制限）は、他のリトライ対象と同様に扱う
            if _attempt < _MAX_RETRIES:
                wait_sec = 3 * (_attempt + 1)
                print(f'    ⏳ Gemini APIのレート制限（429）。{wait_sec}秒後にリトライします'
                      f'（{_attempt + 1}/{_MAX_RETRIES}）...')
                _time.sleep(wait_sec)
            continue

        if resp.status_code not in _RETRYABLE_STATUS_CODES:
            break
        if _attempt < _MAX_RETRIES:
            wait_sec = 3 * (_attempt + 1)  # 3秒 → 6秒と少しずつ間隔を空ける
            print(f'    ⏳ Gemini APIが一時的に混雑（{resp.status_code}）。{wait_sec}秒後にリトライします'
                  f'（{_attempt + 1}/{_MAX_RETRIES}）...')
            _time.sleep(wait_sec)
    data = resp.json()
    try:
        parts = data['candidates'][0]['content']['parts']
        # 応答が複数partsに分かれるケースに備え、全partsのtextを連結する
        # （parts[0]だけを見ると、モデルによっては本文の一部しか拾えないことがある）。
        text = ''.join(p.get('text', '') for p in parts).strip()
        if not text:
            raise KeyError('no text in parts')
    except (KeyError, IndexError, TypeError):
        # candidatesが無い/空の場合、多くは安全フィルタによるブロックが原因。
        # promptFeedback（ブロック理由）を含めてログに出し、原因を特定しやすくする。
        prompt_feedback = data.get('promptFeedback', {})
        raise ValueError(f'unexpected Gemini API response: promptFeedback={prompt_feedback} / raw={data}')

    if not text or '===OVERVIEW===' not in text or '===POINTS===' not in text:
        # フォーマット崩れの原因調査用に、実際に返ってきたテキストの先頭部分と
        # finishReason（MAX_TOKENS/SAFETY等）をログに出す。
        finish_reason = ''
        try:
            finish_reason = data['candidates'][0].get('finishReason', '')
        except (KeyError, IndexError, TypeError):
            pass
        preview = text[:300] if text else '(空文字)'
        raise ValueError(
            f'unexpected AI response format / finishReason={finish_reason} / text_preview={preview!r}'
        )

    overview_part = text.split('===OVERVIEW===', 1)[1].split('===POINTS===', 1)[0].strip()
    points_part = text.split('===POINTS===', 1)[1].strip()
    points = [
        line.strip().lstrip('-').strip()
        for line in points_part.splitlines()
        if line.strip().lstrip('-').strip()
    ]
    if not overview_part or not points:
        raise ValueError('empty overview or points')
    return {'overview': overview_part, 'points': points[:length_variant['points_max']]}


def _stable_pick(key: str, salt: str, options: list):
    """keyから安定的に選ばれる1要素を返す（既存の_stable_variant_indexを再利用）。"""
    if not options:
        return None
    return options[_stable_variant_index(key, salt, len(options))]


def _stable_order(key: str, salt: str, items: list) -> list:
    """itemsを安定的にシャッフルした順序で返す（同じ作品は常に同じ順序になる）。"""
    seed = _stable_variant_index(key, salt, 2 ** 31)
    rng = random.Random(seed)
    shuffled = list(items)
    rng.shuffle(shuffled)
    return shuffled


# 冒頭文（フォーカスキーフレーズあり／なし）のバリエーション
_INTRO_WITH_KEYPHRASE = [
    '「{kp}」に注目の{kind}。{genre}系の内容です。',
    '{genre}系の{kind}として、いま「{kp}」で探している方にちょうど合いそうな一本です。',
    '「{kp}」が気になった方に向けた、{genre}系の{kind}です。',
    '{genre}が好きな方はもちろん、「{kp}」に惹かれた方にもおすすめの{kind}です。',
]
_INTRO_PLAIN = [
    '{genre}系の{kind}です。',
    '{genre}を軸にした{kind}に仕上がっています。',
    '{genre}好きに向けた{kind}です。',
    '{genre}要素を詰め込んだ{kind}となっています。',
]

# 出演者紹介のバリエーション（AVのみ）
_ACTOR_TEMPLATES = [
    '出演しているのは{actor}。この時点でもう見る理由は十分揃っています。',
    '出演は{actor}。名前を見ただけで期待値が上がる組み合わせです。',
    '{actor}が出演しており、ファンなら見逃せない一本です。',
    'キャストは{actor}。この顔ぶれなら安心して選べます。',
]

# メーカー・サークル紹介のバリエーション（appeal_pattern='作者・レーベル訴求'用の候補は別途）
_MAKER_TEMPLATES = [
    'ちなみに、手がけるのは{maker}。',
    '制作は{maker}が担当しています。',
    '{maker}が手がけた作品というのもポイントです。',
    'メーカーは{maker}です。',
]
_MAKER_TEMPLATES_APPEAL = [
    '手がけているのは{maker}で、作風の傾向を知っている方なら安心して選べる一本です。',
    '{maker}が制作を担当。この{maker}という組み合わせにピンときた方は要チェックです。',
]

# 価格訴求のバリエーション
_PRICE_TEMPLATES = [
    'さらに価格は{price}なので、この内容ならコスパも十分満足できるはずです。',
    '価格も{price}と、内容を考えれば手を出しやすい設定です。',
    '{price}という価格も、このボリュームなら納得できる範囲です。',
]

# ジャンル訴求のバリエーション
_GENRE_APPEAL_TEMPLATES = [
    'つまり、{genre}といったジャンルが好きな方はもちろん、'
    '普段あまりこの手のジャンルを見ない方にも新鮮に映る一本というわけです。',
    '{genre}が好きな方には刺さりやすく、初めて触れる方にも入りやすい内容です。',
    '{genre}のファンはもちろん、気分転換に違うジャンルを試したい方にも向いています。',
]

# サンプル画像への言及のバリエーション
_SAMPLE_TEMPLATES = [
    'サンプル画像だけでも見応え十分なので、まずは雰囲気だけでもチェックしてみると早いかもしれません。',
    '購入前にサンプル画像で雰囲気を確認しておくと、選ぶときの参考になります。',
    '気になった方は、まずサンプル画像で作品の空気感を見てみてください。',
]

# レビューへの言及のバリエーション
_REVIEW_TEMPLATES = [
    '実際、レビューでも平均{avg}点（{count}件）と評価は上々で、'
    'すでに多くの人がその魅力に気づいている一本です。',
    'レビューは平均{avg}点（{count}件）と、実際に見た人からの評価も安定しています。',
    '平均{avg}点（{count}件のレビュー）という数字が、内容の安定感を裏付けています。',
]

# 「そのため、」に相当する締めの接続語バリエーション
_CLOSER_LEAD_TEMPLATES = ['そのため、', 'というわけで、', 'そんなわけで、', '以上を踏まえると、']

_GENRE_POINT_TEMPLATES = [
    '{g}好きなら、うっかり夜更かし確定の内容です',
    '{g}成分が気になる方は、もう指がカートに伸びているはず',
    '{g}のツボを心得た一作。油断してると即決してしまいます',
    '{g}好きにこっそり教えたい、隠れた掘り出し物です',
    '{g}をテーマにした場面が中心で、好きな人にはたまらない構成です',
    '{g}が刺さる人にとっては、外せない一本になりそうです',
]

_REVIEW_POINT_TEMPLATES = [
    'また、レビュー平均{avg}点（{count}件）と、みんなも太鼓判',
    'レビューは平均{avg}点（{count}件）。実際に見た人からの評価も高めです',
    '評価は平均{avg}点（{count}件のレビュー）と、安定した支持を集めています',
]

_MAKER_POINT_TEMPLATES = [
    '制作は{maker}。安定した仕上がりも安心材料のひとつです',
    '{maker}が手がけているので、作風の傾向を知っている方には選びやすい一本です',
    '手がけているのは{maker}。この安心感も見逃せないポイントです',
]

_NO_INFO_POINT_TEMPLATES = [
    '作品ページを開いた時点で、もう半分ハマっています',
    '詳細はサンプル画像や作品ページで確認してみてください',
    '情報だけでは伝わりきらない魅力が詰まっている一本です',
]

_OVERVIEW_CLOSERS = [
    '内容を知ったうえで、あとは値段と相談するだけです。',
    '一度サンプルだけでも見ておくと、判断材料としては十分だと思います。',
    '好みに合うかどうかは人それぞれですが、条件は揃っている一本です。',
    'この手のジャンルが刺さる人には、かなり具体的に刺さる内容です。',
    '過度な期待はせず、素直に内容だけで判断してみてください。',
    '細かい好みが分かれる作品なので、まずは特徴を押さえておくと選びやすくなります。',
    '万人向けではありませんが、刺さる人にはしっかり刺さる作りです。',
    '判断に迷ったら、サンプル画像や紹介文の描写を基準にするとよさそうです。',
    '迷っている時間があるなら、その時間でもう読み終わっているかもしれません。',
]


def _get_article_body_template(product: dict, focus_keyphrase: str = '', appeal_pattern: dict = None) -> dict:
    appeal_name = (appeal_pattern or {}).get('name', '')
    key = product.get('content_id') or product.get('title') or ''
    genre_str = '、'.join(product['genres'][:5]) if product['genres'] else '不明'
    work_kind = '同人作品' if CONTENT_TYPE == 'doujin' else 'AV作品'

    # 冒頭文（フォーカスキーフレーズの有無で候補プールを切り替え、言い回しをばらつかせる）。
    if focus_keyphrase:
        intro_tmpl = _stable_pick(key, 'intro', _INTRO_WITH_KEYPHRASE)
        overview = intro_tmpl.format(kp=focus_keyphrase, kind=work_kind, genre=genre_str)
    else:
        intro_tmpl = _stable_pick(key, 'intro', _INTRO_PLAIN)
        overview = intro_tmpl.format(kind=work_kind, genre=genre_str)

    # 出演者/メーカー/価格/ジャンル訴求/サンプル画像/レビューの各文は、
    # 存在するものだけを対象に、作品ごとに安定した順序でシャッフルして連結する。
    optional_sentences = []
    if product.get('actors') and CONTENT_TYPE == 'av':
        actor_str = '、'.join(product['actors'])
        tmpl = _stable_pick(key, 'actor', _ACTOR_TEMPLATES)
        optional_sentences.append(('actor', tmpl.format(actor=actor_str)))
    if product.get('maker'):
        maker_pool = _MAKER_TEMPLATES_APPEAL if appeal_name == '作者・レーベル訴求' else _MAKER_TEMPLATES
        tmpl = _stable_pick(key, 'maker', maker_pool)
        optional_sentences.append(('maker', tmpl.format(maker=product['maker'])))
    if product.get('price'):
        tmpl = _stable_pick(key, 'price', _PRICE_TEMPLATES)
        optional_sentences.append(('price', tmpl.format(price=product['price'])))
    if product.get('genres'):
        tmpl = _stable_pick(key, 'genre_appeal', _GENRE_APPEAL_TEMPLATES)
        optional_sentences.append(('genre_appeal', tmpl.format(genre=genre_str)))
    if product.get('sample_images'):
        tmpl = _stable_pick(key, 'sample', _SAMPLE_TEMPLATES)
        optional_sentences.append(('sample', tmpl))
    if product.get('review_avg') and product.get('review_count'):
        tmpl = _stable_pick(key, 'review', _REVIEW_TEMPLATES)
        optional_sentences.append((
            'review', tmpl.format(avg=product['review_avg'], count=product['review_count']),
        ))

    ordered = _stable_order(key, 'sentence_order', optional_sentences)
    for _, sentence in ordered:
        overview += f" {sentence}"

    closer_lead = _stable_pick(key, 'closer_lead', _CLOSER_LEAD_TEMPLATES)
    closer = _stable_pick(key, 'closer', _OVERVIEW_CLOSERS)
    overview += f"\n\n{closer_lead}{closer}"

    # POINTSも固定順ではなく、存在する要素を安定的にシャッフルした順序で並べる。
    point_candidates = []
    for i, g in enumerate((product.get('genres') or [])[:4]):
        tmpl = _stable_pick(f'{key}::{i}', 'genre_point', _GENRE_POINT_TEMPLATES)
        point_candidates.append(tmpl.format(g=g))
    if product.get('review_avg') and product.get('review_count'):
        tmpl = _stable_pick(key, 'review_point', _REVIEW_POINT_TEMPLATES)
        point_candidates.append(tmpl.format(avg=product['review_avg'], count=product['review_count']))
    if product.get('maker'):
        tmpl = _stable_pick(key, 'maker_point', _MAKER_POINT_TEMPLATES)
        point_candidates.append(tmpl.format(maker=product['maker']))
    if not point_candidates:
        point_candidates = [_stable_pick(key, 'no_info_point', _NO_INFO_POINT_TEMPLATES)]

    points = _stable_order(key, 'point_order', point_candidates)

    # 本文中でもう一度フォーカスキーフレーズに触れる
    # （Yoastの「キーフレーズ分布（最低2回）」チェック対策）。
    # 6件上限で切り捨てられないよう、既に6件ある場合は末尾と差し替える。
    if focus_keyphrase:
        keyphrase_point = f"なお、「{focus_keyphrase}」が気になった方は、ぜひ作品ページもチェックしてみてください"
        if len(points) >= 6:
            points[5] = keyphrase_point
        else:
            points.append(keyphrase_point)

    return {'overview': overview, 'points': points[:6]}


def _paragraphs_to_html(text: str) -> str:
    paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
    html_parts = []
    for p in paragraphs:
        p_html = escape(p).replace('\n', '<br>')
        html_parts.append(
            f'<p style="line-height:1.8;color:#333;margin:0 0 12px;">{p_html}</p>'
        )
    return '\n'.join(html_parts)


_BADGE_COLORS = ['#ff6f91', '#ff9671', '#845ec2', '#4b93ff', '#00c2a8']


def _genre_badges_html(genres: list) -> str:
    if not genres:
        return ''
    badges = []
    for i, g in enumerate(genres[:5]):
        color = _BADGE_COLORS[i % len(_BADGE_COLORS)]
        badges.append(
            f'<span style="display:inline-block;background:{color};color:#fff;'
            'padding:4px 12px;border-radius:999px;font-size:12px;font-weight:bold;'
            f'margin:2px 4px 2px 0;">{escape(g)}</span>'
        )
    return f'<div style="margin:8px 0;">{"".join(badges)}</div>'


def _star_rating_html(avg, count) -> str:
    if not avg or not count:
        return ''
    filled = max(0, min(5, round(avg)))
    stars = '★' * filled + '☆' * (5 - filled)
    return (
        '<div style="margin:6px 0;">'
        f'<span style="color:#f5a623;font-size:18px;letter-spacing:1px;">{stars}</span> '
        f'<span style="color:#888;font-size:13px;">{avg}点（{count}件のレビュー）</span>'
        '</div>'
    )


def _points_list_html(points: list, heading: str = '✓ ここがポイント') -> str:
    if not points:
        return ''
    items = ''.join(
        f'<li style="margin:6px 0;line-height:1.6;">{escape(pt)}</li>'
        for pt in points
    )
    return (
        '<div class="ona-points-box">'
        f'<h2 class="ona-points-title" style="margin:0 0 8px;font-size:16px;">{escape(heading)}</h2>'
        f'<ul style="margin:0;padding-left:20px;">{items}</ul>'
        '</div>'
    )


# サンプル画像のクリック時に「拡大画像」を開く取得元。
# それ以外（DMM等）は従来どおり、クリックでアフィリエイトリンクへ遷移する。
_ENLARGE_SOURCES = {'duga', 'sokmil'}

# 記事内に埋め込む軽量ライトボックス（外部プラグイン不要）。
# ・サムネイルをクリック → 大きい画像を画面中央に表示。画像/背景クリックか Esc で閉じる。←→キーや左右ボタンで前後移動。
# ・JSが無効/除去された環境でも、リンク先が拡大画像なのでクリックすれば新しいタブで大きい画像が開く。
# ・WordPressの自動整形(wpautop)で改行が <br>/<p> に化けないよう、1行にまとめている。
_LIGHTBOX_SNIPPET = (
    '<style>'
    '.ona-lb{position:fixed;inset:0;background:rgba(0,0,0,.88);display:flex;align-items:center;justify-content:center;z-index:99999;cursor:zoom-out}'
    # 元画像が小さいサムネイルしか無い場合でも、画面幅いっぱい（最大960px）まで拡大して表示する
    '.ona-lb img{width:min(94vw,960px);height:auto;max-height:90vh;object-fit:contain;background:#000;box-shadow:0 0 24px rgba(0,0,0,.6)}'
    '.ona-lb button{position:absolute;top:50%;transform:translateY(-50%);background:rgba(255,255,255,.18);color:#fff;border:0;'
    'font-size:32px;width:48px;height:64px;cursor:pointer;border-radius:6px}'
    '.ona-lb .ona-lb-prev{left:8px}.ona-lb .ona-lb-next{right:8px}'
    '.ona-lb .ona-lb-close{top:12px;right:12px;transform:none;height:44px;font-size:26px}'
    '</style>'
    '<script>(function(){if(window.__onaLB)return;window.__onaLB=1;'
    'var box=null,list=[],idx=0;'
    'function show(){box.querySelector("img").src=list[idx];}'
    'function close(){if(box){box.remove();box=null;document.removeEventListener("keydown",key);}}'
    'function step(d){idx=(idx+d+list.length)%list.length;show();}'
    'function key(e){if(e.key==="Escape")close();else if(e.key==="ArrowLeft")step(-1);else if(e.key==="ArrowRight")step(1);}'
    'document.addEventListener("click",function(e){'
    'var a=e.target.closest&&e.target.closest(".ona-sample-gallery[data-ona-lightbox] a.ona-sample-cell");'
    'if(!a)return;e.preventDefault();'
    'list=[].map.call(a.closest(".ona-sample-gallery").querySelectorAll("a.ona-sample-cell"),function(x){return x.href;});'
    'idx=list.indexOf(a.href);if(idx<0)idx=0;close();'
    'box=document.createElement("div");box.className="ona-lb";'
    'box.innerHTML=\'<img alt=""><button class="ona-lb-close" aria-label="閉じる">×</button>\'+'
    '(list.length>1?\'<button class="ona-lb-prev" aria-label="前へ">‹</button><button class="ona-lb-next" aria-label="次へ">›</button>\':"");'
    'box.addEventListener("click",function(ev){var c=ev.target.className;'
    'if(c==="ona-lb-prev"){ev.stopPropagation();step(-1);}else if(c==="ona-lb-next"){ev.stopPropagation();step(1);}else close();});'
    'document.body.appendChild(box);document.addEventListener("keydown",key);show();});'
    '})();</script>'
)

def _sample_gallery_html(affiliate_url: str, sample_images: list, title: str, focus_keyphrase: str = '',
                          heading: str = '作品サンプル', large_images: list = None,
                          enlarge: bool = False) -> str:
    imgs = [u for u in (sample_images or []) if u][:8]
    # large_images は sample_images と同じ並びの拡大用URL。無い/足りない場合は表示用URLで代用する。
    larges = list(large_images or [])
    if not imgs:
        return ''
    # altテキストにフォーカスキーフレーズ（や、それと重なりがちな作品タイトル）を
    # 含めるのは最初の1枚だけにする。
    # 2枚目以降はタイトルも繰り返さず「サンプル画像2」のような汎用文言にすることで、
    # Yoastの「キーフレーズ（や同義語）の過剰使用」警告を避ける。
    keyphrase_alt = f'{focus_keyphrase} {title} サンプル画像' if focus_keyphrase else f'{title} サンプル画像'
    cells = []
    for i, url in enumerate(imgs):
        alt_text = keyphrase_alt if i == 0 else f'サンプル画像{i + 1}'
        # 拡大モード: 画像ファイル自体へリンクする（ライトボックス系プラグインがあればその場で拡大、無ければ新しいタブで開く）
        href = (larges[i] if i < len(larges) and larges[i] else url) if enlarge else affiliate_url
        rel = 'noopener' if enlarge else 'nofollow sponsored noopener'
        cells.append(
            f'<a href="{escape(href)}" target="_blank" rel="{rel}" class="ona-sample-cell">'
            f'<img src="{escape(url)}" alt="{escape(alt_text)}" loading="lazy" class="ona-sample-img"></a>'
        )
    # f-string内でバックスラッシュは使えない(Python 3.11以前)ため、属性文字列は事前に組み立てる
    lightbox_attr = ' data-ona-lightbox="1"' if enlarge else ''
    # 拡大モードではサンプル画像からアフィリエイトリンクへ遷移しなくなるため、導線を1本追加する
    more_link = ''
    if enlarge and affiliate_url:
        more_link = (
            '<p class="ona-sample-more" style="margin:8px 0 0;font-size:14px;">'
            f'<a href="{escape(affiliate_url)}" target="_blank" rel="nofollow sponsored noopener">'
            '▶ 作品ページでサンプルをもっと見る</a></p>'
        )
    return (
        f'<div class="ona-sample-gallery"{lightbox_attr}>'
        f'<h3 class="ona-sample-gallery-title" style="margin:0 0 8px;font-size:15px;">{escape(heading)}</h3>'
        '<div class="ona-sample-grid">' + ''.join(cells) + '</div>'
        + more_link +
        '</div>'
        + (_LIGHTBOX_SNIPPET if enlarge else '')
    )


def _sample_video_html(sample_movie_url: str) -> str:
    """サンプル動画の埋め込み。DMM APIからサンプル動画URLが取得できた作品のみ表示される。
    静止画ギャラリーだけのページより滞在時間が伸びやすく、ページの情報価値も上がる。

    DMM APIの sampleMovieURL は多くの場合、直接再生できる動画ファイル（.mp4等）ではなく、
    litevideo等のプレイヤーページ（HTML）のURLを返す仕様のため、<video src="..."> ではなく
    <iframe> で埋め込む（<video>のままだと再生されない/真っ黒になることがある）。"""
    if not sample_movie_url:
        return ''
    return (
        '<div class="ona-sample-video" style="margin:14px 0;">'
        '<h3 style="margin:0 0 8px;font-size:15px;">サンプル動画</h3>'
        '<div style="position:relative;width:100%;max-width:560px;aspect-ratio:560/360;">'
        f'<iframe src="{escape(sample_movie_url)}" '
        'style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;border-radius:8px;" '
        'allow="autoplay; fullscreen" allowfullscreen loading="lazy"></iframe>'
        '</div>'
        '</div>'
    )


# ================================================================
# 🎛️ 記事バリエーション設定（同一テンプレート感の軽減用）
# ================================================================
# 全記事が「同じ見出し・同じセクション順」になると、文章表現を変えても
# サイト全体としては機械生成のパターンとして見えやすい。
# content_idベースで安定的に（＝再実行しても同じ作品は同じ結果になるように）
# 構成順・見出し文言・AIへの訴求指示をばらけさせる。

# セクション構成順のバリエーション（デフォルトのハッシュ選択用）。
# 各要素名はbuild_article内のsections辞書のキーと対応する。
_SECTION_ORDER_VARIANTS = [
    ['overview', 'meta', 'badges', 'star', 'price', 'points', 'gallery', 'video', 'cta', 'internal_link', 'disclaimer'],
    ['overview', 'star', 'price', 'points', 'badges', 'meta', 'gallery', 'video', 'cta', 'internal_link', 'disclaimer'],
    ['overview', 'points', 'badges', 'meta', 'star', 'price', 'gallery', 'video', 'cta', 'internal_link', 'disclaimer'],
]

# シリーズ物: 「前作との違い」の判断material（meta欄）を早めに見せた方が
# 読者の判断に資するため、構成順を固定でこちらにする。
_SERIES_FORWARD_ORDER = [
    'overview', 'meta', 'points', 'badges', 'star', 'price', 'gallery', 'video', 'cta', 'internal_link', 'disclaimer'
]
# レビューが一定数以上ある作品: 「みんなの評価」を早めに見せて説得材料にする。
_REVIEW_FORWARD_ORDER = [
    'overview', 'star', 'meta', 'price', 'points', 'badges', 'gallery', 'video', 'cta', 'internal_link', 'disclaimer'
]
_REVIEW_FORWARD_THRESHOLD = 50  # このレビュー件数以上ならレビュー優先構成にする

_OVERVIEW_HEADING_VARIANTS = ['作品の魅力', 'この作品はどんな内容？', '注目ポイントを先取り']
_POINTS_HEADING_VARIANTS = ['✓ ここがポイント', '✓ チェックしておきたい特徴', '✓ 押さえておきたい魅力']
_GALLERY_HEADING_VARIANTS = ['作品サンプル', 'サンプルをチェック', '気になる場面をプレビュー']

# Gemini記事生成時にどの切り口を軸にするかのバリエーション。
_APPEAL_PATTERNS = [
    {
        'name': '利用シーン訴求',
        'instruction': (
            "- どんな時間帯・気分・シチュエーションで読者がこの作品を楽しみたくなるか、"
            "具体的な利用シーンを軸に描写してください\n"
        ),
    },
    {
        'name': 'ジャンル比較訴求',
        'instruction': (
            "- 似た系統の作品と比べたときに、このジャンルの組み合わせ・配分が"
            "どう違って見えるかを軸に描写してください\n"
        ),
    },
    {
        'name': '作者・レーベル訴求',
        'instruction': (
            "- 制作元（サークル/メーカー/レーベル/監督）の作風の傾向や過去作との関係を"
            "軸に描写してください（情報が乏しい場合はこの軸に固執しなくてよい）\n"
        ),
    },
    {
        'name': '読者タイプ訴求',
        'instruction': (
            "- どんな好み・経験を持つ読者に強く刺さるか／逆にどんな読者には物足りないかを"
            "軸に描写してください\n"
        ),
    },
]

# 段落数・文字数・POINTS数のバリエーション（全記事が同じ分量にならないように）。
_LENGTH_VARIANTS = [
    {'paragraphs': '3〜4段落、700〜950文字程度', 'points_count': '3〜4個', 'points_max': 4},
    {'paragraphs': '4〜5段落、900〜1150文字程度', 'points_count': '4〜5個', 'points_max': 5},
    {'paragraphs': '4〜6段落、1000〜1300文字程度', 'points_count': '5〜6個', 'points_max': 6},
]

# OVERVIEWの書き出し（最初の一文〜二文）の「型」のバリエーション。
# appeal_pattern（何を軸に描写するか＝内容面）とは別に、「どう切り出すか」という
# レトリック面のパターンをローテーションさせることで、記事の冒頭が
# 毎回同じ構文（例:「◯◯系の作品です。」で始まる等）になるのを防ぐ。
_OPENING_STYLE_VARIANTS = [
    {
        'name': '情景描写から入る',
        'instruction': (
            "- 書き出しは、作品の中の具体的な一場面・状況を情景として描写することから"
            "始めてください（ジャンル名や『〜系の作品です』のような紹介文的な一文から"
            "始めない）\n"
        ),
    },
    {
        'name': '問いかけから入る',
        'instruction': (
            "- 書き出しは、読者に語りかけるような短い問いかけや『こんな経験はないか』"
            "という共感の呼びかけから始めてください\n"
        ),
    },
    {
        'name': '核心の一言から入る',
        'instruction': (
            "- 書き出しは、この作品を一言で言い切るような短い断定的な一文から始め、"
            "その後で詳しく説明を広げてください\n"
        ),
    },
    {
        'name': '対比から入る',
        'instruction': (
            "- 書き出しは、『よくある◯◯とは違い』のような、似た作品との対比から"
            "始めてください（対比先は具体的な傾向で、実在しない作品名は出さない）\n"
        ),
    },
    {
        'name': '読者の状況から入る',
        'instruction': (
            "- 書き出しは、この作品を探している読者が今どんな気分・状況にいそうかを"
            "想像した一文から始めてください\n"
        ),
    },
]


def _make_slug(content_id: str, title: str) -> str:
    """パーマリンクを英数字のみの短いスラッグにする。
    日本語タイトルがそのままURLエンコードされて長く読みにくくなるのを防ぐため、
    content_id（DMM側の商品IDで元々英数字）を優先的に使う。"""
    base = (content_id or '').strip()
    base = re.sub(r'[^A-Za-z0-9\-]+', '-', base).strip('-').lower()
    if base:
        return base
    # content_idが取得できない場合のフォールバック（タイトルのハッシュ的な短縮）
    fallback = re.sub(r'[^A-Za-z0-9]+', '-', title).strip('-').lower()
    return fallback[:60] or 'item'


def _make_excerpt(title: str, max_len: int = 90) -> str:
    """アーカイブページ等で画像の下に表示される抜粋文（プレーンテキスト、HTMLタグなし）。
    以前はジャンル接頭辞＋概要文を独自に組み立てていたが、
    それぞれが同じジャンル名を繰り返してしまい一覧が全部同じ書き出しに見える原因になっていたため、
    シンプルに作品タイトルをそのまま抜粋として使う。"""
    plain = re.sub(r'\s+', ' ', title or '').strip()
    if len(plain) > max_len:
        plain = plain[:max_len - 1].rstrip() + '…'
    return plain


def _make_description_excerpt(overview_text: str, fallback_title: str, max_len: int = 90) -> str:
    """メタディスクリプション用に、AIが生成した本文（OVERVIEW）の冒頭から
    プレーンテキストの説明文を作る。改行や段落区切りは単一スペースにまとめる。
    OVERVIEWが空の場合（テンプレート運用時など）は、作品タイトルにフォールバックする。"""
    plain = re.sub(r'\s+', ' ', (overview_text or '')).strip()
    if not plain:
        return _make_excerpt(fallback_title, max_len=max_len)
    if len(plain) > max_len:
        plain = plain[:max_len - 1].rstrip() + '…'
    return plain


_FOCUS_KEYPHRASE_EXCLUDE = {
    'ハイビジョン', '4K', '4k', 'ＨＤ', 'HD',
    '独占配信', '独占', '専売', '単体', '通販', 'DL版',
    '4時間以上作品', 'デジタル限定', '成人向け', '男性向け',
}


def _build_focus_keyphrase(product: dict, max_words: int = 2, max_chars: int = 12) -> str:
    """Yoast SEOの「フォーカスキーフレーズ」用に、出演者名・ジャンル名から
    最大max_words個の単語を選んでスペース区切りの文字列にする。
    Yoastは12文字前後を推奨しているため、文字数がmax_charsを超える場合は
    単語数をさらに削って収める。
    1文字だけの意味のないジャンル名（例:「P」）や、「ハイビジョン」「4K」など
    画質・属性系のキーワードは除外する。
    出演者名（avのみ）を優先的に含め、残り枠をジャンルで埋める。
    出演者名が無い場合（doujin等）はジャンルのみ、それも無ければサークル/メーカー名を使う。"""
    words = []
    if CONTENT_TYPE == 'av' and product.get('actors'):
        for a in product['actors']:
            a = (a or '').strip()
            if a and a not in words:
                words.append(a)
            if len(words) >= max_words:
                break
    for g in (product.get('genres') or []):
        if len(words) >= max_words:
            break
        g = (g or '').strip()
        if g and len(g) > 1 and g not in words and g not in _FOCUS_KEYPHRASE_EXCLUDE:
            words.append(g)
    if not words and product.get('maker'):
        maker = product['maker'].strip()
        if maker:
            words.append(maker)

    # 文字数がmax_charsを超える場合、収まるまで末尾の単語を削る
    while len(words) > 1 and len(' '.join(words)) > max_chars:
        words.pop()

    return ' '.join(words[:max_words])


def _build_seo_title(product: dict, keyphrase: str = '', max_len: int = 32) -> str:
    """検索結果に表示されるSEOタイトルを生成する。
    キーフレーズが既にタイトル内に含まれる場合は重複させない。"""
    title = (product.get('title') or '').strip()
    if not keyphrase:
        return title[:max_len]

    # キーフレーズが既にタイトルの先頭付近に含まれていれば、
    # 単純にタイトルをそのまま使う（重複防止）
    if keyphrase in title:
        return title[:max_len]

    remaining = max_len - len(keyphrase) - 1
    if remaining <= 0:
        return keyphrase[:max_len]
    return f'{keyphrase} {title[:remaining].rstrip()}'


def build_article(product: dict, recent_openings: list = None) -> dict:
    focus_keyphrase = _build_focus_keyphrase(product)

    # 構成順・見出し・訴求パターン・分量は、content_id（無ければタイトル）を
    # キーにした安定ハッシュで軸ごとに独立して選ぶ。これにより同じ作品は
    # 再実行しても同じ組み合わせになる一方、記事間ではバラける。
    variant_key = product.get('content_id') or product.get('title') or ''
    heading_idx = _stable_variant_index(variant_key, 'heading', len(_OVERVIEW_HEADING_VARIANTS))
    appeal_idx = _stable_variant_index(variant_key, 'appeal', len(_APPEAL_PATTERNS))
    length_idx = _stable_variant_index(variant_key, 'length', len(_LENGTH_VARIANTS))
    structure_idx = _stable_variant_index(variant_key, 'structure', len(_SECTION_ORDER_VARIANTS))
    # 'appeal'とは別の salt('opening')でハッシュを取ることで、appeal_patternとは
    # 独立に（＝appeal_patternが同じ作品同士でも）書き出しの型がばらけるようにする。
    opening_idx = _stable_variant_index(variant_key, 'opening', len(_OPENING_STYLE_VARIANTS))

    appeal_pattern = _APPEAL_PATTERNS[appeal_idx]
    length_variant = _LENGTH_VARIANTS[length_idx]
    opening_pattern = _OPENING_STYLE_VARIANTS[opening_idx]

    # 構成順は、作品の情報の有無（シリーズ物か／レビューが多いか）を優先的に見て決める。
    # 該当しない場合のみ、ハッシュによるローテーションにフォールバックする。
    if product.get('series'):
        section_order = _SERIES_FORWARD_ORDER
    elif (product.get('review_avg') and (product.get('review_count') or 0) >= _REVIEW_FORWARD_THRESHOLD):
        section_order = _REVIEW_FORWARD_ORDER
    else:
        section_order = _SECTION_ORDER_VARIANTS[structure_idx]

    body_content = get_article_body_ai(
        product, focus_keyphrase,
        appeal_pattern=appeal_pattern, length_variant=length_variant,
        opening_pattern=opening_pattern,
        recent_openings=recent_openings,
    )
    # 【品質ゲート】公開してよい品質か機械判定する。不合格は下書きに留める（人の目視確認は不要）。
    quality = quality_gate.assess(product, body_content, quality_gate.load_recent_overviews())
    status_override = ''
    if quality_gate.QUALITY_GATE != 'off' and not quality['publish_ok']:
        status_override = 'draft'
        print('    🚧 品質ゲート不合格 → 下書きに留めます: ' + ' / '.join(quality['reasons']))
    # SEO_INCLUDE_KEYPHRASE=false の場合、SEOタイトル生成にキーフレーズを渡さない
    # （_build_seo_titleはkeyphrase未指定だとタイトルそのままを返す）。
    seo_title = _build_seo_title(
        product,
        keyphrase=(focus_keyphrase if SEO_INCLUDE_KEYPHRASE else ''),
        max_len=20,
    )

    # メタディスクリプションは、作品の内容が伝わるようAI生成OVERVIEW（本文の概要部分）
    # の冒頭を使う。文字数は、Yoastが日本語（全角）を長めにカウントする傾向があるため、
    # 「80文字を超えています」という警告が出ないよう余裕を持たせて55文字までに抑える。
    overview_for_meta = body_content.get('overview', '')
    if SEO_INCLUDE_KEYPHRASE and focus_keyphrase and focus_keyphrase not in overview_for_meta:
        # キーフレーズがOVERVIEW冒頭に含まれていない場合のみ、Yoastのキーフレーズ
        # チェック対策として先頭に付与する（作品説明そのものは維持する）。
        excerpt = _make_description_excerpt(
            f'{focus_keyphrase}｜{overview_for_meta}', product['title'], max_len=55,
        )
    else:
        excerpt = _make_description_excerpt(overview_for_meta, product['title'], max_len=55)
    overview_html = _paragraphs_to_html(body_content['overview'])
    points_html = _points_list_html(
        body_content['points'], heading=_POINTS_HEADING_VARIANTS[heading_idx]
    )
    genre_badges_html = _genre_badges_html(product.get('genres', []))
    star_html = _star_rating_html(product.get('review_avg'), product.get('review_count'))
    gallery_html = _sample_gallery_html(
        product.get('affiliate_url', ''), product.get('sample_images', []), product.get('title', ''),
        focus_keyphrase, heading=_GALLERY_HEADING_VARIANTS[heading_idx],
        large_images=product.get('sample_images_large', []),
        enlarge=product.get('source') in _ENLARGE_SOURCES,
    )
    video_html = _sample_video_html(product.get('sample_movie_url', ''))

    meta_line_parts = []
    if product.get('maker'):
        meta_line_parts.append(f'サークル: {escape(product["maker"])}')
    meta_line_html = ''
    if meta_line_parts:
        meta_line_html = (
            '<div style="color:#666;font-size:13px;margin:4px 0 10px;">'
            + ' ／ '.join(meta_line_parts) + '</div>'
        )

    price_badge_html = ''
    if product.get('price'):
        price_badge_html = (
            '<div style="display:inline-block;background:#fff0f5;color:#e0507a;'
            'border:1px solid #ffc2d6;border-radius:8px;padding:6px 14px;'
            f'font-size:15px;font-weight:bold;margin:10px 0;">価格 {escape(product["price"])}</div>'
        )

    overview_section_html = (
        f'<h2 style="margin:14px 0 8px;font-size:17px;">{escape(_OVERVIEW_HEADING_VARIANTS[heading_idx])}</h2>'
        '<div>'
        f'{overview_html}</div>'
    )

    cta_html = (
        f'<div style="text-align:center;margin:20px 0 8px;">'
        f'<a href="{escape(product["affiliate_url"])}" target="_blank" rel="nofollow sponsored noopener" '
        'style="display:inline-block;padding:14px 36px;background:linear-gradient(135deg,#ff6f91,#e0507a);'
        'color:#fff;text-decoration:none;border-radius:999px;font-size:16px;font-weight:bold;'
        'box-shadow:0 4px 12px rgba(224,80,122,0.35);">'
        '▶ 作品ページを見る</a></div>'
    )

    disclaimer_html = (
        '<p style="color:#999;font-size:12px;line-height:1.6;margin-top:16px;">'
        '※成人向けコンテンツを含みます。18歳未満の方はご利用いただけません。</p>'
    )

    internal_link_html = ''
    if WP_URL:
        cat_label = '同人' if CONTENT_TYPE == 'doujin' else '動画'
        internal_link_html = (
            f'<p style="font-size:13px;margin-top:14px;">'
            f'<a href="{escape(WP_URL)}/category/{cat_label}/">'
            f'他の{cat_label}作品もチェックする →</a></p>'
        )

    # セクションを辞書として持ち、section_order（作品ごとに固定で決まる並び順）に
    # 従って組み立てる。全記事が同じ順番にならないようにするための仕組み。
    sections = {
        'overview':      overview_section_html,
        'meta':          meta_line_html,
        'badges':        genre_badges_html,
        'star':          star_html,
        'price':         price_badge_html,
        'points':        points_html,
        'gallery':       gallery_html,
        'video':         video_html,
        'cta':           cta_html,
        'internal_link': internal_link_html,
        'disclaimer':    disclaimer_html,
    }
    card_inner = '\n'.join(
        sections[name] for name in section_order if sections.get(name)
    )

    body_html = (
        '<div style="max-width:600px;margin:0 auto;padding:20px;border:1px solid #eee;'
        'border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,0.06);font-family:'
        '-apple-system,BlinkMacSystemFont,\'Hiragino Sans\',sans-serif;">'
        f'{card_inner}</div>'
    )

    # タグはジャンルのみ（フィルタなしでそのまま使用、検索性重視）。
    # 出演者名は専用タクソノミー（onavi_actress）に登録するため、タグには含めない。
    tag_source = list(product['genres']) if product['genres'] else []
    actor_source = list(product['actors']) if (CONTENT_TYPE == 'av' and product.get('actors')) else []

    # カテゴリーは「同人」または「動画」の1つだけを使う（ジャンルはカテゴリーに含めない、PRは付与しない）。
    display_category_label = '同人' if CONTENT_TYPE == 'doujin' else '動画'

    return {
        'title':             product['title'],
        'slug':              _make_slug(product.get('content_id', ''), product['title']),
        'excerpt':           excerpt,
        'body':              body_html,
        'tags':              tag_source,
        'actors':            actor_source,
        'category_label':    display_category_label,
        'featured_image_url': product.get('package_image', ''),
        'content_id':        product.get('content_id', ''),
        'volume':            product.get('volume', 0),
        'maker':             product.get('maker', ''),
        'release_date':       (product.get('date') or '')[:10],
        'focus_keyphrase':   focus_keyphrase,
        'seo_title':         seo_title,
        'affiliate_url':     product.get('affiliate_url', ''),
        # WordPressには送らない。次回実行時の自己模倣防止プロンプト用に、
        # 生成されたOVERVIEWの冒頭を投稿履歴へ記録するためだけに使う。
        'overview_text':     body_content.get('overview', ''),
        'status_override':   status_override,
        'quality':           quality,
    }


# ================================================================
# 🔐 WordPress REST API 投稿（アプリケーションパスワード認証・draft固定）
# ================================================================

_category_cache = {}   # name -> id
_tag_cache = {}        # name -> id
_actress_cache = {}    # name -> id（onavi_actress タクソノミー用）


def _wp_auth():
    return (WP_USERNAME, WP_APP_PASSWORD)


_JSON_HEADERS = {
    'Content-Type': 'application/json; charset=utf-8',
    'Accept': 'application/json',
    # レンタルサーバーのbot対策（Imunify360等）は、見慣れない独自User-Agentを
    # 弾くことがあるため、一般的なブラウザのUser-Agentを名乗る。
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
}


def _get_or_create_term(taxonomy: str, name: str, cache: dict):
    """WordPressのカテゴリー/タグを名前で検索し、無ければ作成してIDを返す。"""
    if not name:
        return None
    if name in cache:
        return cache[name]

    endpoint = f'{WP_URL}/wp-json/wp/v2/{taxonomy}'
    try:
        # まず既存を検索
        resp = requests.get(
            endpoint, params={'search': name, 'per_page': 100},
            auth=_wp_auth(), headers=_JSON_HEADERS, timeout=15,
        )
        if resp.status_code == 200:
            try:
                results = resp.json()
            except ValueError:
                results = None
            # 想定外のレスポンス形状（文字列やdictなど）はスキップして作成処理へ進む。
            # search語に完全一致するタームだけを既存として扱う（前方一致等の誤爆を避けるため）。
            if isinstance(results, list):
                for term in results:
                    if isinstance(term, dict) and term.get('name') == name:
                        cache[name] = term['id']
                        return term['id']

        # 無ければ新規作成
        resp = requests.post(
            endpoint, data=json.dumps({'name': name}).encode('utf-8'),
            auth=_wp_auth(), headers=_JSON_HEADERS, timeout=15,
        )
        if resp.status_code in (200, 201):
            try:
                created = resp.json()
            except ValueError:
                created = None
            if isinstance(created, dict) and 'id' in created:
                term_id = created['id']
                cache[name] = term_id
                return term_id
            print(f'    ⚠️ タクソノミー"{name}"の作成レスポンスが想定外の形式です: {resp.text[:200]}')
            return None

        # WordPressは同名タームが既に存在する場合、
        # status 400 + code:"term_exists" + data.term_id を返す仕様。
        # 検索でヒットしなかった（例: 全角/半角違いなど）場合はここで既存IDを拾う。
        try:
            err = resp.json()
        except ValueError:
            err = None
        if isinstance(err, dict) and err.get('code') == 'term_exists':
            existing_id = (err.get('data') or {}).get('term_id')
            if existing_id:
                cache[name] = existing_id
                return existing_id

        print(f'    ⚠️ タクソノミー"{name}"の作成に失敗 status={resp.status_code}: {resp.text[:200]}')
        return None
    except Exception as e:
        print(f'    ⚠️ タクソノミー"{name}"の取得/作成エラー: {e}')
        return None


def _upload_featured_image(image_url: str, content_id: str):
    """パッケージ画像をWordPressメディアライブラリにアップロードし、attachment IDを返す。"""
    if not image_url:
        print('    ℹ️ アイキャッチ画像URLが空のため、画像アップロードをスキップします。')
        return None
    try:
        import mimetypes
        # 一部のアフィリエイト画像サーバーは、User-Agent/Refererが無いリクエストを
        # ブロックすることがあるため、ブラウザからのアクセスに近いヘッダーを付与する。
        img_resp = requests.get(
            image_url,
            timeout=20,
            headers={
                'User-Agent': _JSON_HEADERS['User-Agent'],
                'Referer': image_url.split('/', 3)[0] + '//' + image_url.split('/', 3)[2] + '/',
            },
        )
        img_resp.raise_for_status()
        content_type = img_resp.headers.get('Content-Type', 'image/jpeg').split(';')[0].strip()
        ext = mimetypes.guess_extension(content_type) or '.jpg'
        # HTTPヘッダーはASCII(latin-1)のみ許容されるため、日本語タイトルではなく
        # content_id（英数字）ベースのファイル名にする
        safe_id = (content_id or 'item').replace(' ', '_')
        filename = f'featured-{safe_id}{ext}'

        resp = requests.post(
            f'{WP_URL}/wp-json/wp/v2/media',
            data=img_resp.content,
            auth=_wp_auth(),
            headers={
                'Content-Type': content_type,
                'Content-Disposition': f'attachment; filename="{filename}"',
                'Accept': 'application/json',
                'User-Agent': _JSON_HEADERS['User-Agent'],
            },
            timeout=30,
        )
        if resp.status_code in (200, 201):
            media_id = resp.json()['id']
            print(f'    🖼️ アイキャッチ画像アップロード成功（media_id={media_id}, 元URL={image_url}）')
            return media_id
        print(f'    ⚠️ アイキャッチ画像のアップロードに失敗 status={resp.status_code}: {resp.text[:200]}')
        return None
    except Exception as e:
        print(f'    ⚠️ アイキャッチ画像の取得/アップロードエラー（画像URL={image_url}）: {e}')
        return None


def post_draft_to_wordpress(article: dict) -> bool:
    endpoint = f'{WP_URL}/wp-json/wp/v2/posts'

    # カテゴリーは種別ラベル（doujin:「同人」／av:「動画」）の1つだけを登録する。
    # ジャンル・出演者はタグ側に登録する（build_articleで組み立て済みのarticle['tags']を使用）。
    category_label = article.get('category_label') or CONTENT_LABEL
    category_ids = []
    base_category_id = _get_or_create_term('categories', category_label, _category_cache)
    if base_category_id:
        category_ids.append(base_category_id)

    tag_ids = []
    for tag_name in article.get('tags', []):
        if not tag_name or tag_name == category_label:
            continue
        tid = _get_or_create_term('tags', tag_name, _tag_cache)
        if tid and tid not in tag_ids:
            tag_ids.append(tid)

    # 出演者（avのみ）は専用タクソノミー「onavi_actress」に登録する。
    # ※ WordPress側で register_taxonomy() により rest_base='onavi_actress' として
    #   REST APIに公開されている必要がある（未対応の場合はこの項目は無視される）。
    actress_ids = []
    for actor_name in article.get('actors', []):
        if not actor_name:
            continue
        aid = _get_or_create_term('onavi_actress', actor_name, _actress_cache)
        if aid and aid not in actress_ids:
            actress_ids.append(aid)

    # 品質ゲート不合格の記事は 'draft' に上書きされる
    eff_status = article.get('status_override') or WP_POST_STATUS
    payload = {
        'title':      article['title'],
        'slug':       article.get('slug') or '',
        'excerpt':    article.get('excerpt') or '',
        'content':    article['body'],
        'status':     eff_status,       # 'draft' / 'pending' / 'publish'（WP_POST_STATUS。品質ゲート不合格はdraft）
        'categories': category_ids,
        'tags':       tag_ids,
    }
    if actress_ids:
        payload['onavi_actress'] = actress_ids

    # Yoast SEOの「フォーカスキーフレーズ」「SEOタイトル」「メタディスクリプション」を
    # 投稿と同時に設定する。
    # ※ WordPress側で '_yoast_wpseo_focuskw' / '_yoast_wpseo_title' / '_yoast_wpseo_metadesc'
    #   メタフィールドが register_post_meta() 等でREST APIに公開されている必要がある。
    meta = {}
    focus_keyphrase = article.get('focus_keyphrase') or ''
    if focus_keyphrase:
        meta['_yoast_wpseo_focuskw'] = focus_keyphrase
    seo_title = article.get('seo_title') or ''
    if seo_title:
        meta['_yoast_wpseo_title'] = seo_title
    metadesc = article.get('excerpt') or ''
    if metadesc:
        meta['_yoast_wpseo_metadesc'] = metadesc
    # デプロイ確認用: この投稿がどのバージョンのスクリプトで生成されたかを記録する
    meta['_onavi_script_version'] = SCRIPT_VERSION

    # 記事一覧のアイキャッチ画像から直接アフィリエイトリンクへ飛ばせるように、
    # アフィリエイトURLをカスタムフィールドとしても保存しておく。
    # ※ WordPress側で '_onavi_affiliate_url' を register_post_meta() 等で
    #   REST APIに公開しておく必要がある（下記functions.php例を参照）。
    if article.get('affiliate_url'):
        meta['_onavi_affiliate_url'] = article['affiliate_url']

    # 新デザインのカード表示用（再生時間・品番・メーカー）。
    # WordPress側で register_post_meta() 済み（otona-navi-redesign.php の「N」節）。
    if article.get('volume'):
        meta['_onavi_volume'] = str(article['volume'])
    if article.get('content_id'):
        meta['_onavi_content_id'] = str(article['content_id'])
    if article.get('maker'):
        meta['_onavi_maker'] = str(article['maker'])
    # 個別作品ページの「配信開始」表示用（YYYY-MM-DD形式のときだけ保存）
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}', str(article.get('release_date') or '')):
        meta['_onavi_release_date'] = article['release_date']

    if meta:
        payload['meta'] = meta

    # アイキャッチ画像（featured_media）を設定する。
    # 本文側からは同じ画像を削除したので、重複表示にはならない。
    media_id = _upload_featured_image(article.get('featured_image_url', ''), article.get('content_id', ''))
    if media_id:
        payload['featured_media'] = media_id

    try:
        resp = requests.post(
            endpoint, data=json.dumps(payload).encode('utf-8'),
            auth=_wp_auth(), headers=_JSON_HEADERS, timeout=20,
        )

        # --- 診断ログ（原因切り分け用） -------------------------------
        # ・resp.history に何か入っていれば、途中でリダイレクトが発生している
        #   （POSTがGETに化ける典型パターン）。
        # ・resp.url がendpointと異なれば、リダイレクト先URLが分かる。
        # ・Cache関連ヘッダーがあれば、プロキシ/CDN層のキャッシュが疑われる。
        if resp.history:
            redirect_chain = ' -> '.join(r.url for r in resp.history) + f' -> {resp.url}'
            print(f"    🔎 リダイレクトが発生しています: {redirect_chain}")
        if resp.url != endpoint:
            print(f"    🔎 最終アクセスURLがendpointと異なります: endpoint={endpoint} / 実際={resp.url}")
        cache_headers = {
            k: v for k, v in resp.headers.items()
            if k.lower() in (
                'x-cache', 'x-cache-status', 'age', 'cf-cache-status',
                'x-litespeed-cache', 'x-proxy-cache', 'server', 'via',
            )
        }
        if cache_headers:
            print(f"    🔎 キャッシュ/プロキシ関連ヘッダー: {cache_headers}")
        print(f"    🔎 HTTPステータス: {resp.status_code}")
        # ---------------------------------------------------------------

        if resp.status_code in (200, 201):
            try:
                result = resp.json()
            except ValueError:
                result = None
            # レンタルサーバーのbot対策（Imunify360等）にブロックされた場合、
            # HTTPステータスは200/201でも本文が {"message": "..."} のような
            # エラーメッセージだけのことがある。実際に投稿されたことを保証するため、
            # 本物のWordPress投稿レスポンス（'id'キーを持つdict）かどうかを確認する。
            if not isinstance(result, dict) or 'id' not in result:
                print(f"    ❌ 投稿失敗：WordPressから投稿データが返りませんでした"
                      f"（サーバー側のbot対策等でブロックされた可能性があります）: {resp.text[:300]}")
                return False
            actual_status = result.get('status')
            # WordPressから返ってきたステータスが、こちらが指定したWP_POST_STATUSと
            # 一致しているかどうかだけを確認する（想定外の値が返った場合のみ警告）。
            if actual_status != eff_status:
                print(f"    ⚠️ 指定したステータス（{eff_status}）と異なる値が返りました"
                      f"（status={actual_status}）。念のため内容をご確認ください: {result.get('link', '')}")
            print(f"    ✅ {actual_status}として投稿成功: {article['title'][:40]}")
            # 公開(publish)された場合のみ、そのURLをIndexNowへ通知する。
            # draft/pending（人間が後から手動公開する運用）の場合は、
            # この時点ではまだ公開されていないURLなので送信しない。
            if actual_status == 'publish':
                submit_url(WP_URL, result.get('link', ''))
            return True
        else:
            print(f"    ❌ 投稿失敗 status={resp.status_code}: {resp.text[:300]}")
            return False
    except Exception as e:
        print(f"    ❌ 投稿エラー: {e}")
        return False


# ================================================================
# 🚀 メイン実行
# ================================================================

def _parse_dmm_date(date_str):
    """DMMの date フィールド（例: 'YYYY-MM-DD HH:MM:SS'）をdatetimeに変換する。
    パースできない・空の場合はNoneを返す。"""
    if not date_str:
        return None
    date_str = date_str.strip()
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
        try:
            return datetime.datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None


def main():
    history = load_posted_history()
    posted_history = history['posted']
    recent_openings = history['recent_openings']
    print(f'📚 投稿済み履歴: {len(posted_history)}件')

    now_jst = datetime.datetime.now(JST)
    today = now_jst.date()
    window_start = today - datetime.timedelta(days=DATE_WINDOW_DAYS)
    # 比較用に、実行時刻（JST）をtzなしdatetimeにしておく（DMMのdateフィールドはtz情報を持たないため）
    now_naive = now_jst.replace(tzinfo=None)
    # DMM API側で発売日/配信日の範囲を絞り込み、未来の予約作品を最初から取得対象外にする
    gte_date_str = datetime.datetime.combine(window_start, datetime.time.min).strftime('%Y-%m-%dT%H:%M:%S')
    lte_date_str = now_naive.strftime('%Y-%m-%dT%H:%M:%S')
    if SOURCE == 'dmm':
        print(f'\n🏆 {_SORT_LABEL}（sort={DMM_SORT_MODE}）で上位{RANK_FETCH_LIMIT}件を取得します...'
              f'（DMM APIへ日付範囲指定: {gte_date_str} 〜 {lte_date_str}）')
        raw_items = fetch_rank_items(RANK_FETCH_LIMIT, sort=DMM_SORT_MODE,
                                      gte_date=gte_date_str, lte_date=lte_date_str)
        parse_item = parse_product
    elif SOURCE == 'duga':
        from duga_source import fetch_duga_products, parse_duga_product
        print(f'\n🟣 DUGAから上位{RANK_FETCH_LIMIT}件を取得します（sort={DUGA_SORT}）...')
        raw_items = fetch_duga_products(
            offset=1, hits=RANK_FETCH_LIMIT, sort=DUGA_SORT,
            release_start=window_start.strftime('%Y%m%d'),
            release_end=today.strftime('%Y%m%d'),
        )
        parse_item = parse_duga_product
    elif SOURCE == 'mgs':
        from mgs_source import fetch_and_parse_mgs_products
        print(f'\n🟢 MGSから上位{RANK_FETCH_LIMIT}件を取得します（ランキングスクレイピング）...')
        # MGS版はスクレイピングの時点で既にproduct辞書へ正規化済みなので、
        # parse_itemは恒等関数（そのまま返すだけ）にする。
        raw_items = fetch_and_parse_mgs_products(limit=RANK_FETCH_LIMIT, sleep_seconds=MGS_SLEEP_SECONDS)
        parse_item = lambda x: x
    else:  # SOURCE == 'sokmil'
        from sokmil_source import fetch_sokmil_products, parse_sokmil_product
        print(f'\n🔵 ソクミルから上位{RANK_FETCH_LIMIT}件を取得します（sort={SOKMIL_SORT}）...')
        raw_items = fetch_sokmil_products(
            hits=RANK_FETCH_LIMIT, offset=1, sort=SOKMIL_SORT,
            release_start=window_start.strftime('%Y-%m-%d'),
            release_end=today.strftime('%Y-%m-%d'),
        )
        parse_item = parse_sokmil_product

    print(f'🏆 {len(raw_items)}件を取得しました。'
          f'（対象期間: {window_start} 〜 実行日時（{now_naive}）より過去 の発売日/配信日のみ投稿対象。'
          f'ただしdateが取得できない場合は期間フィルターをスキップします）')

    safe_products = []
    seen_in_run = set()
    all_skipped = []
    out_of_window_skipped = []
    dup_skipped = 0

    for item in raw_items:
        if len(safe_products) >= MAX_ARTICLES:
            break

        product = parse_item(item)
        key = product_history_key(product)

        # 【重複防止】過去に投稿済みの作品、および今回の実行内で既に選ばれた作品はスキップする
        if key in posted_history or key in seen_in_run:
            dup_skipped += 1
            continue

        ok, matched = is_safe(product)
        if not ok:
            all_skipped.append((product, matched))
            continue

        # 発売日/配信日が「実行日時（now）より過去」かつ「今日から過去DATE_WINDOW_DAYS日以内」の
        # 作品のみを対象にする。
        # ・実行日時より未来（＝当日中でもまだ配信/発売されていない予約作品）は自動的に対象外になる
        # ・window_startより古い作品も対象外になる
        # ・DUGA/MGSはdateが取得できないことがあるため、その場合はこのフィルターをスキップする
        #   （DMMはdateが必ず入っている前提のまま、従来通り厳密にチェックする）
        raw_date = product.get('date', '')
        if SOURCE != 'dmm' and not raw_date:
            pass  # 期間フィルターをスキップ（date不明のため対象に含める）
        else:
            product_date = _parse_dmm_date(raw_date)
            if (
                product_date is None
                or product_date > now_naive
                or product_date.date() < window_start
            ):
                out_of_window_skipped.append(product)
                continue

        price_num = product.get('price_num')
        if PRICE_MIN is not None and (price_num is None or price_num < PRICE_MIN):
            continue
        if PRICE_MAX is not None and (price_num is None or price_num > PRICE_MAX):
            continue

        if CONTENT_TYPE == 'av' and EXCLUDE_VR and _is_vr_product(product):
            continue

        seen_in_run.add(key)
        safe_products.append(product)

    print(f'\n📊 検索結果: {len(safe_products)}/{MAX_ARTICLES}件 集まりました '
          f'（安全フィルター除外 {len(all_skipped)}件・対象期間外のため除外 {len(out_of_window_skipped)}件・'
          f'投稿済み重複のため除外 {dup_skipped}件）')

    if out_of_window_skipped:
        print(f'   📅 対象期間（{window_start}〜{today}）外のためスキップ（例）:')
        for p in out_of_window_skipped[:10]:
            print(f"      - {p['title'][:40]}（発売日/配信日: {p.get('date')}）")
        if len(out_of_window_skipped) > 10:
            print(f'      …他{len(out_of_window_skipped) - 10}件')

    if all_skipped:
        Path('outputs').mkdir(exist_ok=True)
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        skip_path = Path('outputs') / f'skipped_{ts}.txt'
        with open(skip_path, 'w', encoding='utf-8') as f:
            f.write('# 年少者連想ワードにより除外された作品一覧\n\n')
            for p, matched in all_skipped:
                f.write(f"- {p['title']}\n  マッチ語: {', '.join(matched)}\n")
        print(f'📄 除外ログ: {skip_path}')

    if not safe_products:
        print('⚠️ 投稿対象の作品がありませんでした（フィルター/重複除外で全件除外、または対象期間内に該当作品なし）。')
        sys.exit(0)

    if len(safe_products) < MAX_ARTICLES:
        print(f'⚠️ {_SORT_LABEL}上位{RANK_FETCH_LIMIT}件・対象期間{DATE_WINDOW_DAYS}日以内の中では'
              f'{MAX_ARTICLES}件に届きませんでした。集まった{len(safe_products)}件のみ投稿します。')

    posted = 0
    for p in safe_products:
        print(f"\n📝 記事生成中: {p['title'][:40]}（発売日/配信日: {p.get('date') or '不明'}）")
        article = build_article(p, recent_openings=recent_openings)
        q = article.get('quality') or {}
        if q and quality_gate.QUALITY_GATE == 'skip' and not q.get('publish_ok'):
            print('    ⏭️ QUALITY_GATE=skip のため投稿しません')
            quality_gate.log_report(p, q, 'skipped')
            # 一時的なAI失敗以外は再試行しても結果が変わらないため、履歴に入れて毎回の再試行を避ける
            if not any('AI生成' in r for r in q.get('reasons', [])):
                posted_history.add(product_history_key(p))
                save_posted_history(posted_history, recent_openings)
            continue
        if post_draft_to_wordpress(article):
            posted += 1
            posted_history.add(product_history_key(p))
            if q:
                quality_gate.log_report(p, q, article.get('status_override') or WP_POST_STATUS)
            _ov = (article.get('overview_text') or '')[:600]
            if _ov:
                _recent_ov = quality_gate.load_recent_overviews()
                _recent_ov.append(_ov)
                quality_gate.save_recent_overviews(_recent_ov)
            # 今回生成した書き出し冒頭を履歴に追加し、次回以降のAI生成で
            # 同じような書き出しパターンが連続しないようにする。
            opening = (article.get('overview_text') or '')[:40]
            if opening:
                recent_openings.append(opening)
            save_posted_history(posted_history, recent_openings)

    print(f'\n✅ 完了！{posted}/{len(safe_products)} 件をWordPressに{WP_POST_STATUS}として投稿しました。')
    print(f'   📚 累計投稿履歴: {len(posted_history)}件（{POSTED_HISTORY_FILE}）')
    print('   ※ 公開前に必ず内容をご確認ください。')


if __name__ == '__main__':
    main()
