# -*- coding: utf-8 -*-
"""
🔵 ソクミル（SOKMIL）アフィリエイト 取得・正規化モジュール

wordpress_blog_poster.py から次のインターフェースで呼び出される。
    fetch_sokmil_products(hits, offset, sort, release_start, release_end) -> list[dict]
    parse_sokmil_product(item) -> dict   # ポスター共通のproduct辞書に正規化

必要な環境変数:
    SOKMIL_API_KEY       : ソクミルAPIキー（必須）
    SOKMIL_AFFILIATE_ID  : アフィリエイトID（必須）
    SOKMIL_DEBUG         : 1 にすると、先頭1件の生データ構造を表示（項目名の調査用）

※ レスポンスの項目名はAPIバージョンで揺れる可能性があるため、候補キーを順に探し、
  取得できない項目は空値にフォールバックする（処理は止めない）。
"""
from __future__ import annotations

import datetime
import hashlib
import os
import re
import time
from typing import Any, Optional

import requests

from real_summary import pick_summary, clean_summary, debug_log

Product = dict[str, Any]

SOKMIL_API_BASE = 'https://sokmil-ad.com/api/v1/Item'
_MAX_HITS_PER_REQUEST = 100
_REQUEST_TIMEOUT_SEC = 15
_MAX_RETRIES = 3
_RETRY_WAIT_SEC = 2.0
_IMAGE_URL_RE = re.compile(r'^https?://.+\.(?:jpe?g|png|gif|webp)(?:\?.*)?$', re.IGNORECASE)

# 作品ではない無料枠・広告枠を示すキーワード（タイトル／ジャンルに含まれたら除外）
_EXCLUDE_TITLE_KEYWORDS: tuple[str, ...] = ('毎朝10時に更新', '0円エロ動画', '1日1本無料')
_EXCLUDE_GENRE_KEYWORDS: tuple[str, ...] = ('0円動画',)


class SokmilConfigError(RuntimeError):
    """認証情報の未設定など、設定起因のエラー。"""


# ================================================================
# 🔧 内部ユーティリティ
# ================================================================

def _load_credentials() -> tuple[str, str]:
    # 旧名 SOKMIL_API_ID も受け付ける（既存のGitHub Secret名を変えずに使えるようにするため）
    api_key = (os.environ.get('SOKMIL_API_KEY', '').strip()
               or os.environ.get('SOKMIL_API_ID', '').strip())
    affiliate_id = os.environ.get('SOKMIL_AFFILIATE_ID', '').strip()
    if not api_key or not affiliate_id:
        raise SokmilConfigError('環境変数 SOKMIL_API_KEY（または SOKMIL_API_ID） / SOKMIL_AFFILIATE_ID が設定されていません。')
    return api_key, affiliate_id


def _parse_date_str(raw: Any) -> Optional[datetime.date]:
    if not raw:
        return None
    text = str(raw).strip().split(' ')[0].split('T')[0]
    for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%Y%m%d'):
        try:
            return datetime.datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def _first(item: Product, keys: tuple[str, ...]) -> Any:
    for key in keys:
        if item.get(key):
            return item[key]
    return ''


def _to_https(url: Any) -> str:
    if not url or not isinstance(url, str):
        return ''
    url = url.strip()
    if url.startswith('//'):
        return 'https:' + url
    if url.startswith('http://'):
        return 'https://' + url[len('http://'):]
    return url


def _names(container: Any) -> list[str]:
    """genre / actress / maker 等の揺れる構造から名前の配列を取り出す。
    想定形: [{'name':..}] / [{'data':{'name':..}}] / ['名前'] / {'name':..} / '名前'"""
    if not container:
        return []
    if isinstance(container, dict):
        container = container.get('data') or container.get('item') or [container]
    if not isinstance(container, list):
        container = [container]
    names: list[str] = []
    for entry in container:
        if isinstance(entry, dict) and isinstance(entry.get('data'), dict):
            entry = entry['data']
        name = ''
        if isinstance(entry, dict):
            name = str(entry.get('name') or entry.get('title') or '').strip()
        elif isinstance(entry, str):
            name = entry.strip()
        if name and name not in names:
            names.append(name)
    return names


def _collect_image_urls(node: Any, limit: int = 8) -> list[str]:
    """入れ子のdict/listから画像URLを出現順に集める（重複除去）。
    DMM風の {'sample_l': {'image': [...]}, 'sample_s': {...}} は大きい方（sample_l）を優先する。"""
    if isinstance(node, dict):
        for preferred in ('sample_l', 'large'):
            if preferred in node:
                found = _collect_image_urls(node[preferred], limit)
                if found:
                    return found
    urls: list[str] = []

    def walk(value: Any) -> None:
        if len(urls) >= limit:
            return
        if isinstance(value, str):
            https = _to_https(value)
            if _IMAGE_URL_RE.match(https) and https not in urls:
                urls.append(https)
        elif isinstance(value, dict):
            for v in value.values():
                walk(v)
        elif isinstance(value, list):
            for v in value:
                walk(v)

    walk(node)
    return urls[:limit]


def _collect_sample_images(node: Any, limit: int = 8) -> tuple[list[str], list[str]]:
    """サンプル画像を (表示用, 拡大用) の2配列で返す。同じ並び・同じ長さ。
    {'sample_s': ..., 'sample_l': ...} のようにサイズ違いがあれば、表示用=小 / 拡大用=大にする。
    サイズ違いが無ければ両方とも同じURLになる（その場合も拡大表示自体は動く）。"""
    if isinstance(node, dict):
        large = _collect_image_urls(node.get('sample_l') or node.get('large'), limit)
        small = _collect_image_urls(node.get('sample_s') or node.get('small'), limit)
        if large and small and len(large) == len(small):
            return small, large
        if large:
            return large, large
        if small:
            return small, small
    urls = _collect_image_urls(node, limit)
    return urls, list(urls)


def _pick_package_image(item: Product) -> str:
    block = item.get('imageURL') or item.get('image') or item.get('imageUrl')
    if isinstance(block, dict):
        for key in ('large', 'list', 'small'):
            if block.get(key):
                return _to_https(block[key])
    if isinstance(block, str):
        return _to_https(block)
    return ''


def _exclusion_reason(item: Product) -> str:
    """投稿対象外の商品なら理由を返し、対象なら空文字を返す。
    無料枠の広告商品や画像なしの商品は、記事として成立しないため除外する。"""
    title = str(item.get('title') or '')
    for kw in _EXCLUDE_TITLE_KEYWORDS:
        if kw in title:
            return f'タイトルに「{kw}」'

    info = item.get('iteminfo') if isinstance(item.get('iteminfo'), dict) else {}
    genres = _names(info.get('genre') or item.get('genre'))
    for kw in _EXCLUDE_GENRE_KEYWORDS:
        if any(kw in g for g in genres):
            return f'ジャンルに「{kw}」'

    if not _pick_package_image(item):
        return 'パッケージ画像なし'
    return ''


def _request_page(params: dict[str, Any]) -> list[Product]:
    last_error: Optional[Exception] = None
    data: Any = None
    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            resp = requests.get(SOKMIL_API_BASE, params=params, timeout=_REQUEST_TIMEOUT_SEC)
            resp.raise_for_status()
            data = resp.json()
            break
        except (requests.RequestException, ValueError) as e:
            last_error = e
            print(f'  ⚠️ [SOKMIL] 取得失敗（{attempt}/{_MAX_RETRIES}回目）: {e}')
            if attempt < _MAX_RETRIES:
                time.sleep(_RETRY_WAIT_SEC * attempt)
    else:
        raise RuntimeError(f'ソクミルAPIの取得に失敗しました: {last_error}') from last_error

    if not isinstance(data, dict):
        raise RuntimeError(f'ソクミルAPIの応答形式が想定外です: {str(data)[:200]}')
    result = data.get('result', data)
    if isinstance(result, dict):
        status = result.get('status')
        if status not in (None, 200, '200'):
            raise RuntimeError(f'ソクミルAPIがエラーを返しました（status={status}）: {str(result)[:200]}')
        items = result.get('items') or result.get('item') or []
    else:
        items = []
    if isinstance(items, dict):  # {'item': [...]} 形式
        items = items.get('item') or []
    return [i for i in items if isinstance(i, dict)]


# ================================================================
# 🌐 公開API
# ================================================================

def fetch_sokmil_products(
    hits: int = 100,
    offset: int = 1,
    sort: str = 'date',
    release_start: str = '',
    release_end: str = '',
) -> list[Product]:
    """ソクミルAPIから作品を取得する（100件超は自動でページ送り）。
    release_start / release_end は 'YYYY-MM-DD'。日付はクライアント側で絞り込み、
    新着順(date)で期間より古い作品が出た時点で打ち切る。"""
    api_key, affiliate_id = _load_credentials()
    start_date = _parse_date_str(release_start)
    end_date = _parse_date_str(release_end)

    first_offset = max(1, offset)
    current_offset = first_offset
    remaining = max(1, hits)
    collected: list[Product] = []
    excluded_count = 0

    while remaining > 0:
        page_hits = min(remaining, _MAX_HITS_PER_REQUEST)
        params = {
            'api_key': api_key, 'affiliate_id': affiliate_id, 'output': 'json',
            'hits': page_hits, 'offset': current_offset, 'sort': sort,
        }
        print(f'  [SOKMIL] 取得中（sort={sort} / offset={current_offset} / hits={page_hits}）...')
        try:
            page = _request_page(params)
        except RuntimeError:
            if current_offset == first_offset:
                raise
            print('  ⚠️ [SOKMIL] 2ページ目以降の取得に失敗したため、ここまでの結果で続行します。')
            break
        if not page:
            break

        if collected == [] and os.environ.get('SOKMIL_DEBUG', '').strip() in ('1', 'true'):
            print(f'  🔎 [SOKMIL debug] 先頭1件のキー: {sorted(page[0].keys())}')
            print(f'  🔎 [SOKMIL debug] 先頭1件: {str(page[0])[:800]}')

        hit_older = False
        for item in page:
            released = _parse_date_str(_first(item, ('date', 'release_date', 'open_date')))
            if released is not None:
                if start_date and released < start_date:
                    hit_older = True
                    continue
                if end_date and released > end_date:
                    continue

            # 無料枠・広告枠・画像なしは投稿対象から外す
            reason = _exclusion_reason(item)
            if reason:
                excluded_count += 1
                print(f'  ⏭️ [SOKMIL] 除外: {str(item.get("title") or "")[:40]}（{reason}）')
                continue
            collected.append(item)

        if sort == 'date' and hit_older:
            break
        if len(page) < page_hits:
            break
        current_offset += page_hits
        remaining -= page_hits

    print(f'  ✅ [SOKMIL] {len(collected)} 件取得しました（除外 {excluded_count} 件）。')
    return collected


def parse_sokmil_product(item: Product) -> Product:
    """ソクミルのitemを、wordpress_blog_poster.py 共通のproduct辞書へ正規化する。"""
    title = str(item.get('title') or '').strip()
    item_id = str(_first(item, ('item_id', 'id', 'content_id', 'product_id')) or '').strip().lower()
    # 他ソースのcontent_idと衝突しないようプレフィックスを付ける（履歴キー兼スラッグ）
    content_id = f'sokmil-{item_id}' if item_id else 'sokmil-' + hashlib.sha1(title.encode('utf-8')).hexdigest()[:10]

    price_raw = item.get('price')
    if isinstance(price_raw, dict):
        price_raw = price_raw.get('price') or price_raw.get('list_price')
    digits = ''.join(ch for ch in str(price_raw or '') if ch.isdigit())
    price_num = int(digits) if digits else None
    price_str = f'¥{price_num:,}' if price_num is not None else ''

    info = item.get('iteminfo') if isinstance(item.get('iteminfo'), dict) else {}
    genres = _names(info.get('genre') or item.get('genre'))
    actors = _names(info.get('actress') or item.get('actress') or item.get('performer'))[:3]
    makers = _names(info.get('maker') or item.get('maker'))
    labels = _names(info.get('label') or item.get('label'))
    series = _names(info.get('series') or item.get('series'))
    directors = _names(info.get('director') or item.get('director'))

    review_avg: Optional[float] = None
    review_count: Optional[int] = None
    review = item.get('review')
    if isinstance(review, dict):
        try:
            review_avg = round(float(review.get('average') or 0), 2) or None
            review_count = int(review.get('count') or 0) or None
        except (TypeError, ValueError):
            review_avg, review_count = None, None

    sample_node = item.get('sampleImageURL') or item.get('sample_images') or item.get('sampleImage')
    sample_images, sample_images_large = _collect_sample_images(sample_node)
    released = _parse_date_str(_first(item, ('date', 'release_date', 'open_date')))
    # 公式の紹介文（実データ）。取れなければ空文字
    summary = pick_summary(item)
    debug_log('sokmil', item, summary)

    return {
        'content_id':       content_id,
        'title':            title,
        'affiliate_url':    str(_first(item, ('affiliateURL', 'affiliateUrl', 'affiliate_url', 'URL', 'url')) or '').strip(),
        'price':            price_str,
        'price_num':        price_num,
        'genres':           genres,
        'maker':            makers[0] if makers else '',
        'actors':           actors,
        'review_avg':       review_avg,
        'review_count':     review_count,
        'package_image':    _pick_package_image(item),
        'sample_images':    sample_images,
        'sample_images_large': sample_images_large,
        'sample_movie_url': '',  # 埋め込みURLの仕様が未確認のため未対応（空なら動画ブロックは出力されない）
        'series':           series[0] if series else '',
        'label':            labels[0] if labels else '',
        'director':         directors[0] if directors else '',
        # ポスター側の期間フィルターが読める 'YYYY-MM-DD' 形式に統一（不明なら空）
        'date':             released.isoformat() if released else '',
        'source':           'sokmil',
        'real_summary':     summary,
    }
