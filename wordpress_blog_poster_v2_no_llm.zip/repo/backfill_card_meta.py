# -*- coding: utf-8 -*-
"""
🔁 過去記事の「再生時間・品番・メーカー」一括補完ツール

新デザインのカードに表示する3つのカスタムフィールド
    _onavi_volume      再生時間（分）
    _onavi_content_id  品番（DMMのcontent_id）
    _onavi_maker       メーカー名
    _onavi_release_date 配信日（YYYY-MM-DD）… 個別作品ページの「配信開始」表示用
を、すでに投稿済みの記事に後から保存します。

■ 仕組み
  1. WordPress REST APIで記事を全件取得
  2. 本文中のアフィリエイトリンク（al.fanza.co.jp / al.dmm.co.jp）から
     品番(content_id)を取り出す
     （リンクが無い記事は、スラッグが品番由来のものに限り、スラッグから推定）
  3. DMM API(ItemList, cidで1件検索)で再生時間とメーカーを取得
  4. 足りないフィールドだけをWordPressに書き込む（既にある値は上書きしない）

■ 事前条件
  ・redesign用PHPスニペット(otona-navi-redesign.php)が有効であること
    （N-2でカスタムフィールドをREST APIに公開しているため。無効だと保存されません）
  ・環境変数（既存の投稿スクリプトと同じもの）
      WP_URL / WP_USERNAME / WP_APP_PASSWORD / DMM_API_ID / DMM_AFFILIATE_ID

■ 使い方
  python backfill_card_meta.py                # まず必ずドライラン（書き込まない）
  python backfill_card_meta.py --limit 20     # 20件だけ試す
  python backfill_card_meta.py --apply        # 実際に書き込む
  python backfill_card_meta.py --apply --sleep 1.0   # API間隔を1秒にして書き込む

■ 対象外
  DUGA / MGS など FANZA以外の作品（スラッグが duga-… / mgs-… 等）は
  DMM APIで検索できないため、自動的にスキップします。
"""

import argparse
import html
import json
import os
import re
import sys
import time
import urllib.parse
from pathlib import Path

import requests

# ----------------------------------------------------------------
# 設定
# ----------------------------------------------------------------
WP_URL          = os.environ.get('WP_URL', '').rstrip('/')
WP_USERNAME     = os.environ.get('WP_USERNAME', '')
WP_APP_PASSWORD = os.environ.get('WP_APP_PASSWORD', '')
DMM_API_ID       = os.environ.get('DMM_API_ID', '')
DMM_AFFILIATE_ID = os.environ.get('DMM_AFFILIATE_ID', '')

DMM_API_BASE = 'https://api.dmm.com/affiliate/v3'
# 品番を探すフロア（AV → 素人の順に試す）
DMM_FLOORS = [('digital', 'videoa'), ('digital', 'videoc')]

META_VOLUME     = '_onavi_volume'
META_CONTENT_ID = '_onavi_content_id'
META_MAKER      = '_onavi_maker'
META_DATE       = '_onavi_release_date'
ALL_META = (META_VOLUME, META_CONTENT_ID, META_MAKER, META_DATE)

# DMM側に見つからなかった品番の記録（毎回無駄に再検索しないため）
NOTFOUND_FILE = Path(__file__).with_name('backfill_notfound.json')

# FANZA以外のスラッグ接頭辞（これらはスキップ）
NON_FANZA_SLUG = re.compile(r'^(duga|mgs|sokmil|fc2|caribbean|heyzo)[-_]', re.I)

AFFILIATE_HREF_RE = re.compile(
    r'href=["\'](https?://al\.(?:fanza|dmm)\.co\.jp/[^"\']+)["\']', re.I)
CID_RE = re.compile(r'(?:[?&](?:id|cid)=|/cid=)([A-Za-z0-9_]+)')


# ----------------------------------------------------------------
# 純粋関数（ネットワークを使わない部分）
# ----------------------------------------------------------------
def parse_volume_minutes(raw) -> int:
    """'120' / '120分' / '02:00:00' などを分(int)に。取れなければ0。"""
    s = str(raw or '').strip()
    if not s:
        return 0
    if ':' in s:
        try:
            nums = [int(p) for p in s.split(':') if p.isdigit()]
        except ValueError:
            return 0
        if len(nums) == 3:
            return nums[0] * 60 + nums[1]
        if len(nums) == 2:
            return nums[0]
        return 0
    digits = ''.join(c for c in s if c.isdigit())
    return int(digits) if digits else 0


def cid_from_affiliate_url(url: str) -> str:
    """アフィリエイトURL（lurlに作品ページが入っている形）から品番を取り出す。"""
    try:
        outer = urllib.parse.urlsplit(html.unescape(url))
        lurl = urllib.parse.parse_qs(outer.query).get('lurl', [''])[0]
        target = urllib.parse.unquote(lurl) if lurl else html.unescape(url)
        m = CID_RE.search(target)
        return m.group(1).lower() if m else ''
    except Exception:
        return ''


def cid_candidates_from_post(post: dict) -> list:
    """記事から品番の候補を優先順に返す。"""
    cands = []

    # 1) 本文（edit contextのraw）のアフィリエイトリンク
    raw = ((post.get('content') or {}).get('raw')) or ''
    for m in AFFILIATE_HREF_RE.finditer(raw):
        cid = cid_from_affiliate_url(m.group(1))
        if cid and cid not in cands:
            cands.append(cid)

    # 2) メタに保存済みのアフィリエイトURL
    meta = post.get('meta') or {}
    aff = meta.get('_onavi_affiliate_url') if isinstance(meta, dict) else ''
    if aff:
        cid = cid_from_affiliate_url(aff)
        if cid and cid not in cands:
            cands.append(cid)

    # 3) スラッグ（FANZA以外の接頭辞は除外。WordPressが付けた -2, -3 は外した候補も試す）
    slug = (post.get('slug') or '').strip().lower()
    if slug and not NON_FANZA_SLUG.match(slug):
        for c in (slug, re.sub(r'-\d+$', '', slug)):
            c = c.strip('-')
            if c and re.fullmatch(r'[a-z0-9_]+', c) and c not in cands:
                cands.append(c)
    return cands


# ----------------------------------------------------------------
# DMM API
# ----------------------------------------------------------------
def fetch_dmm_item(cid: str, sleep_sec: float):
    """cidで1件検索し、(content_id, volume分, maker, 配信日) を返す。見つからなければNone。"""
    for service, floor in DMM_FLOORS:
        params = {
            'api_id': DMM_API_ID, 'affiliate_id': DMM_AFFILIATE_ID,
            'site': 'FANZA', 'service': service, 'floor': floor,
            'cid': cid, 'hits': 1, 'output': 'json',
        }
        for attempt in range(3):
            try:
                resp = requests.get(f'{DMM_API_BASE}/ItemList', params=params, timeout=15)
                data = resp.json()
                break
            except Exception as e:
                if attempt == 2:
                    print(f'   ⚠️ DMM APIエラー({cid}): {e}')
                    return None
                time.sleep(1.5 * (attempt + 1))
        time.sleep(sleep_sec)

        items = (data.get('result') or {}).get('items') or []
        if isinstance(items, dict):
            items = items.get('item', [])
        if not items:
            continue
        item = items[0]
        found_cid = (item.get('content_id') or '').lower()
        if found_cid and found_cid != cid.lower():
            continue  # 別作品が返ってきた場合は採用しない
        iteminfo = item.get('iteminfo') or {}
        maker = ((iteminfo.get('maker') or [{}])[0]).get('name', '')
        date_raw = str(item.get('date') or '')[:10]
        date = date_raw if re.fullmatch(r'\d{4}-\d{2}-\d{2}', date_raw) else ''
        return (found_cid or cid.lower(), parse_volume_minutes(item.get('volume')), maker, date)
    return None


# ----------------------------------------------------------------
# WordPress REST
# ----------------------------------------------------------------
def wp_auth():
    return (WP_USERNAME, WP_APP_PASSWORD)


def iter_posts():
    """全記事（公開・下書き・予約・非公開）を順に返す。"""
    page = 1
    while True:
        resp = requests.get(
            f'{WP_URL}/wp-json/wp/v2/posts',
            params={
                'per_page': 100, 'page': page, 'context': 'edit',
                'status': 'publish,draft,pending,future,private',
                '_fields': 'id,slug,status,meta,content',
            },
            auth=wp_auth(), timeout=60,
        )
        if resp.status_code == 400:  # 最終ページの次
            return
        resp.raise_for_status()
        batch = resp.json()
        if not batch:
            return
        for p in batch:
            yield p
        total_pages = int(resp.headers.get('X-WP-TotalPages', page))
        if page >= total_pages:
            return
        page += 1


def update_post_meta(post_id: int, meta: dict) -> bool:
    resp = requests.post(
        f'{WP_URL}/wp-json/wp/v2/posts/{post_id}',
        json={'meta': meta}, auth=wp_auth(), timeout=60,
    )
    if resp.status_code >= 400:
        print(f'   ❌ 更新失敗 id={post_id}: HTTP {resp.status_code} {resp.text[:150]}')
        return False
    # メタが未登録だとWordPressは黙って無視するため、返り値で保存を確認する
    saved = (resp.json().get('meta') or {})
    return all(str(saved.get(k, '')) == str(v) for k, v in meta.items())


# ----------------------------------------------------------------
# メイン
# ----------------------------------------------------------------
def load_notfound() -> set:
    try:
        return set(json.loads(NOTFOUND_FILE.read_text(encoding='utf-8')))
    except Exception:
        return set()


def save_notfound(s: set):
    NOTFOUND_FILE.write_text(json.dumps(sorted(s), ensure_ascii=False, indent=0), encoding='utf-8')


def main():
    ap = argparse.ArgumentParser(description='過去記事の再生時間・品番・メーカーを一括補完')
    ap.add_argument('--apply', action='store_true', help='実際に書き込む（指定なしはドライラン）')
    ap.add_argument('--limit', type=int, default=0, help='処理する記事数の上限（0=無制限）')
    ap.add_argument('--sleep', type=float, default=0.5, help='DMM API呼び出しの間隔（秒）')
    args = ap.parse_args()

    required = (
        ('WP_URL', WP_URL), ('WP_USERNAME', WP_USERNAME),
        ('WP_APP_PASSWORD', WP_APP_PASSWORD),
        ('DMM_API_ID', DMM_API_ID), ('DMM_AFFILIATE_ID', DMM_AFFILIATE_ID),
    )
    missing = [name for name, val in required if not val]
    if missing:
        print('❌ 環境変数が未設定です: ' + ', '.join(missing))
        sys.exit(1)

    mode = '書き込みモード' if args.apply else 'ドライラン（書き込みません）'
    print(f'🔁 過去記事の補完を開始します — {mode}')

    notfound = load_notfound()
    stats = dict(total=0, complete=0, skipped_nonfanza=0, no_cid=0, notfound=0,
                 would_update=0, updated=0, failed=0)
    processed = 0

    for post in iter_posts():
        stats['total'] += 1
        meta = post.get('meta') if isinstance(post.get('meta'), dict) else {}
        have = {k: str(meta.get(k, '') or '').strip() for k in ALL_META}

        if all(have.values()):
            stats['complete'] += 1
            continue

        cands = cid_candidates_from_post(post)
        if not cands:
            if NON_FANZA_SLUG.match((post.get('slug') or '')):
                stats['skipped_nonfanza'] += 1
            else:
                stats['no_cid'] += 1
            continue

        if args.limit and processed >= args.limit:
            break
        processed += 1

        result = None
        for cid in cands:
            if cid in notfound:
                continue
            result = fetch_dmm_item(cid, args.sleep)
            if result:
                break
            notfound.add(cid)
        if not result:
            stats['notfound'] += 1
            print(f'  ・id={post["id"]} slug={post.get("slug")}: DMMで見つからずスキップ')
            continue

        content_id, volume, maker, rel_date = result
        new_meta = {}
        if not have[META_CONTENT_ID] and content_id:
            new_meta[META_CONTENT_ID] = content_id
        if not have[META_VOLUME] and volume > 0:
            new_meta[META_VOLUME] = str(volume)
        if not have[META_MAKER] and maker:
            new_meta[META_MAKER] = maker
        if not have[META_DATE] and rel_date:
            new_meta[META_DATE] = rel_date

        if not new_meta:
            continue

        label = ' / '.join(f'{k.replace("_onavi_", "")}={v}' for k, v in new_meta.items())
        if not args.apply:
            stats['would_update'] += 1
            print(f'  [dry] id={post["id"]} {label}')
            continue

        if update_post_meta(post['id'], new_meta):
            stats['updated'] += 1
            print(f'  ✅ id={post["id"]} {label}')
        else:
            stats['failed'] += 1

    save_notfound(notfound)

    print('\n===== 結果 =====')
    print(f'  記事の総数            : {stats["total"]}')
    print(f'  すでに4項目そろっている: {stats["complete"]}')
    print(f'  FANZA以外でスキップ    : {stats["skipped_nonfanza"]}')
    print(f'  品番を特定できず       : {stats["no_cid"]}')
    print(f'  DMMで見つからず        : {stats["notfound"]}')
    if args.apply:
        print(f'  更新に成功             : {stats["updated"]}')
        print(f'  更新に失敗             : {stats["failed"]}')
        if stats['failed']:
            print('  ※失敗が多い場合は、PHPスニペット(N-2)が有効か確認してください。')
    else:
        print(f'  更新予定               : {stats["would_update"]}')
        print('  → 問題なければ --apply を付けて再実行してください。')


if __name__ == '__main__':
    main()
