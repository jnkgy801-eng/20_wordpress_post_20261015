# -*- coding: utf-8 -*-
"""
🔌 IndexNow 送信モジュール（共通）
--------------------------------------------------------------
wordpress_blog_poster.py / wordpress_pickup_poster.py /
wordpress_reserve_poster.py の3つから共通で使う。

IndexNowは、Bing・Yandex・Seznam.cz・Naver・Yep等が共同で対応している
プロトコルで、"このURLを更新/公開したので見に来てください" と1回HTTPで
知らせるだけで、対応する検索エンジンにまとめて通知できる。
※ Googleは2024年時点でIndexNowに参加していないため、Google向けには
   効果がない（Googleには従来通りサイトマップ＋URL検査での
   手動リクエストが必要）。

--------------------------------------------------------------
✅ 事前準備（1回だけ）
--------------------------------------------------------------
1) 下の INDEXNOW_KEY の値（ランダム生成済み）を、サイトのルート直下に
   「{キー}.txt」というファイル名で、中身がキー文字列そのものだけの
   ファイルとして設置する必要がある。
   例: https://adult-navi20.site/a8ad6de35f29dc283f3e3a9b4b6bb89b.txt
       にアクセスすると、中身が
       a8ad6de35f29dc283f3e3a9b4b6bb89b
       とだけ表示される状態にする。

   WordPressにFTPでファイルを置けない場合、「コードスニペット」で
   このキーファイルを仮想的に返すPHPコードを追加する方法がある
   （別途お渡しするPHPスニペットにこの処理を含めています）。

2) 環境変数 INDEXNOW_KEY にも同じ値を設定しておく（Secretsに登録）。
   未設定の場合はこのファイル内のデフォルト値を使う。
"""

import os
import requests

INDEXNOW_ENDPOINT = 'https://api.indexnow.org/indexnow'
# デフォルト値。GitHub Secrets等で INDEXNOW_KEY を設定していればそちらを優先する。
INDEXNOW_KEY = os.environ.get('INDEXNOW_KEY', 'a8ad6de35f29dc283f3e3a9b4b6bb89b').strip()


def submit_url(site_url: str, page_url: str) -> bool:
    """公開されたページのURLを1件、IndexNowへ送信する。

    site_url: サイトのルートURL（例: 'https://adult-navi20.site'）。
              WP_URL環境変数の値をそのまま渡せばよい。
    page_url: 実際に公開されたページの完全なURL。

    戻り値: 送信が成功した（200/202が返ってきた）かどうか。
    失敗してもスクリプト全体を止めたくないため、例外は投げず
    Falseを返すだけにしている。
    """
    if not page_url:
        return False

    host = site_url.replace('https://', '').replace('http://', '').rstrip('/')

    try:
        resp = requests.post(
            INDEXNOW_ENDPOINT,
            json={
                'host': host,
                'key': INDEXNOW_KEY,
                'keyLocation': f'{site_url.rstrip("/")}/{INDEXNOW_KEY}.txt',
                'urlList': [page_url],
            },
            headers={'Content-Type': 'application/json; charset=utf-8'},
            timeout=10,
        )
        if resp.status_code in (200, 202):
            print(f'    🔔 IndexNowへ送信しました: {page_url}')
            return True
        print(f'    ⚠️ IndexNow送信が失敗しました（status={resp.status_code}）: {resp.text[:200]}')
        return False
    except Exception as e:
        print(f'    ⚠️ IndexNow送信エラー: {e}')
        return False
