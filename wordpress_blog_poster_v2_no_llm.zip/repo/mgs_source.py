# -*- coding: utf-8 -*-
"""
🟢 MGStage（MGSアフィリエイト）取得・正規化モジュール

MGSには公式APIが無いため、一覧ページ → 商品詳細ページの2段階でスクレイピングする。
wordpress_blog_poster.py から次のインターフェースで呼び出される。
    fetch_and_parse_mgs_products(limit, sleep_seconds) -> list[dict]
    （返り値は既にポスター共通のproduct辞書。ポスター側のparse_itemは恒等関数）

環境変数:
    MGS_AFF_ID            : MGSアフィリエイトID（必須）
    MGS_SORT              : 一覧の並び順（デフォルト ranking。新着なら new を試す）
    MGS_LIST_URL          : 一覧ページURLを直接指定（任意。指定時は最優先で試す）
    MGS_MAX_DETAIL_FETCH  : 詳細ページを取得する最大件数（デフォルト 30。アクセス過多防止）
    POSTED_HISTORY_FILE   : 投稿履歴JSON（投稿済みは詳細取得をスキップしてアクセスを減らす）

⚠️ GitHub ActionsのIPはMGS側のBot対策で403になることがある。
   その場合は例外で失敗させる（成功扱いで空振りさせない）。セルフホストランナー等を検討すること。
"""
from __future__ import annotations

import html as html_lib
import json
import os
import random
import re
import time
from pathlib import Path
from typing import Any, Optional

import requests

from real_summary import pick_summary, clean_summary, debug_log

# MGSのBot対策(WAF)はrequests特有のTLS指紋で403にすることがあるため、
# curl_cffi があれば実ブラウザ(chrome)のTLS指紋で通信する。無ければ通常のrequestsにフォールバック。
try:
    from curl_cffi import requests as _cffi_requests
    _USING_CURL_CFFI = True
except ImportError:
    _cffi_requests = None
    _USING_CURL_CFFI = False

Product = dict[str, Any]

MGS_BASE_URL = 'https://www.mgstage.com'
_REQUEST_TIMEOUT_SEC = 15
_LIST_MAX_PAGES = 3   # cSearch系の一覧で辿る最大ページ数
_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
    ),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'ja,en-US;q=0.9,en;q=0.8',
    'Referer': MGS_BASE_URL + '/',
}
# 年齢確認ページを通過するためのCookie。仕様変更で効かなくなったら、
# ブラウザで年齢確認後のCookieを確認してここを更新する。
_AGE_COOKIES = {'adc': '1'}

_PRODUCT_LINK_RE = re.compile(
    r'''href=["'](?:https?://www\.mgstage\.com)?/product/product_detail/([^/"'?#]+)/?[^"']*["']'''
)
_TAG_RE = re.compile(r'<[^>]+>')


# ================================================================
# 🔧 内部ユーティリティ
# ================================================================

def _load_aff_id() -> str:
    aff_id = os.environ.get('MGS_AFF_ID', '').strip()
    if not aff_id:
        raise RuntimeError('環境変数 MGS_AFF_ID が設定されていません。')
    return aff_id


def _build_session():
    session = _cffi_requests.Session(impersonate='chrome') if _USING_CURL_CFFI else requests.Session()
    session.headers.update(_HEADERS)
    session.cookies.update(_AGE_COOKIES)
    return session


def _get(session, url: str):
    """GETし、4xx/5xxなら診断情報（最終URL・本文冒頭）付きで HTTPError を投げる。"""
    resp = session.get(url, timeout=_REQUEST_TIMEOUT_SEC, allow_redirects=True)
    if resp.status_code >= 400:
        snippet = resp.text[:200].replace('\n', ' ') if resp.text else '(本文なし)'
        raise RuntimeError(f'HTTP {resp.status_code} {resp.reason}（最終URL: {resp.url} / 本文冒頭: {snippet}）')
    return resp


def _polite_sleep(base_seconds: float) -> None:
    """サーバー負荷とBot判定を避けるため、ゆらぎ付きで待機する。"""
    if base_seconds > 0:
        time.sleep(base_seconds * random.uniform(0.8, 1.4))


def _strip_tags(fragment: str) -> str:
    return html_lib.unescape(_TAG_RE.sub('', fragment)).strip()


def _meta_content(page_html: str, prop: str) -> str:
    m = re.search(
        rf'''<meta[^>]+(?:property|name)=["']{re.escape(prop)}["'][^>]+content=["']([^"']+)["']''',
        page_html, re.IGNORECASE,
    )
    return html_lib.unescape(m.group(1)).strip() if m else ''


def _row_html(page_html: str, label: str) -> str:
    """商品情報テーブルの <th>label</th><td>…</td> の td 内HTMLを返す（無ければ空文字）。"""
    m = re.search(
        rf'<th[^>]*>\s*{re.escape(label)}\s*[：:]?\s*</th>\s*<td[^>]*>(.*?)</td>',
        page_html, re.DOTALL,
    )
    return m.group(1) if m else ''


def _row_links(page_html: str, label: str) -> list[str]:
    """テーブル行内のリンクテキスト一覧（出演者・ジャンル用）。"""
    block = _row_html(page_html, label)
    names: list[str] = []
    for inner in re.findall(r'<a[^>]*>(.*?)</a>', block, re.DOTALL):
        text = _strip_tags(inner)
        if text and text not in names:
            names.append(text)
    return names


def _row_text(page_html: str, label: str) -> str:
    block = _row_html(page_html, label)
    links = _row_links(page_html, label)
    return links[0] if links else _strip_tags(block)


def _normalize_date(raw: str) -> str:
    """'2026/07/20' 等を 'YYYY-MM-DD' に統一。ポスターの期間フィルターが読める形式にするため。"""
    m = re.search(r'(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})', raw or '')
    if not m:
        return ''
    year, month, day = (int(g) for g in m.groups())
    try:
        return f'{year:04d}-{month:02d}-{day:02d}'
    except ValueError:
        return ''


def _load_posted_ids() -> set[str]:
    """投稿済みキーを読む。詳細ページを無駄に取得しないための最適化（失敗しても致命的ではない）。"""
    path = Path(os.environ.get('POSTED_HISTORY_FILE', 'outputs/posted_history.json'))
    if not path.exists():
        return set()
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return set(json.load(f).get('posted', []))
    except (OSError, ValueError) as e:
        print(f'  ⚠️ [MGS] 投稿履歴の読み込みに失敗（スキップ判定なしで続行）: {e}')
        return set()


# ================================================================
# 📃 一覧ページ → 商品コード収集
# ================================================================

def _candidate_list_urls() -> list[str]:
    sort = os.environ.get('MGS_SORT', '').strip() or 'ranking'
    candidates = [
        os.environ.get('MGS_LIST_URL', '').strip() or os.environ.get('MGS_RANKING_URL', '').strip(),
        f'{MGS_BASE_URL}/search/cSearch.php?sort={sort}',
        f'{MGS_BASE_URL}/ranking/',
    ]
    seen: set[str] = set()
    result: list[str] = []
    for url in candidates:
        if url and url not in seen:
            seen.add(url)
            result.append(url)
    return result


def _collect_product_codes(session, limit: int, sleep_seconds: float) -> list[str]:
    """一覧ページから商品コードを順序を保って重複なく集める。全候補URLが失敗したら RuntimeError。"""
    errors: list[str] = []
    for list_url in _candidate_list_urls():
        paginated = 'cSearch.php' in list_url
        codes: list[str] = []
        for page in range(1, (_LIST_MAX_PAGES if paginated else 1) + 1):
            url = list_url if page == 1 else f'{list_url}{"&" if "?" in list_url else "?"}page={page}'
            print(f'  [MGS] 一覧取得中: {url}')
            try:
                page_html = _get(session, url).text
            except Exception as e:  # requests / curl_cffi 双方の通信例外を拾う
                errors.append(f'{url}: {e}')
                print(f'  ❌ [MGS] 取得失敗: {e}')
                break
            before = len(codes)
            for code in _PRODUCT_LINK_RE.findall(page_html):
                if code not in codes:
                    codes.append(code)
            if len(codes) == before or len(codes) >= limit:
                break  # 新しい商品が増えない＝最終ページ
            _polite_sleep(sleep_seconds)
        if codes:
            print(f'  ✅ [MGS] 商品コードを{len(codes[:limit])}件取得（採用URL: {list_url}）')
            return codes[:limit]
        print('  ⚠️ [MGS] 商品リンクが見つかりませんでした。次の候補URLを試します。')

    raise RuntimeError(
        'MGSの一覧ページから商品を取得できませんでした。実行環境のIPがBot対策でブロックされている可能性があります'
        '（セルフホストランナー等を検討）。試行結果: ' + ' | '.join(errors or ['リンク0件'])
    )


# ================================================================
# 🧩 詳細ページ → product辞書
# ================================================================

def parse_mgs_product(detail_url: str, page_html: str, aff_id: str) -> Optional[Product]:
    """商品詳細HTMLからproduct辞書を作る。タイトルが取れない場合は None。"""
    code_match = _PRODUCT_LINK_RE.search(f'href="{detail_url}"')
    if not code_match:
        return None
    code = code_match.group(1)

    title = _meta_content(page_html, 'og:title')
    if not title:
        m = re.search(r'<title>([^<]+)</title>', page_html)
        title = html_lib.unescape(m.group(1)).strip() if m else ''
    title = title.split('|')[0]
    title = re.sub(r'\s*MGS動画.*$', '', title).rstrip(' -–—|・').strip()
    if not title:
        return None

    price_num: Optional[int] = None
    price_str = ''
    m = (re.search(r'class="[^"]*price[^"]*"[^>]*>\s*([0-9][0-9,]*)\s*円', page_html)
         or re.search(r'([0-9][0-9,]{2,})\s*円', page_html))
    if m:
        digits = m.group(1).replace(',', '')
        if digits.isdigit():
            price_num = int(digits)
            price_str = f'¥{price_num:,}'

    # サンプル画像（cap_e_N_*.jpg がMGSの拡大サンプル画像の命名）
    sample_images: list[str] = []
    for url in re.findall(r'''href=["'](https?://image\.mgstage\.com/[^"']+?/cap_e_\d+_[^"']+?\.jpg)["']''', page_html):
        if url not in sample_images:
            sample_images.append(url)
    sample_images = sample_images[:8]

    package_image = _meta_content(page_html, 'og:image') or (sample_images[0] if sample_images else '')

    sep = '&' if '?' in detail_url else '?'
    released = (_normalize_date(_row_text(page_html, '配信開始日'))
                or _normalize_date(_row_text(page_html, '商品発売日')))

    # 公式の紹介文（実データ）。ページ内の紹介文欄 → メタディスクリプションの順で探す
    summary = clean_summary(
        _row_text(page_html, '紹介文') or _row_text(page_html, '商品説明')
        or _meta_content(page_html, 'og:description') or _meta_content(page_html, 'description')
    )
    debug_log('mgs', {'detail_url': detail_url}, summary)

    return {
        'content_id':       f'mgs-{code.lower()}',
        'title':            title,
        'affiliate_url':    f'{detail_url}{sep}aff={aff_id}',
        'price':            price_str,
        'price_num':        price_num,
        'genres':           _row_links(page_html, 'ジャンル'),
        'maker':            _row_text(page_html, 'メーカー'),
        'actors':           _row_links(page_html, '出演')[:3],
        'review_avg':       None,
        'review_count':     None,
        'package_image':    package_image,
        'sample_images':    sample_images,
        'sample_movie_url': '',
        'series':           _row_text(page_html, 'シリーズ'),
        'label':            _row_text(page_html, 'レーベル'),
        'director':         '',
        'real_summary':     summary,
        'date':             released,  # 取得できない場合は空（ポスター側で期間フィルターをスキップ）
        'source':           'mgs',
    }


# ================================================================
# 🌐 公開API
# ================================================================

def fetch_and_parse_mgs_products(limit: int = 100, sleep_seconds: float = 1.0) -> list[Product]:
    """一覧から商品を集め、未投稿のものだけ詳細ページを取得して正規化したproductのリストを返す。"""
    aff_id = _load_aff_id()
    max_detail = max(1, int(os.environ.get('MGS_MAX_DETAIL_FETCH', '30')))

    session = _build_session()
    try:
        # トップに先にアクセスしてCookie/セッションを温める（失敗しても致命的ではない）
        session.get(MGS_BASE_URL + '/', timeout=_REQUEST_TIMEOUT_SEC)
    except Exception as e:  # requests / curl_cffi 双方の通信例外を拾う
        print(f'  ⚠️ [MGS] トップページへの疎通確認に失敗: {e}')

    codes = _collect_product_codes(session, limit, sleep_seconds)
    posted_ids = _load_posted_ids()

    products: list[Product] = []
    failures = 0
    skipped_posted = 0
    for code in codes:
        if len(products) >= max_detail:
            break
        if f'mgs-{code.lower()}' in posted_ids:
            skipped_posted += 1
            continue

        detail_url = f'{MGS_BASE_URL}/product/product_detail/{code}/'
        _polite_sleep(sleep_seconds)
        try:
            page_html = _get(session, detail_url).text
        except Exception as e:  # requests / curl_cffi 双方の通信例外を拾う
            failures += 1
            print(f'    ⚠️ [MGS] 詳細ページ取得失敗（スキップ）: {detail_url} ({e})')
            continue

        try:
            product = parse_mgs_product(detail_url, page_html, aff_id)
        except Exception as e:  # HTML構造変更で想定外の例外が出ても1件の失敗で全体を止めない
            failures += 1
            print(f'    ⚠️ [MGS] 解析失敗（スキップ）: {detail_url} ({e})')
            continue
        if product:
            products.append(product)

    print(f'  ✅ [MGS] {len(products)}件を解析（投稿済みスキップ {skipped_posted}件・失敗 {failures}件）')
    if not products and failures:
        raise RuntimeError(f'MGSの詳細ページを1件も取得/解析できませんでした（失敗 {failures}件）。')
    return products
