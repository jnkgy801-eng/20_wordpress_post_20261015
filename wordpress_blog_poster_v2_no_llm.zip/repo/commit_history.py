# -*- coding: utf-8 -*-
"""
投稿履歴(outputs/)をコミット＆pushする補助スクリプト。

・bash構文に依存しない（Windowsのセルフホストランナーでも動かすためPythonで実装）
・outputs/posted_history.json が他の実行と競合した場合は、両方の履歴を和集合でマージして解決する
  （履歴が失われると同じ作品を重複投稿してしまうため）
・pushが他の更新と競合して拒否された場合は、取り込み直して再試行する

使い方: python commit_history.py [コミットメッセージ用ラベル]
"""
from __future__ import annotations

import datetime
import json
import os
import shutil
import subprocess
import sys

HISTORY_PATH = 'outputs/posted_history.json'
_RECENT_OPENINGS_KEEP = 8   # wordpress_blog_poster.py の _RECENT_OPENINGS_KEEP と揃える
_MAX_PUSH_ATTEMPTS = 3


def _git(*args: str, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(['git', *args], check=check, text=True, capture_output=True, encoding='utf-8')


def _merge_history(base_json: str, ours_json: str) -> str:
    """2つの履歴JSON文字列をマージする。postedは和集合、recent_openingsは重複除去して末尾N件。"""
    def load(text: str) -> dict:
        try:
            data = json.loads(text)
            return data if isinstance(data, dict) else {}
        except ValueError:
            return {}

    a, b = load(base_json), load(ours_json)
    merged = {**a, **b}
    merged['posted'] = sorted(set(a.get('posted', [])) | set(b.get('posted', [])))
    openings = list(a.get('recent_openings', []))
    openings += [o for o in b.get('recent_openings', []) if o not in openings]
    merged['recent_openings'] = openings[-_RECENT_OPENINGS_KEEP:]
    return json.dumps(merged, ensure_ascii=False, indent=2)


def _rebase_onto_remote(branch: str) -> None:
    """origin/branch の上にコミットを載せ替える。履歴JSONの競合だけは自動解決する。"""
    _git('fetch', 'origin', branch)
    result = _git('rebase', f'origin/{branch}', check=False)
    while result.returncode != 0:
        conflicted = _git('diff', '--name-only', '--diff-filter=U').stdout.split()
        if conflicted != [HISTORY_PATH]:
            _git('rebase', '--abort', check=False)
            raise RuntimeError(f'履歴JSON以外のファイルで競合したため中断しました: {conflicted}\n{result.stderr}')
        # rebase中は stage2 = origin側（他の実行の更新）, stage3 = 今回の更新
        remote_side = _git('show', f':2:{HISTORY_PATH}').stdout
        our_side = _git('show', f':3:{HISTORY_PATH}').stdout
        with open(HISTORY_PATH, 'w', encoding='utf-8') as f:
            f.write(_merge_history(remote_side, our_side))
        _git('add', HISTORY_PATH)
        print('履歴JSONの競合を和集合マージで解決しました。')
        # エディタを開かずに続行する
        result = subprocess.run(
            ['git', '-c', 'core.editor=true', 'rebase', '--continue'],
            text=True, capture_output=True, encoding='utf-8',
        )


def _clear_stale_rebase_state() -> None:
    """前回の失敗で残ったrebase中断状態(.git/rebase-merge 等)を削除する。
    セルフホストランナーは作業フォルダが使い回されるため、残っていると次回の rebase が必ず失敗する。
    作業ツリーのファイルには触れない（今回の更新分を失わないため、git rebase --abort は使わない）。"""
    git_dir = _git('rev-parse', '--git-dir').stdout.strip()
    for name in ('rebase-merge', 'rebase-apply'):
        path = os.path.join(git_dir, name)
        if os.path.isdir(path):
            print(f'前回の中断したrebase状態を削除します: {path}')
            shutil.rmtree(path, ignore_errors=True)


def main() -> int:
    label = f' {sys.argv[1]}' if len(sys.argv) > 1 else ''
    branch = os.environ.get('GITHUB_REF_NAME', 'main')
    os.makedirs('outputs', exist_ok=True)
    try:
        _clear_stale_rebase_state()
        _git('config', 'user.name', 'github-actions[bot]')
        _git('config', 'user.email', 'github-actions[bot]@users.noreply.github.com')
        _git('add', '-A', 'outputs/')

        # returncode 0 = ステージされた差分なし
        if _git('diff', '--staged', '--quiet', check=False).returncode == 0:
            print('コミットする変更はありません。')
            return 0

        stamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        _git('commit', '-m', f'WordPress自動投稿 履歴更新{label} ({stamp})')

        for attempt in range(1, _MAX_PUSH_ATTEMPTS + 1):
            _rebase_onto_remote(branch)
            push = _git('push', 'origin', f'HEAD:{branch}', check=False)
            if push.returncode == 0:
                print('履歴をコミットしてpushしました。')
                return 0
            print(f'push失敗（{attempt}/{_MAX_PUSH_ATTEMPTS}回目）。取り込み直して再試行します: {push.stderr.strip()[:200]}')
        print('エラー: pushが繰り返し失敗しました。')
        return 1
    except FileNotFoundError:
        print('エラー: git が見つかりません。Git for Windows をインストールしてください。')
        return 1
    except subprocess.CalledProcessError as e:
        _git('rebase', '--abort', check=False)  # 作業コピーを中途半端な状態で残さない
        print(f'エラー: git {" ".join(e.cmd[1:])} に失敗しました。\n{e.stdout}\n{e.stderr}')
        return 1
    except RuntimeError as e:
        print(f'エラー: {e}')
        return 1


if __name__ == '__main__':
    sys.exit(main())
