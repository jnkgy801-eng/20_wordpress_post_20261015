# -*- coding: utf-8 -*-
"""
AI生成を使わない「データ駆動ハブページ」の本文ビルダー。

方針:
  文章をAIで量産するのではなく、APIで取れる実データ（価格・通常価格・収録時間・レビュー・配信日）
  から「割引率」「1分あたりの単価」などを計算し、比較表と目的別の選び方として整理する。
  書いてあることはすべてデータから機械的に導いた事実なので、捏造がなく、毎日更新でき、
  1作品1記事の薄いページとは違う「まとめ・比較」としての価値を持つ。

純粋関数のみ（ネットワーク・環境変数に依存しない）なのでオフラインでテストできる。
"""
import datetime
from xml.sax.saxutils import escape

MIN_REVIEWS_FOR_PICK = 3   # 「高評価」として推すのに必要な最低レビュー件数
MIN_MINUTES_FOR_UNIT = 30  # 円/分を出す最低収録時間（短い作品で単価が極端になるのを避ける）


def volume_minutes(raw) -> int:
    """DMM APIのvolume（収録時間）を分にする。'120' / '120分' / '02:00:00' に対応。取れなければ0。"""
    s = str(raw or '').strip()
    if not s:
        return 0
    if ':' in s:
        try:
            nums = [int(p) for p in s.split(':') if p.isdigit()]
        except ValueError:
            return 0
        if len(nums) == 3:
            return nums[0] * 60 + nums[1]
        if len(nums) == 2:
            return nums[0]
        return 0
    digits = ''.join(c for c in s if c.isdigit())
    return int(digits) if digits else 0


def discount_pct(price_num, list_price_num) -> int:
    """通常価格より現在価格が安いときだけ割引率(%)を返す。それ以外は0。"""
    if price_num and list_price_num and list_price_num > price_num:
        return int(round((1 - price_num / list_price_num) * 100))
    return 0


def _yen(n) -> str:
    return f'¥{int(n):,}'


def _date_label(raw: str) -> str:
    raw = (raw or '').strip()
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d'):
        try:
            d = datetime.datetime.strptime(raw[:19], fmt)
            return f'{d.year}/{d.month}/{d.day}'
        except ValueError:
            continue
    return ''


def _unit_price(p: dict):
    mins, price = p.get('volume') or 0, p.get('price_num')
    if price and mins >= MIN_MINUTES_FOR_UNIT:
        return price / mins
    return None


def _link(p: dict) -> str:
    return f'<a href="{escape(p["affiliate_url"])}">{escape(p["title"])}</a>'


def _short(title: str, n: int = 28) -> str:
    return title if len(title) <= n else title[:n] + '…'


def compute_picks(products: list) -> list:
    """目的別の「選び方」を、データから機械的に決める。[(見出し, 作品, 根拠の文)] を返す。"""
    picks = []
    with_price = [p for p in products if p.get('price_num')]
    if with_price:
        p = min(with_price, key=lambda x: x['price_num'])
        picks.append(('とにかく安く選ぶなら', p, f'現在{_yen(p["price_num"])}で、このページの中では最安です。'))
    disc = [p for p in products if (p.get('discount_pct') or 0) > 0]
    if disc:
        p = max(disc, key=lambda x: x['discount_pct'])
        picks.append(('割引率で選ぶなら', p,
                      f'通常{_yen(p["list_price_num"])}が{_yen(p["price_num"])}で、{p["discount_pct"]}%OFFです。'))
    unit = [(p, _unit_price(p)) for p in products if _unit_price(p)]
    if unit:
        p, u = min(unit, key=lambda x: x[1])
        picks.append(('1分あたりの単価で選ぶなら', p,
                      f'収録{p["volume"]}分で、1分あたり約{u:.1f}円です。'))
    longest = [p for p in products if (p.get('volume') or 0) > 0]
    if longest:
        p = max(longest, key=lambda x: x['volume'])
        picks.append(('たっぷり長く楽しむなら', p, f'収録時間は{p["volume"]}分で、このページの中では最長です。'))
    rated = [p for p in products if p.get('review_avg') and (p.get('review_count') or 0) >= MIN_REVIEWS_FOR_PICK]
    if rated:
        p = max(rated, key=lambda x: (x['review_avg'], x['review_count']))
        picks.append(('レビュー評価で選ぶなら', p,
                      f'レビュー平均{p["review_avg"]}（{p["review_count"]}件）で、{MIN_REVIEWS_FOR_PICK}件以上の中では最高です。'))
    dated = [p for p in products if _date_label(p.get('date', ''))]
    if dated:
        p = max(dated, key=lambda x: x['date'])
        picks.append(('いちばん新しい作品は', p, f'配信日は{_date_label(p["date"])}です。'))
    return picks


def _summary_lines(products: list, mode: str) -> list:
    lines = [f'このページでは{len(products)}作品を比較しています。']
    rated = [p for p in products if p.get('review_avg')]
    if rated:
        lines.append(f'うちレビューが付いている作品は{len(rated)}本です。')
    disc = [p for p in products if (p.get('discount_pct') or 0) > 0]
    if disc:
        avg = sum(p['discount_pct'] for p in disc) / len(disc)
        best = max(disc, key=lambda x: x['discount_pct'])
        lines.append(f'割引中は{len(disc)}本、平均割引率は約{avg:.0f}%、'
                     f'最大は{best["discount_pct"]}%OFFの「{escape(_short(best["title"]))}」です。')
    dates = sorted(_date_label(p.get('date', '')) for p in products if _date_label(p.get('date', '')))
    if mode == 'new' and dates:
        lines.append(f'配信日は{dates[0]}〜{dates[-1]}の範囲です。')
    return lines


def _table(products: list, show_discount: bool) -> str:
    th = ('<th>#</th><th>作品</th><th>価格</th>' + ('<th>割引</th>' if show_discount else '')
          + '<th>収録</th><th>円/分</th><th>レビュー</th><th>配信日</th>')
    rows = []
    for i, p in enumerate(products, start=1):
        u = _unit_price(p)
        price = _yen(p['price_num']) if p.get('price_num') else '-'
        if show_discount and p.get('discount_pct'):
            price = f'<s>{_yen(p["list_price_num"])}</s> {price}'
        cells = [str(i), _link(p), price]
        if show_discount:
            cells.append(f'{p["discount_pct"]}%OFF' if p.get('discount_pct') else '-')
        cells += [
            f'{p["volume"]}分' if p.get('volume') else '-',
            f'{u:.1f}' if u else '-',
            f'{p["review_avg"]}（{p["review_count"]}）' if p.get('review_avg') and p.get('review_count') else '-',
            _date_label(p.get('date', '')) or '-',
        ]
        rows.append('<tr>' + ''.join(f'<td>{c}</td>' for c in cells) + '</tr>')
    return ('<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:13px;">'
            f'<thead><tr>{th}</tr></thead><tbody>{"".join(rows)}</tbody></table></div>')


def _card(p: dict, rank: int) -> str:
    title, url, img = escape(p['title']), escape(p['affiliate_url']), escape(p.get('package_image', ''))
    facts = []
    if p.get('price_num'):
        price = _yen(p['price_num'])
        if p.get('discount_pct'):
            price = f'<s>{_yen(p["list_price_num"])}</s> {price}（{p["discount_pct"]}%OFF）'
        facts.append(price)
    if p.get('volume'):
        facts.append(f'収録{p["volume"]}分')
    if p.get('review_avg') and p.get('review_count'):
        facts.append(f'レビュー{p["review_avg"]}（{p["review_count"]}件）')
    if _date_label(p.get('date', '')):
        facts.append(f'配信{_date_label(p["date"])}')
    genres = '・'.join(escape(g) for g in (p.get('genres') or [])[:4])
    return f'''
<div style="display:flex;gap:14px;align-items:flex-start;margin:0 0 20px;padding-bottom:16px;border-bottom:1px solid #333;">
  <div style="flex:0 0 auto;font-size:20px;font-weight:bold;min-width:32px;">{rank}</div>
  <a href="{url}" style="flex:0 0 auto;display:block;"><img src="{img}" alt="{title}" loading="lazy" style="width:120px;height:120px;object-fit:cover;border-radius:6px;display:block;"></a>
  <div style="flex:1 1 auto;">
    <a href="{url}" style="font-weight:bold;font-size:15px;text-decoration:none;">{title}</a>
    {f'<div style="margin-top:6px;font-size:13px;">{" / ".join(facts)}</div>' if facts else ''}
    {f'<div style="margin-top:4px;font-size:12px;color:#b3b3b3;">{genres}</div>' if genres else ''}
    <div style="margin-top:8px;"><a href="{url}" style="display:inline-block;padding:6px 14px;background:#cc2222;color:#fff;border-radius:999px;font-size:12px;text-decoration:none;">販売ページで詳細を見る（PR）</a></div>
  </div>
</div>'''


def build_data_body(products: list, mode: str, now_jst: datetime.datetime, label: str = '') -> str:
    """ハブページ本文のHTMLを返す。mode は ranking / genre / sale / new。"""
    stamp = f'{now_jst.month}月{now_jst.day}日 {now_jst.hour}時'
    show_discount = any((p.get('discount_pct') or 0) > 0 for p in products)
    head = (f'<p>（PR）本ページはアフィリエイト広告を含みます。価格・割引は{stamp}時点のFANZA掲載情報で、'
            '予告なく変わることがあります。購入前に販売ページで最新の価格をご確認ください。</p>')
    summary = '<h2>このページのポイント</h2><p>' + '</p><p>'.join(_summary_lines(products, mode)) + '</p>'
    table = '<h2>比較表</h2>' + _table(products, show_discount)
    picks = compute_picks(products)
    picks_html = ''
    if picks:
        items = ''.join(
            f'<li><strong>{escape(h)}</strong>：{_link(p)}<br><span style="font-size:13px;">{escape(why)}</span></li>'
            for h, p, why in picks)
        picks_html = f'<h2>目的別の選び方</h2><ul>{items}</ul>'
    cards = '<h2>作品ごとの情報</h2>' + ''.join(_card(p, i) for i, p in enumerate(products, start=1))
    return '\n'.join([head, summary, table, picks_html, cards])


def build_hub_title(mode: str, label: str, content_label: str, now_jst: datetime.datetime, n: int,
                    window_days: int = 7) -> str:
    scope = f'{label}の' if label else ''
    if mode == 'sale':
        return f'【{now_jst.month}/{now_jst.day}更新】{content_label}{scope}セール中の人気作 割引率ランキングTOP{n}'
    if mode == 'new':
        return f'【{now_jst.month}/{now_jst.day}更新】{content_label}{scope}直近{window_days}日の新作まとめTOP{n}'
    return f'【{label}】{content_label}人気まとめTOP{n}'


def build_hub_excerpt(products: list, mode: str) -> str:
    top = '、'.join(_short(p['title'], 18) for p in products[:3])
    return f'{top} など{len(products)}作品を価格・収録時間・レビューで比較。'[:120]
