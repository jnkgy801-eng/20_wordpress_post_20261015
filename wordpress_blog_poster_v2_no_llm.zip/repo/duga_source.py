# -*- coding: utf-8 -*-
"""
🟣 DUGA（APEXアフィリエイト）取得・正規化モジュール

wordpress_blog_poster.py から次のインターフェースで呼び出される。
    fetch_duga_products(offset, hits, sort, release_start, release_end) -> list[dict]
    parse_duga_product(item) -> dict   # ポスター共通のproduct辞書に正規化

必要な環境変数:
    DUGA_APP_ID    : APEXアフィリエイトのアプリケーションID（必須）
    DUGA_AGENT_ID  : エージェントID（必須）
    DUGA_BANNER_ID : バナーID（任意・デフォルト 01）

※ DUGA APIのレスポンス項目名はバージョン/アカウントで揺れるため、
  取得できない項目は空値にフォールバックし、処理は止めない。
"""
from __future__ import annotations

import datetime
import hashlib
import os
import re
import time
from typing import Any, Optional

import requests

from real_summary import pick_summary, clean_summary, debug_log

Product = dict[str, Any]

DUGA_API_BASE = 'http://affapi.duga.jp/search'
DUGA_API_VERSION = '1.2'
_MAX_HITS_PER_REQUEST = 100   # DUGA APIの1リクエストあたり取得上限
_REQUEST_TIMEOUT_SEC = 15
_MAX_RETRIES = 3
_RETRY_WAIT_SEC = 2.0


class DugaConfigError(RuntimeError):
    """認証情報の未設定など、設定起因のエラー。"""


# ================================================================
# 🔧 内部ユーティリティ
# ================================================================

def _load_credentials() -> tuple[str, str, str]:
    """認証情報は呼び出し時に読む（import時に落とさず、SOURCE=duga の時だけ検証するため）。"""
    app_id = os.environ.get('DUGA_APP_ID', '').strip()
    agent_id = os.environ.get('DUGA_AGENT_ID', '').strip()
    banner_id = os.environ.get('DUGA_BANNER_ID', '').strip() or '01'
    if not app_id or not agent_id:
        raise DugaConfigError('環境変数 DUGA_APP_ID / DUGA_AGENT_ID が設定されていません。')
    return app_id, agent_id, banner_id


def _parse_date_str(raw: Any) -> Optional[datetime.date]:
    """'2026/07/20' '2026-07-20' '20260720' '2026-07-20 10:00:00' のいずれかを date に変換。"""
    if not raw:
        return None
    text = str(raw).strip().split(' ')[0].split('T')[0]
    for fmt in ('%Y/%m/%d', '%Y-%m-%d', '%Y%m%d'):
        try:
            return datetime.datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def _extract_date(item: Product) -> Optional[datetime.date]:
    """配信開始日（opendate）を優先し、無ければ発売日（releasedate）を使う。"""
    for key in ('opendate', 'releasedate', 'date'):
        parsed = _parse_date_str(item.get(key))
        if parsed:
            return parsed
    return None


def _to_https(url: Any) -> str:
    """画像URLを https に正規化する（WordPress側の混在コンテンツ警告を避けるため）。"""
    if not url or not isinstance(url, str):
        return ''
    url = url.strip()
    if url.startswith('//'):
        return 'https:' + url
    if url.startswith('http://'):
        return 'https://' + url[len('http://'):]
    return url


def _extract_names(container: Any) -> list[str]:
    """category / performer / label などの揺れる構造から名前の配列を取り出す。
    想定形: [{'data': {'id':..,'name':..}}] / [{'name':..}] / ['名前'] / {'data': [...]}"""
    if not container:
        return []
    if isinstance(container, dict):
        container = container.get('data') or container.get('item') or [container]
    if not isinstance(container, list):
        container = [container]

    names: list[str] = []
    for entry in container:
        if isinstance(entry, dict) and isinstance(entry.get('data'), dict):
            entry = entry['data']
        name = ''
        if isinstance(entry, dict):
            name = str(entry.get('name') or entry.get('title') or '').strip()
        elif isinstance(entry, str):
            name = entry.strip()
        if name and name not in names:
            names.append(name)
    return names


def _pick_image(block: Any, prefer: tuple[str, ...] = ('large', 'midium', 'medium', 'small')) -> str:
    """posterimage / jacketimage のようなサイズ別URLブロックから最大サイズを1つ選ぶ。"""
    if isinstance(block, list):
        block = block[0] if block else None
    if isinstance(block, str):
        return _to_https(block)
    if isinstance(block, dict):
        for key in prefer:
            if block.get(key):
                return _to_https(block[key])
    return ''


# サンプル画像のサイズ別キー。表示用は中サイズ、拡大用は最大サイズを優先して選ぶ。
# （DUGA APIは 'midium' とスペルされる。単一URLのみの場合は 'image' 等を使う）
_DISPLAY_KEYS = ('midium', 'medium', 'large', 'small', 'image', 'url', 'src')
_LARGE_KEYS = ('large', 'midium', 'medium', 'small', 'image', 'url', 'src')


def _pick_from_entry(entry: Any, keys: tuple[str, ...]) -> str:
    if isinstance(entry, str):
        return _to_https(entry)
    if isinstance(entry, dict):
        if isinstance(entry.get('data'), dict):
            entry = entry['data']
        for key in keys:
            if entry.get(key):
                return _to_https(entry[key])
    return ''


def _extract_sample_images(item: Product, limit: int = 8) -> tuple[list[str], list[str]]:
    """thumbnail（サンプル画像の一覧）から (表示用URL配列, 拡大用URL配列) を返す。
    2つの配列は同じ並び・同じ長さ。サイズ違いが無い場合は同じURLになる。"""
    thumbs = item.get('thumbnail') or []
    if isinstance(thumbs, (dict, str)):
        thumbs = [thumbs]
    display: list[str] = []
    large: list[str] = []
    for entry in thumbs:
        shown = _pick_from_entry(entry, _DISPLAY_KEYS)
        full = _pick_from_entry(entry, _LARGE_KEYS)
        if not shown or shown in display:
            continue
        display.append(shown)
        large.append(full or shown)
        if len(display) >= limit:
            break
    return display, large


def _debug_print_image_fields(item: Product) -> None:
    """DUGA_DEBUG_IMAGES=1 のとき、画像関連フィールドの実際の構造を表示する（拡大画像のURL調査用）。"""
    for key in ('thumbnail', 'jacketimage', 'posterimage'):
        value = item.get(key)
        sample = value[:2] if isinstance(value, list) else value
        print(f'  🔎 [DUGA debug] {key}: {sample}')


def _request_page(params: dict[str, Any]) -> list[Product]:
    """1ページ分を取得して item のリストにする。一時的な失敗はリトライし、最終的に失敗したら RuntimeError。"""
    last_error: Optional[Exception] = None
    data: Any = None
    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            resp = requests.get(DUGA_API_BASE, params=params, timeout=_REQUEST_TIMEOUT_SEC)
            resp.raise_for_status()
            data = resp.json()  # 認証エラー時などHTMLが返るとValueError
            break
        except (requests.RequestException, ValueError) as e:
            last_error = e
            print(f'  ⚠️ [DUGA] 取得失敗（{attempt}/{_MAX_RETRIES}回目）: {e}')
            if attempt < _MAX_RETRIES:
                time.sleep(_RETRY_WAIT_SEC * attempt)
    else:
        raise RuntimeError(f'DUGA APIの取得に失敗しました: {last_error}') from last_error

    if not isinstance(data, dict):
        raise RuntimeError(f'DUGA APIの応答形式が想定外です: {str(data)[:200]}')

    items: list[Product] = []
    for entry in data.get('items') or []:
        # DUGAのJSONは [{"item": {...}}, ...] の形が一般的
        if isinstance(entry, dict) and isinstance(entry.get('item'), dict):
            items.append(entry['item'])
        elif isinstance(entry, dict):
            items.append(entry)
    return items


# ================================================================
# 🌐 公開API
# ================================================================

def fetch_duga_products(
    offset: int = 1,
    hits: int = 100,
    sort: str = 'new',
    release_start: str = '',
    release_end: str = '',
    keyword: str = '',
) -> list[Product]:
    """DUGA APIから作品を取得する（100件超は自動でページ送り）。

    release_start / release_end は 'YYYYMMDD'。DUGA APIに日付絞り込みが無いため
    クライアント側で絞り込み、sort=new（新着順）の場合は期間より古い作品が
    出た時点で打ち切る（無駄なリクエストを避けるため）。
    """
    app_id, agent_id, banner_id = _load_credentials()
    start_date = _parse_date_str(release_start)
    end_date = _parse_date_str(release_end)

    first_offset = max(1, offset)
    current_offset = first_offset
    remaining = max(1, hits)
    collected: list[Product] = []

    while remaining > 0:
        page_hits = min(remaining, _MAX_HITS_PER_REQUEST)
        params: dict[str, Any] = {
            'version': DUGA_API_VERSION,
            'appid': app_id,
            'agentid': agent_id,
            'bannerid': banner_id,
            'format': 'json',
            'adult': '1',
            'hits': page_hits,
            'offset': current_offset,
            'sort': sort,
        }
        if keyword:
            params['keyword'] = keyword

        print(f'  [DUGA] 取得中（sort={sort} / offset={current_offset} / hits={page_hits}）...')
        try:
            page = _request_page(params)
        except RuntimeError:
            if current_offset == first_offset:
                raise  # 1ページ目から失敗＝設定/障害なので、成功扱いにせず呼び出し側へ伝える
            print('  ⚠️ [DUGA] 2ページ目以降の取得に失敗したため、ここまでの結果で続行します。')
            break

        if not page:
            break

        hit_older_than_window = False
        for item in page:
            released = _extract_date(item)
            if released is not None:
                if start_date and released < start_date:
                    hit_older_than_window = True
                    continue
                if end_date and released > end_date:
                    continue
            collected.append(item)

        if sort == 'new' and hit_older_than_window:
            break
        if len(page) < page_hits:
            break
        current_offset += page_hits
        remaining -= page_hits

    print(f'  ✅ [DUGA] {len(collected)} 件取得しました。')
    return collected


def parse_duga_product(item: Product) -> Product:
    """DUGAのitemを、wordpress_blog_poster.py 共通のproduct辞書へ正規化する。"""
    title = str(item.get('title') or '').strip()
    product_id = str(item.get('productid') or item.get('itemno') or '').strip().lower()
    # DMMのcontent_idと衝突しないようプレフィックスを付ける（重複投稿防止の履歴キー兼スラッグ）
    if product_id:
        content_id = f'duga-{product_id}'
    else:
        content_id = 'duga-' + hashlib.sha1(title.encode('utf-8')).hexdigest()[:10]

    price_num: Optional[int] = None
    price_str = ''
    digits = ''.join(ch for ch in str(item.get('price') or '') if ch.isdigit())
    if digits:
        price_num = int(digits)
        price_str = f'¥{price_num:,}'

    maker_field = item.get('makername') or item.get('maker')
    maker = ''
    if isinstance(maker_field, dict):
        maker = str(maker_field.get('name') or '').strip()
    elif isinstance(maker_field, str):
        maker = maker_field.strip()
    elif isinstance(maker_field, list):
        names = _extract_names(maker_field)
        maker = names[0] if names else ''

    label_names = _extract_names(item.get('label'))
    series_names = _extract_names(item.get('series'))
    released = _extract_date(item)
    # 公式の紹介文（実データ）。取れなければ空文字
    summary = pick_summary(item)
    debug_log('duga', item, summary)

    sample_images, sample_images_large = _extract_sample_images(item)
    if os.environ.get('DUGA_DEBUG_IMAGES', '').strip() in ('1', 'true'):
        _debug_print_image_fields(item)

    # アイキャッチはヨコ長のjacketimageを優先し、無ければposterimage
    package_image = _pick_image(item.get('jacketimage')) or _pick_image(item.get('posterimage'))

    return {
        'content_id':       content_id,
        'title':            title,
        'affiliate_url':    str(item.get('affiliateurl') or item.get('affiliateURL') or item.get('url') or '').strip(),
        'price':            price_str,
        'price_num':        price_num,
        'genres':           _extract_names(item.get('category') or item.get('categoryarray') or item.get('genre')),
        'maker':            maker,
        'actors':           _extract_names(item.get('performer') or item.get('actress'))[:3],
        'review_avg':       None,
        'review_count':     None,
        'package_image':    package_image,
        'sample_images':    sample_images,
        'sample_images_large': sample_images_large,
        'sample_movie_url': '',  # DUGAの動画は埋め込みURLの仕様が異なるため未対応（空なら動画ブロックは出力されない）
        'series':           series_names[0] if series_names else '',
        'label':            label_names[0] if label_names else '',
        'director':         '',
        'real_summary':     summary,
        # ポスター側の期間フィルターが読める 'YYYY-MM-DD' 形式に統一（不明なら空）
        'date':             released.isoformat() if released else '',
        'source':           'duga',
    }
