"""
📝 DMM品番＋あらすじ＋特徴 → WordPress自動投稿ツール（GitHub Actions実行用）
------------------------------------------------------------
既存サイト（例: https://adult-navi20.site/snos00355-2/）と同じ構成
  ・出演者
  ・## この作品はどんな内容？（あらすじ／手入力）
  ・## ✓ チェックしておきたい特徴（箇条書き／手入力）
  ・ジャンル／サークル／価格
  ・サンプル画像ギャラリー（DMM APIから自動取得）
  ・サンプル動画リンク（DMM APIから自動取得）
  ・購入リンク／注意書き
  ・タグ（DMMのジャンルから自動生成）
で投稿を作成します。あらすじと特徴だけ手入力し、それ以外はDMM APIの情報を使います。

■ 必要な環境変数
  DMM_API_ID / DMM_AFFILIATE_ID / DMM_FLOOR
  WP_URL / WP_USER / WP_APP_PASSWORD
  WP_CATEGORY_ID（任意・直接指定）/ WP_CATEGORY_NAME（任意・名前で指定）
    → どちらも未指定の場合、ターミナルから手動実行しているときは
      実際のカテゴリー一覧を表示して番号で選択できる。
      GitHub Actions等の非対話環境では未分類のまま投稿する。
  WP_STATUS（既定: draft）
  CONTENT_ID   : 品番
  SYNOPSIS     : あらすじ（段落ごとに改行。GitHub Actionsからは \n で改行を表現）
  FEATURES     : 特徴の箇条書き（1行＝1項目。GitHub Actionsからは \n で改行を表現）
"""

import os
import sys
import requests
from io import BytesIO
from typing import Any, Dict, List, Optional
from xml.sax.saxutils import escape

from PIL import Image

DMM_API_ID       = os.environ.get('DMM_API_ID', '')
DMM_AFFILIATE_ID = os.environ.get('DMM_AFFILIATE_ID', '')
DMM_FLOOR        = os.environ.get('DMM_FLOOR', 'videoa')

WP_URL           = os.environ.get('WP_URL', '').rstrip('/')
WP_USER          = os.environ.get('WP_USER', '')
WP_APP_PASSWORD  = os.environ.get('WP_APP_PASSWORD', '')
WP_CATEGORY_ID   = os.environ.get('WP_CATEGORY_ID', '')
WP_CATEGORY_NAME = os.environ.get('WP_CATEGORY_NAME', '')
WP_STATUS        = os.environ.get('WP_STATUS', 'draft')

CONTENT_ID = os.environ.get('CONTENT_ID', '').strip()
SYNOPSIS   = os.environ.get('SYNOPSIS', '').strip()
FEATURES   = os.environ.get('FEATURES', '').strip()

_required = {
    'DMM_API_ID': DMM_API_ID,
    'DMM_AFFILIATE_ID': DMM_AFFILIATE_ID,
    'WP_URL': WP_URL,
    'WP_USER': WP_USER,
    'WP_APP_PASSWORD': WP_APP_PASSWORD,
    'CONTENT_ID': CONTENT_ID,
    'SYNOPSIS': SYNOPSIS,
}
_missing = [k for k, v in _required.items() if not v]
if _missing:
    print(f'❌ 必要な値が不足しています: {", ".join(_missing)}')
    sys.exit(1)

print('✅ 認証情報を読み込みました。')
print(f'📌 品番: {CONTENT_ID} / 投稿ステータス: {WP_STATUS}')


def fetch_dmm_product(content_id):
    """品番からDMM APIで商品情報を1件取得する。見つからなければNoneを返す。"""
    url = 'https://api.dmm.com/affiliate/v3/ItemList'
    params = {
        'api_id': DMM_API_ID,
        'affiliate_id': DMM_AFFILIATE_ID,
        'site': 'FANZA',
        'service': 'digital',
        'floor': DMM_FLOOR,
        'cid': content_id,
        'output': 'json',
    }
    resp = requests.get(url, params=params, timeout=15)
    resp.raise_for_status()
    data = resp.json()
    items = data.get('result', {}).get('items', [])
    return items[0] if items else None


def resize_image_for_upload(
    image_bytes: bytes,
    max_width: int = 800,
    quality: int = 82,
) -> bytes:
    """画像をmax_width以下にリサイズしJPEGで再圧縮し、アップロードするデータ量を減らす。
    WordPress側は受け取った画像を元にサムネイル等を生成するため、事前に軽量化しておくことで
    共有サーバーでのメモリ不足（Fatal error: Allowed memory size exhausted）を避けやすくなる。
    リサイズに失敗した場合は元のバイト列をそのまま返す。"""
    try:
        img = Image.open(BytesIO(image_bytes))
        # 透過PNG等でもJPEG保存できるようRGBに統一する
        img = img.convert('RGB')
        if img.width > max_width:
            ratio = max_width / img.width
            new_height = int(img.height * ratio)
            img = img.resize((max_width, new_height), Image.LANCZOS)
        buffer = BytesIO()
        img.save(buffer, format='JPEG', quality=quality, optimize=True)
        return buffer.getvalue()
    except Exception as e:
        print(f'⚠️ 画像のリサイズに失敗しました（元画像のままアップロードします）: {e}')
        return image_bytes


def upload_featured_media(image_url: str, filename: str, alt_text: str) -> Optional[int]:
    """DMMのパッケージ画像URLをダウンロード→リサイズしてWPメディアライブラリにアップロードし、
    アイキャッチ画像（featured_media）用のメディアIDを返す。失敗時はNoneを返す
    （一覧の「Image」列はfeatured_mediaを参照しており、本文内<img>だけでは表示されないため）。"""
    if not image_url:
        return None

    try:
        img_resp = requests.get(image_url, timeout=15)
        img_resp.raise_for_status()
    except requests.RequestException as e:
        print(f'⚠️ パッケージ画像のダウンロードに失敗しました（アイキャッチ設定をスキップ）: {e}')
        return None

    # リサイズ後は常にJPEGとして保存する（DMM画像はjpg/pngいずれでも問題なく変換できる）。
    # 環境変数で最大幅・画質を調整できるようにしておく。
    max_width = int(os.environ.get('WP_FEATURED_IMAGE_MAX_WIDTH', '800'))
    quality = int(os.environ.get('WP_FEATURED_IMAGE_QUALITY', '82'))
    resized_bytes = resize_image_for_upload(img_resp.content, max_width=max_width, quality=quality)
    safe_filename = f'{filename}.jpg'

    try:
        media_resp = requests.post(
            f'{WP_URL}/wp-json/wp/v2/media',
            headers={
                'Content-Disposition': f'attachment; filename="{safe_filename}"',
                'Content-Type': 'image/jpeg',
            },
            data=resized_bytes,
            auth=(WP_USER, WP_APP_PASSWORD),
            timeout=30,
        )
        if not media_resp.ok:
            # PHP側の致命的エラー（メモリ不足等）はここでHTMLとして返ってくることが多いため、
            # raise_for_statusで握り潰す前に本文を出して原因調査しやすくする。
            print(f'⚠️ メディアアップロードがステータス{media_resp.status_code}を返しました。'
                  f'レスポンス本文（先頭500文字）: {media_resp.text[:500]}')
        media_resp.raise_for_status()
    except requests.RequestException as e:
        print(f'⚠️ メディアのアップロードに失敗しました（アイキャッチ設定をスキップ）: {e}')
        return None

    media = media_resp.json()
    media_id = media.get('id')

    # alt テキストは別リクエストで更新（メディア作成時のパラメータでは反映されないことがあるため）
    if media_id and alt_text:
        try:
            requests.post(
                f'{WP_URL}/wp-json/wp/v2/media/{media_id}',
                json={'alt_text': alt_text},
                auth=(WP_USER, WP_APP_PASSWORD),
                timeout=15,
            )
        except requests.RequestException:
            pass  # alt テキストの設定失敗はアイキャッチ設定自体を止める理由にはしない

    return media_id


def discover_actor_taxonomy_rest_base() -> Optional[str]:
    """出演者用タキソノミーのREST名(rest_base)を返す。
    このサイトでは register_taxonomy() により固定で 'onavi_actress' として
    登録されていることが動作実績のあるwordpress_blog_poster.py側で確認済みのため、
    サイト間で揺れやすい自動検出（/wp-json/wp/v2/taxonomies 経由）はやめて決め打ちにする。
    別サイトで使い回す場合は WP_ACTOR_TAXONOMY 環境変数で上書きできる。"""
    return 'onavi_actress'


def resolve_term_ids(names: List[str], taxonomy_rest_base: str) -> List[int]:
    """指定タキソノミーのREST名(rest_base)を対象に、名前からタームIDのリストを作る。
    既存タームは検索、無ければ新規作成する（resolve_tag_idsの汎用版）。"""
    term_ids: List[int] = []
    for name in names:
        if not name:
            continue
        try:
            resp = requests.get(
                f'{WP_URL}/wp-json/wp/v2/{taxonomy_rest_base}',
                params={'search': name, 'per_page': 10},
                auth=(WP_USER, WP_APP_PASSWORD),
                timeout=15,
            )
            resp.raise_for_status()
            existing = resp.json()
            match = next((t for t in existing if t.get('name') == name), None)
            if match:
                term_ids.append(match['id'])
                continue

            create_resp = requests.post(
                f'{WP_URL}/wp-json/wp/v2/{taxonomy_rest_base}',
                json={'name': name},
                auth=(WP_USER, WP_APP_PASSWORD),
                timeout=15,
            )
            if create_resp.status_code in (200, 201):
                term_ids.append(create_resp.json().get('id'))
            else:
                print(f'⚠️ タキソノミー項目「{name}」の作成に失敗しました（スキップします）: '
                      f'status={create_resp.status_code} body={create_resp.text[:500]}')
        except requests.RequestException as e:
            print(f'⚠️ タキソノミー項目「{name}」の処理中にエラー（スキップします）: {e}')
    return term_ids


# ================================================================
# 🎨 見た目パーツ生成（wordpress_blog_poster.py と同じ見え方に揃える）
# ================================================================

_BADGE_COLORS = ['#ff6f91', '#ff9671', '#845ec2', '#4b93ff', '#00c2a8']


def _genre_badges_html(genres: list) -> str:
    """ジャンルを丸みのある色付きバッジで表示する。"""
    if not genres:
        return ''
    badges = []
    for i, g in enumerate(genres[:5]):
        color = _BADGE_COLORS[i % len(_BADGE_COLORS)]
        badges.append(
            f'<span style="display:inline-block;background:{color};color:#fff;'
            'padding:4px 12px;border-radius:999px;font-size:12px;font-weight:bold;'
            f'margin:2px 4px 2px 0;">{escape(g)}</span>'
        )
    return f'<div style="margin:8px 0;">{"".join(badges)}</div>'


def _star_rating_html(avg, count) -> str:
    """レビュー平均・件数から星評価（★☆）を表示する。"""
    if not avg or not count:
        return ''
    try:
        filled = max(0, min(5, round(float(avg))))
    except (TypeError, ValueError):
        return ''
    stars = '★' * filled + '☆' * (5 - filled)
    return (
        '<div style="margin:6px 0;">'
        f'<span style="color:#f5a623;font-size:18px;letter-spacing:1px;">{stars}</span> '
        f'<span style="color:#888;font-size:13px;">{avg}点（{count}件のレビュー）</span>'
        '</div>'
    )


def _paragraphs_html(text: str) -> str:
    """改行区切りの手入力テキストを段落（<p>）に変換する。"""
    parts = []
    for para in (text or '').splitlines():
        para = para.strip()
        if para:
            para_html = escape(para).replace('\n', '<br>')
            parts.append(f'<p style="line-height:1.8;color:#333;margin:0 0 12px;">{para_html}</p>')
    return '\n'.join(parts)


def _points_list_html(features: str, heading: str = '✓ チェックしておきたい特徴') -> str:
    """箇条書き特徴を、囲み付きのポイントボックスに変換する。"""
    lines = [line.strip() for line in (features or '').splitlines() if line.strip()]
    if not lines:
        return ''
    items = ''.join(
        f'<li style="margin:6px 0;line-height:1.6;">{escape(line)}</li>' for line in lines
    )
    return (
        '<div class="ona-points-box">'
        f'<h2 class="ona-points-title" style="margin:0 0 8px;font-size:16px;">{escape(heading)}</h2>'
        f'<ul style="margin:0;padding-left:20px;">{items}</ul>'
        '</div>'
    )


def _sample_gallery_html(affiliate_url: str, sample_images: list, title: str,
                          heading: str = 'サンプルをチェック') -> str:
    """サンプル画像をグリッド表示するギャラリーを組み立てる。"""
    imgs = [u for u in (sample_images or []) if u][:8]
    if not imgs:
        return ''
    cells = []
    for i, url in enumerate(imgs):
        alt_text = f'{title} サンプル画像' if i == 0 else f'サンプル画像{i + 1}'
        cells.append(
            f'<a href="{escape(affiliate_url)}" target="_blank" rel="sponsored" class="ona-sample-cell">'
            f'<img src="{escape(url)}" alt="{escape(alt_text)}" loading="lazy" class="ona-sample-img"></a>'
        )
    return (
        '<div class="ona-sample-gallery">'
        f'<h3 class="ona-sample-gallery-title" style="margin:0 0 8px;font-size:15px;">{escape(heading)}</h3>'
        '<div class="ona-sample-grid">' + ''.join(cells) + '</div>'
        '</div>'
    )


def _sample_video_html(sample_movie_url: str) -> str:
    """サンプル動画をiframeで埋め込む。<video>だと再生されないことがあるためiframeを使う。"""
    if not sample_movie_url:
        return ''
    return (
        '<div class="ona-sample-video" style="margin:14px 0;">'
        '<h3 style="margin:0 0 8px;font-size:15px;">サンプル動画</h3>'
        '<div style="position:relative;width:100%;max-width:560px;aspect-ratio:560/360;">'
        f'<iframe src="{escape(sample_movie_url)}" '
        'style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;border-radius:8px;" '
        'allow="autoplay; fullscreen" allowfullscreen loading="lazy"></iframe>'
        '</div>'
        '</div>'
    )


def make_excerpt(synopsis: str, title: str, max_len: int = 90) -> str:
    """投稿の抜粋(excerpt)を生成する。
    抜粋を空のまま投稿すると、WordPress側がwp_trim_excerpt()で本文から自動生成しようとする。
    このサイトのテーマ(GeneratePress)にはget_the_excerptフィルターの無限再帰バグがあり、
    自動生成が走るとPHPのメモリを使い切って投稿保存自体が失敗するため、
    必ず抜粋を明示的に指定して自動生成を回避する。"""
    text = (synopsis or title or '').replace('\n', ' ').strip()
    if len(text) <= max_len:
        return text
    return text[:max_len].rstrip() + '…'


def build_post_content(item, synopsis, features):
    """wordpress_blog_poster.py と同じ「カード型」レイアウトでHTMLを組み立てる。"""
    title         = item.get('title', '')
    affiliate_url = item.get('affiliateURL', '') or item.get('URL', '')
    # 'large' が無いレスポンスもあるため、'large' → 'small' の順にフォールバックする
    _image_urls  = item.get('imageURL', {}) or {}
    image_url     = _image_urls.get('large', '') or _image_urls.get('small', '')
    price         = (item.get('prices', {}) or {}).get('price', '')
    actors        = [a.get('name', '') for a in (item.get('iteminfo', {}).get('actress') or []) if a.get('name')]
    genres        = [g.get('name', '') for g in (item.get('iteminfo', {}).get('genre') or [])]
    maker         = ((item.get('iteminfo', {}).get('maker') or [{}])[0]).get('name', '')
    label         = ((item.get('iteminfo', {}).get('label') or [{}])[0]).get('name', '')
    review        = item.get('review', {}) or {}
    review_avg    = review.get('average', '')
    review_count  = review.get('count', '')

    sample_images = (
        (item.get('sampleImageURL', {}) or {})
        .get('sample_l', {})
        .get('image', [])
    )
    sample_movie = ''
    movie_urls = item.get('sampleMovieURL', {}) or {}
    for key in ('size_720_480', 'size_644_414', 'size_560_360', 'size_476_306'):
        if movie_urls.get(key):
            sample_movie = movie_urls[key]
            break

    # ---- パッケージ画像（アイキャッチ的にカード先頭へ）----
    image_section = ''
    if image_url:
        image_section = (
            f'<img src="{escape(image_url)}" alt="{escape(title)}" '
            'style="max-width:100%;height:auto;border-radius:8px;display:block;margin:0 0 12px;" />'
        )

    # ---- 出演者 ----
    # 本文内に表示するだけでなく、WPタグとしても付与できるよう戻り値に含める
    # （API側で "actress" 情報が無いジャンル・作品ではそもそも取得できない点に注意）。
    actors_section = ''
    if actors:
        actors_section = (
            '<div style="color:#666;font-size:13px;margin:4px 0 10px;">'
            f'出演者：{escape("、".join(actors))}</div>'
        )
    else:
        print('ℹ️ この作品にはDMM APIから出演者情報が取得できませんでした（AV以外のジャンル等では未提供のことがあります）。')

    # ---- あらすじ（手入力）----
    overview_section = (
        '<h2 style="margin:14px 0 8px;font-size:17px;">この作品はどんな内容？</h2>'
        f'<div>{_paragraphs_html(synopsis)}</div>'
    )

    # ---- 特徴（手入力・箇条書き）----
    points_section = _points_list_html(features)

    # ---- ジャンルバッジ・サークル・星評価・価格 ----
    badges_section = _genre_badges_html(genres)
    meta_section = ''
    if maker or label:
        meta_section = (
            '<div style="color:#666;font-size:13px;margin:4px 0 10px;">'
            f'サークル: {escape(maker or label)}</div>'
        )
    star_section = _star_rating_html(review_avg, review_count)
    price_section = ''
    if price:
        price_section = (
            '<div style="display:inline-block;background:#fff0f5;color:#e0507a;'
            'border:1px solid #ffc2d6;border-radius:8px;padding:6px 14px;'
            f'font-size:15px;font-weight:bold;margin:10px 0;">価格 ￥{escape(str(price))}</div>'
        )

    # ---- サンプル画像ギャラリー・サンプル動画 ----
    gallery_section = _sample_gallery_html(affiliate_url, sample_images, title)
    video_section = _sample_video_html(sample_movie)

    # ---- 購入CTAボタン ----
    cta_section = ''
    if affiliate_url:
        cta_section = (
            '<div style="text-align:center;margin:20px 0 8px;">'
            f'<a href="{escape(affiliate_url)}" target="_blank" rel="sponsored" '
            'style="display:inline-block;padding:14px 36px;background:linear-gradient(135deg,#ff6f91,#e0507a);'
            'color:#fff;text-decoration:none;border-radius:999px;font-size:16px;font-weight:bold;'
            'box-shadow:0 4px 12px rgba(224,80,122,0.35);">'
            '▶ 作品ページを見る</a></div>'
        )

    disclaimer_section = (
        '<p style="color:#999;font-size:12px;line-height:1.6;margin-top:16px;">'
        '※成人向けコンテンツを含みます。18歳未満の方はご利用いただけません。</p>'
    )

    # 表示したいセクションだけを順番に連結する（空文字のセクションは自動的に除外）
    card_inner = '\n'.join(part for part in [
        image_section,
        actors_section,
        overview_section,
        points_section,
        badges_section,
        meta_section,
        star_section,
        price_section,
        gallery_section,
        video_section,
        cta_section,
        disclaimer_section,
    ] if part)

    # wordpress_blog_poster.py と同じ「白いカード」の見た目にするラッパー
    body_html = (
        '<div style="max-width:600px;margin:0 auto;padding:20px;border:1px solid #eee;'
        'border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,0.06);font-family:'
        '-apple-system,BlinkMacSystemFont,\'Hiragino Sans\',sans-serif;">'
        f'{card_inner}</div>'
    )

    return title, body_html, genres, actors, image_url


def fetch_all_categories():
    """WordPressに登録されている全カテゴリー（id・name）を取得する。"""
    resp = requests.get(
        f'{WP_URL}/wp-json/wp/v2/categories',
        params={'per_page': 100},
        auth=(WP_USER, WP_APP_PASSWORD),
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()


def prompt_category_selection(categories: list):
    """手動実行時（対話的なターミナル）に、番号入力でカテゴリーを選ばせる。
    GitHub Actions等の非対話環境では標準入力が無いため、この関数は呼ばれない。"""
    print('📂 投稿先カテゴリーを選択してください:')
    for i, c in enumerate(categories, start=1):
        print(f'   {i}. {c.get("name")} (ID: {c.get("id")})')
    print('   0. 未分類のまま投稿する')

    while True:
        choice = input('番号を入力してください: ').strip()
        if choice == '0':
            return None
        if choice.isdigit() and 1 <= int(choice) <= len(categories):
            return categories[int(choice) - 1].get('id')
        print('⚠️ 無効な入力です。もう一度入力してください。')


def resolve_category_id():
    """カテゴリーIDの決定ロジック（優先順）:
    1. WP_CATEGORY_ID が指定されていればそれを使う
    2. WP_CATEGORY_NAME が指定されていれば名前検索で解決する
    3. どちらも未指定かつ対話的なターミナルで実行している場合は、
       実際のカテゴリー一覧から番号選択させる（＝手動投稿時の選択機能）
    4. それ以外（GitHub Actions等）は未分類のまま投稿する
    """
    if WP_CATEGORY_ID:
        try:
            return int(WP_CATEGORY_ID)
        except ValueError:
            print(f'⚠️ WP_CATEGORY_ID「{WP_CATEGORY_ID}」が数値ではありません。名前検索にフォールバックします。')

    if WP_CATEGORY_NAME:
        resp = requests.get(
            f'{WP_URL}/wp-json/wp/v2/categories',
            params={'search': WP_CATEGORY_NAME, 'per_page': 10},
            auth=(WP_USER, WP_APP_PASSWORD),
            timeout=15,
        )
        resp.raise_for_status()
        categories = resp.json()

        for c in categories:
            if c.get('name') == WP_CATEGORY_NAME:
                return c.get('id')
        if categories:
            print(f'⚠️ 「{WP_CATEGORY_NAME}」に完全一致するカテゴリーが無かったため、'
                  f'「{categories[0].get("name")}」を使用します。')
            return categories[0].get('id')
        print(f'⚠️ カテゴリー「{WP_CATEGORY_NAME}」が見つかりませんでした。')

    # WP_CATEGORY_ID / WP_CATEGORY_NAME どちらも指定が無い場合、
    # ローカルのターミナルから手動実行しているときだけ選択肢を出す。
    if sys.stdin.isatty():
        try:
            categories = fetch_all_categories()
        except requests.RequestException as e:
            print(f'⚠️ カテゴリー一覧の取得に失敗しました: {e}')
            return None
        if categories:
            return prompt_category_selection(categories)

    print('ℹ️ カテゴリー未指定のため、未分類のまま投稿します。')
    return None


def resolve_tag_ids(genre_names):
    """ジャンル名からWPタグIDのリストを作る。既存タグは検索、無ければ新規作成する。"""
    tag_ids = []
    for name in genre_names:
        if not name:
            continue
        try:
            resp = requests.get(
                f'{WP_URL}/wp-json/wp/v2/tags',
                params={'search': name, 'per_page': 10},
                auth=(WP_USER, WP_APP_PASSWORD),
                timeout=15,
            )
            resp.raise_for_status()
            existing = resp.json()
            match = next((t for t in existing if t.get('name') == name), None)
            if match:
                tag_ids.append(match['id'])
                continue

            create_resp = requests.post(
                f'{WP_URL}/wp-json/wp/v2/tags',
                json={'name': name},
                auth=(WP_USER, WP_APP_PASSWORD),
                timeout=15,
            )
            if create_resp.status_code in (200, 201):
                tag_ids.append(create_resp.json().get('id'))
            else:
                print(f'⚠️ タグ「{name}」の作成に失敗しました（スキップします）: {create_resp.status_code}')
        except requests.RequestException as e:
            print(f'⚠️ タグ「{name}」の処理中にエラー（スキップします）: {e}')
    return tag_ids


def post_to_wordpress(
    title: str,
    content_html: str,
    category_id: Optional[int] = None,
    tag_ids: Optional[List[int]] = None,
    featured_media: Optional[int] = None,
    extra_taxonomies: Optional[Dict[str, List[int]]] = None,
    excerpt: Optional[str] = None,
) -> Dict[str, Any]:
    """WordPress REST APIに投稿を作成する（アプリケーションパスワード認証）。
    extra_taxonomiesは {rest_base: [term_id, ...]} 形式で、出演者などのカスタム
    タキソノミーを一覧・出演者ページに反映させるために使う。
    excerptは必ず指定すること（省略するとWP側の自動生成処理がテーマの無限再帰バグを
    踏み、Fatal error: Allowed memory size exhaustedで投稿自体が失敗するため）。"""
    endpoint = f'{WP_URL}/wp-json/wp/v2/posts'
    payload: Dict[str, Any] = {
        'title': title,
        'content': content_html,
        'excerpt': excerpt or title,
        'status': WP_STATUS,
    }
    if category_id:
        payload['categories'] = [category_id]
    if tag_ids:
        payload['tags'] = tag_ids
    if featured_media:
        payload['featured_media'] = featured_media
    if extra_taxonomies:
        for rest_base, term_ids in extra_taxonomies.items():
            if term_ids:
                payload[rest_base] = term_ids

    resp = requests.post(
        endpoint,
        json=payload,
        auth=(WP_USER, WP_APP_PASSWORD),
        timeout=20,
    )
    if not resp.ok:
        # formatting.php等でのPHP致命的エラーはここでHTML/プレーンテキストとして返ってくるため、
        # raise_for_statusで握り潰す前に本文を出して、どのリクエストで落ちたか特定できるようにする。
        print(f'❌ 投稿作成がステータス{resp.status_code}を返しました。'
              f'レスポンス本文（先頭1000文字）: {resp.text[:1000]}')
    resp.raise_for_status()
    return resp.json()


def main():
    item = fetch_dmm_product(CONTENT_ID)
    if not item:
        print(f'❌ 品番「{CONTENT_ID}」の商品が見つかりませんでした。品番を確認してください。')
        sys.exit(1)

    title, content_html, genres, actors, image_url = build_post_content(item, SYNOPSIS, FEATURES)
    category_id = resolve_category_id()

    # ---- 切り分け用デバッグスイッチ ----
    # Fatal error（メモリ不足）の原因がどの処理にあるかを特定するため、
    # 各処理を個別に無効化できるようにしておく（true指定でスキップ）。
    skip_tags = os.environ.get('WP_SKIP_TAGS', '').strip().lower() == 'true'
    skip_featured_image = os.environ.get('WP_SKIP_FEATURED_IMAGE', '').strip().lower() == 'true'
    skip_actor_taxonomy = os.environ.get('WP_SKIP_ACTOR_TAXONOMY', '').strip().lower() == 'true'

    # ジャンルはタグとして付与
    tag_ids: List[int] = [] if skip_tags else resolve_tag_ids(genres)
    if skip_tags:
        print('🛠️ デバッグ: WP_SKIP_TAGS=true のためタグ付与をスキップしました。')

    # ---- アイキャッチ画像（一覧の「Image」列に表示させるため必須）----
    featured_media: Optional[int] = None
    if skip_featured_image:
        print('🛠️ デバッグ: WP_SKIP_FEATURED_IMAGE=true のためアイキャッチ設定をスキップしました。')
    else:
        featured_media = upload_featured_media(image_url, CONTENT_ID, title)
        if featured_media:
            print(f'🖼️ アイキャッチ画像を設定しました（メディアID: {featured_media}）')

    # ---- 出演者（一覧の「出演者」列・出演者ページに反映させるため必須）----
    extra_taxonomies: Dict[str, List[int]] = {}
    if skip_actor_taxonomy:
        print('🛠️ デバッグ: WP_SKIP_ACTOR_TAXONOMY=true のため出演者タキソノミー設定をスキップしました。')
    elif actors:
        actor_taxonomy = os.environ.get('WP_ACTOR_TAXONOMY', '').strip() or discover_actor_taxonomy_rest_base()
        if actor_taxonomy:
            actor_term_ids = resolve_term_ids(actors, actor_taxonomy)
            if actor_term_ids:
                extra_taxonomies[actor_taxonomy] = actor_term_ids
                print(f'🎭 出演者タキソノミー「{actor_taxonomy}」に設定しました: {actors}')
        else:
            # タキソノミーが見つからない場合でも、検索性を保つためタグには残す
            tag_ids += resolve_tag_ids(actors)

    result = post_to_wordpress(
        title, content_html, category_id, tag_ids,
        featured_media=featured_media,
        extra_taxonomies=extra_taxonomies,
        excerpt=make_excerpt(SYNOPSIS, title),
    )

    post_id = result.get('id')
    edit_url = f"{WP_URL}/wp-admin/post.php?post={post_id}&action=edit"
    print(f'✅ 投稿を作成しました（ID: {post_id} / ステータス: {WP_STATUS}）')
    print(f'🔗 編集画面: {edit_url}')


if __name__ == '__main__':
    main()
