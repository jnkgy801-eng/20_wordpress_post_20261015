# -*- coding: utf-8 -*-
"""
記事の「公開してよい品質か」を機械的に判定する品質ゲート。

人が目視で公開判断する代わりに、次の条件を満たさない記事は公開せず下書きに留める
（下書きは検索エンジンにインデックスされない）。判定結果は outputs/quality_report.jsonl
に記録し、後続の自動集計（週次レポート等）で使えるようにする。

判定項目:
  1. AI生成に成功している（テンプレートへのフォールバックは定型文になるため不可）
  2. 作品内容の裏付けがある（公式の紹介文、または一定数のレビュー）
  3. 本文が最低文字数を満たす
  4. 直近の記事と本文が似すぎていない（文字6-gramのJaccard類似度）

環境変数:
  QUALITY_GATE = draft(既定: 不合格は下書き) / skip(不合格は投稿しない) / off(判定しない)
"""
import datetime
import json
import os
from pathlib import Path

QUALITY_GATE = os.environ.get('QUALITY_GATE', 'draft').strip().lower()
if QUALITY_GATE not in ('draft', 'skip', 'off'):
    QUALITY_GATE = 'draft'

MIN_OVERVIEW_CHARS = int(os.environ.get('QUALITY_MIN_OVERVIEW_CHARS', '400'))
MAX_SIMILARITY = float(os.environ.get('QUALITY_MAX_SIMILARITY', '0.25'))
MIN_REVIEWS_AS_GROUNDING = int(os.environ.get('QUALITY_MIN_REVIEWS', '3'))

RECENT_OVERVIEWS_PATH = Path(os.environ.get('RECENT_OVERVIEWS_FILE', 'outputs/recent_overviews.json'))
REPORT_PATH = Path(os.environ.get('QUALITY_REPORT_FILE', 'outputs/quality_report.jsonl'))
_RECENT_KEEP = 40
_NGRAM = 6


def _ngrams(text: str, n: int = _NGRAM) -> set:
    t = ''.join(text.split())
    if len(t) < n:
        return {t} if t else set()
    return {t[i:i + n] for i in range(len(t) - n + 1)}


def similarity(a: str, b: str) -> float:
    ga, gb = _ngrams(a), _ngrams(b)
    if not ga or not gb:
        return 0.0
    return len(ga & gb) / len(ga | gb)


def max_similarity(text: str, others: list) -> float:
    return max((similarity(text, o) for o in others if o), default=0.0)


def load_recent_overviews() -> list:
    try:
        with open(RECENT_OVERVIEWS_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return [str(x) for x in data][-_RECENT_KEEP:]
    except Exception:
        return []


def save_recent_overviews(items: list) -> None:
    try:
        RECENT_OVERVIEWS_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(RECENT_OVERVIEWS_PATH, 'w', encoding='utf-8') as f:
            json.dump(items[-_RECENT_KEEP:], f, ensure_ascii=False)
    except Exception as e:
        print(f'⚠️ recent_overviews の保存に失敗しました: {e}')


def assess(product: dict, body: dict, recent_overviews: list) -> dict:
    """判定結果 {'publish_ok': bool, 'reasons': [...], 'similarity': float, 'grounded': bool} を返す。"""
    reasons = []
    if body.get('generated_by') != 'ai':
        reasons.append('AI生成に失敗し、定型テンプレートにフォールバックした')

    review_count = product.get('review_count') or 0
    grounded = bool(product.get('real_summary')) or review_count >= MIN_REVIEWS_AS_GROUNDING
    if not grounded:
        reasons.append('作品内容の裏付けデータがない（公式紹介文なし・レビュー少数）')

    overview = body.get('overview', '') or ''
    if len(overview) < MIN_OVERVIEW_CHARS:
        reasons.append(f'本文が短い（{len(overview)}字 < {MIN_OVERVIEW_CHARS}字）')

    sim = max_similarity(overview, recent_overviews)
    if sim >= MAX_SIMILARITY:
        reasons.append(f'直近の記事と本文が似すぎている（類似度 {sim:.2f} ≥ {MAX_SIMILARITY}）')

    return {'publish_ok': not reasons, 'reasons': reasons,
            'similarity': round(sim, 3), 'grounded': grounded}


def log_report(product: dict, result: dict, final_status: str) -> None:
    try:
        REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
        row = {
            'ts': datetime.datetime.now().isoformat(timespec='seconds'),
            'content_id': product.get('content_id'),
            'source': product.get('source') or os.environ.get('SOURCE', 'dmm'),
            'title': (product.get('title') or '')[:60],
            'publish_ok': result['publish_ok'],
            'grounded': result['grounded'],
            'similarity': result['similarity'],
            'reasons': result['reasons'],
            'final_status': final_status,
        }
        with open(REPORT_PATH, 'a', encoding='utf-8') as f:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')
    except Exception as e:
        print(f'⚠️ 品質レポートの書き込みに失敗しました: {e}')
