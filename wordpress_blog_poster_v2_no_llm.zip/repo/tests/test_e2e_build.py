# -*- coding: utf-8 -*-
"""build_article 〜 WordPress投稿ペイロードまでをモックで通す検証。実行: python tests/test_e2e_build.py"""
import os, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
tmp = tempfile.mkdtemp(); os.chdir(tmp)
os.environ.update({'SOURCE': 'duga', 'DUGA_APP_ID': 'a', 'DUGA_AGENT_ID': 'b',
    'WP_URL': 'https://example.com', 'WP_USERNAME': 'u', 'WP_APP_PASSWORD': 'p',
    'GEMINI_API_KEY': 'dummy', 'CONTENT_TYPE': 'av', 'WP_POST_STATUS': 'publish',
    'RECENT_OVERVIEWS_FILE': os.path.join(tmp, 'outputs/ro.json'),
    'QUALITY_REPORT_FILE': os.path.join(tmp, 'outputs/qr.jsonl')})
import wordpress_blog_poster as wp
class R:
    status_code = 200
    def json(self):
        return {'candidates': [{'content': {'parts': [{'text': '===OVERVIEW===\n' + ''.join(
            f'段落{i}では作品の方向性を整理します。' * 3 + '\n\n' for i in range(1, 14)) + '\n===POINTS===\n- a\n- b\n- c'}]}}]}
wp.requests.post = lambda *a, **k: R()
prod = {'content_id': 'duga-x1', 'title': '検証作品', 'genres': ['NTR'], 'maker': 'M', 'price': '¥500',
        'review_avg': None, 'review_count': None, 'series': '', 'label': '', 'director': '',
        'affiliate_url': 'https://example.com/a', 'package_image': '', 'sample_images': [],
        'sample_movie_url': '', 'actors': [], 'date': '2026-10-14', 'source': 'duga'}
a1 = wp.build_article(dict(prod, real_summary=''))
assert a1['status_override'] == 'draft' and not a1['quality']['grounded'], a1['quality']
print('PASS 紹介文なし → build_articleが draft を指定:', a1['quality']['reasons'])
a2 = wp.build_article(dict(prod, content_id='duga-x2', real_summary='紹介文のテスト。' * 12))
assert a2['status_override'] == '' and a2['quality']['publish_ok'], a2['quality']
print('PASS 紹介文あり → status_override なし（WP_POST_STATUS=publish のまま公開）')
