# -*- coding: utf-8 -*-
"""データ駆動ハブ（sale/new）のオフライン検証。DMM/WordPressはモック。実行: python tests/test_hubs.py"""
import json, os, sys, tempfile, datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.chdir(tempfile.mkdtemp())

def make_items(n_sale=8, n_plain=8):
    items = []
    for i in range(n_sale + n_plain):
        sale = i < n_sale
        lp = 1000 + 100 * i
        price = int(lp * (0.5 if i % 2 == 0 else 0.8)) if sale else lp
        items.append({
            'content_id': f'abc{i:05d}', 'title': f'テスト作品{i}', 'affiliateURL': f'https://al.fanza.co.jp/?lurl=x{i}',
            'prices': {'price': str(price), 'list_price': str(lp)}, 'volume': str(60 + i * 10),
            'date': f'2026-10-{10 + (i % 5):02d} 10:00:00',
            'iteminfo': {'genre': [{'name': 'NTR'}, {'name': '人妻・主婦'}]},
            'review': {'average': 4.0 + (i % 10) / 10, 'count': i}, 'imageURL': {'large': f'https://pics.example/{i}.jpg'}})
    return items

def run(mode, items, extra_env=None):
    env = {'DMM_API_ID': 'x', 'DMM_AFFILIATE_ID': 'x-990', 'WP_URL': 'https://example.com', 'WP_USERNAME': 'u',
           'WP_APP_PASSWORD': 'p', 'CONTENT_TYPE': 'av', 'ROUNDUP_MODE': mode, 'GENRE_LABEL': 'NTR',
           'DMM_ARTICLE_ID': '4111', 'ROUNDUP_TOP_N': '10', 'WP_POST_STATUS': 'publish'}
    env.update(extra_env or {})
    os.environ.update(env)
    sys.modules.pop('wordpress_roundup_poster', None)
    import wordpress_roundup_poster as rp
    posted, calls = {}, []
    class Resp:
        def __init__(self, code=200, data=None, content=b''):
            self.status_code, self._d, self.content, self.text = code, data, content, json.dumps(data or {})
            self.headers = {'Content-Type': 'image/jpeg'}
        def json(self): return self._d
    def fake_get(url, **kw):
        calls.append(('GET', url, kw.get('params')))
        if 'api.dmm.com' in url:
            off = kw['params']['offset']
            return Resp(200, {'result': {'items': items if off == 1 else []}})
        if 'wp-json' in url:
            return Resp(200, [])
        return Resp(404, {})
    def fake_post(url, **kw):
        if url.rstrip('/').endswith(('/posts', )) or '/posts/' in url:
            posted.update(json.loads(kw['data'].decode('utf-8')))
            return Resp(201, {'id': 7, 'status': 'publish', 'link': 'https://example.com/p'})
        if 'categories' in url or 'tags' in url:
            return Resp(201, {'id': 3})
        return Resp(404, {})
    rp.requests.get, rp.requests.post = fake_get, fake_post
    code = 0
    try:
        rp.main()
    except SystemExit as e:
        code = e.code
    return posted, code, calls

# --- 純粋関数 ---
import hub_content as hc
assert hc.volume_minutes('02:00:00') == 120 and hc.volume_minutes('90分') == 90 and hc.volume_minutes(None) == 0
assert hc.discount_pct(350, 500) == 30 and hc.discount_pct(500, 500) == 0 and hc.discount_pct(600, 500) == 0 and hc.discount_pct(None, 500) == 0
print('PASS 収録時間・割引率の計算')

# --- sale ---
posted, code, calls = run('sale', make_items(), {'SALE_MIN_PCT': '15'})
assert code == 0 and posted, (code, posted)
body = posted['content']
assert posted['slug'] == 'sale-av-4111', posted['slug']
assert '（PR）' in body and '時点' in body
assert '<table' in body and '割引' in body and 'OFF' in body
assert '目的別の選び方' in body and '最安' in body
assert '作品ごとの情報' in body
n_cards = body.count('販売ページで詳細を見る（PR）')
assert n_cards == 8, n_cards   # セール対象は8本（割引率が15%未満の通常価格の作品は含まれない）
assert 'テスト作品12' not in body   # 通常価格の作品（index>=8）は含まれない
assert posted['status'] == 'publish'
print(f'PASS sale: 対象{n_cards}本のみ・PR表記・比較表・選び方・slug固定({posted["slug"]})')
# 割引率の降順
import re
pcts = [int(x) for x in re.findall(r'<td>(\d+)%OFF</td>', body)]
assert pcts == sorted(pcts, reverse=True), pcts
print('PASS sale: 表が割引率の高い順:', pcts)

# --- 件数不足ガード ---
posted, code, _ = run('sale', make_items(n_sale=3, n_plain=10), {'SALE_MIN_PCT': '15'})
assert code == 0 and not posted
print('PASS sale: 該当が最低件数未満ならページを更新しない')

# --- new ---
posted, code, calls = run('new', make_items())
assert posted and posted['slug'] == 'new-av-4111'
api_params = [c[2] for c in calls if c[2] and c[2].get('sort')]
assert api_params[0]['sort'] == 'date' and 'gte_date' in api_params[0] and api_params[0]['article_id'] == '4111'
assert '直近7日' in posted['title'] and '配信日は' in posted['content']
print('PASS new: sort=date・期間指定・ジャンル指定・タイトル/配信日レンジ')

# --- ranking/genre の既存挙動（slug・ソート）が壊れていない ---
posted, code, calls = run('genre', make_items())
assert posted['slug'] == 'genre-roundup-av-4111'
assert [c[2] for c in calls if c[2] and c[2].get('sort')][0]['sort'] == 'rank'
print('PASS genre: 既存のslug/ソートを維持し、本文はデータ駆動に')

print('\nALL HUB CHECKS PASSED')
