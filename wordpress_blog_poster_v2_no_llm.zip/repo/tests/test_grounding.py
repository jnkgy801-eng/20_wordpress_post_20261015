# -*- coding: utf-8 -*-
"""オフラインで動く検証（APIキー・ネットワーク不要）。実行: python tests/test_grounding.py"""
import json, os, sys, tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
tmp = tempfile.mkdtemp()
os.chdir(tmp)
os.environ.update({
    'SOURCE': 'dmm', 'DMM_API_ID': 'x', 'DMM_AFFILIATE_ID': 'x-990',
    'WP_URL': 'https://example.com', 'WP_USERNAME': 'u', 'WP_APP_PASSWORD': 'p',
    'GEMINI_API_KEY': 'dummy', 'CONTENT_TYPE': 'av', 'WP_POST_STATUS': 'publish',
    'POSTED_HISTORY_FILE': os.path.join(tmp, 'outputs/posted_history.json'),
    'RECENT_OVERVIEWS_FILE': os.path.join(tmp, 'outputs/recent_overviews.json'),
    'QUALITY_REPORT_FILE': os.path.join(tmp, 'outputs/quality_report.jsonl'),
})
import real_summary as rs
import quality_gate as qg
import wordpress_blog_poster as wp

ok = 0
def check(name, cond):
    global ok
    print(('PASS ' if cond else 'FAIL ') + name)
    assert cond, name
    ok += 1

# --- real_summary ---
check('短すぎる文字列は紹介文にしない', rs.clean_summary('短い') == '')
check('HTMLタグが除去される', '<br>' not in rs.clean_summary('あ' * 50 + '<br>' + 'い' * 10))
check('候補キーから紹介文を拾う（caption）', rs.pick_summary({'caption': '舞台は小さな温泉街。' * 8}) != '')
check('定型文は紹介文にしない', rs.clean_summary('MGS動画（' + 'あ' * 50) == '')
check('長すぎる紹介文は切られる', len(rs.clean_summary('あ' * 2000)) <= rs.MAX_SUMMARY_CHARS + 1)

# --- プロンプトの根拠づけ（Gemini呼び出しをモックして実際のプロンプトを検査） ---
captured = {}
class FakeResp:
    status_code = 200
    def json(self):
        return {'candidates': [{'content': {'parts': [{'text':
            '===OVERVIEW===\n' + ('テスト本文です。' * 60) + '\n===POINTS===\n- 項目1\n- 項目2\n- 項目3'}]}}]}
def fake_post(url, params=None, headers=None, json=None, timeout=None):
    captured['prompt'] = json['contents'][0]['parts'][0]['text']
    return FakeResp()
wp.requests.post = fake_post

base = {'content_id': 't1', 'title': 'テスト作品', 'genres': ['NTR', '人妻'], 'maker': 'テストメーカー',
        'price': '¥300', 'review_avg': None, 'review_count': None, 'series': '', 'label': '', 'director': ''}

with_sum = dict(base, real_summary='夫の出張中、隣人との距離が少しずつ変わっていく人妻の日常を描くドラマ作品。' * 2)
wp._get_article_body_from_api(with_sum, appeal_pattern=wp._APPEAL_PATTERNS[0],
                              length_variant=wp._LENGTH_VARIANTS[1], opening_pattern=wp._OPENING_STYLE_VARIANTS[0])
p1 = captured['prompt']
check('紹介文ありのとき、紹介文がプロンプトに入る', '夫の出張中' in p1)
check('紹介文ありのとき、「唯一の根拠」ルールが入る', '唯一の根拠' in p1)
check('紹介文ありのとき、情景描写の書き出しが維持される', '具体的な一場面' in p1)
check('旧指示（ジャンルから状況を描写）が消えている', 'ジャンルの組み合わせから、どんな状況' not in p1)

wp._get_article_body_from_api(base, appeal_pattern=wp._APPEAL_PATTERNS[0],
                              length_variant=wp._LENGTH_VARIANTS[1], opening_pattern=wp._OPENING_STYLE_VARIANTS[0])
p2 = captured['prompt']
check('紹介文なしのとき、想像で書くことを禁止する指示が入る', '想像で書くことは禁止' in p2)
check('紹介文なしのとき、情景描写の書き出しに切り替わる', '具体的な一場面' not in p2)
check('紹介文なしのとき、不明点は正直に書く指示が入る', '販売ページで確認' in p2)

# --- 品質ゲート ---
good_body = {'generated_by': 'ai', 'overview': ''.join(chr(0x3042 + (i * 7) % 80) for i in range(900))}
r = qg.assess(with_sum, good_body, [])
check('紹介文あり・AI生成・十分な長さ・類似なし → 公開OK', r['publish_ok'])
r = qg.assess(base, good_body, [])
check('紹介文なし・レビュー少 → 不合格（根拠なし）', (not r['publish_ok']) and not r['grounded'])
r = qg.assess(dict(base, review_avg=4.2, review_count=5), good_body, [])
check('レビュー数が十分なら根拠ありと見なす', r['grounded'])
r = qg.assess(with_sum, dict(good_body, generated_by='template'), [])
check('テンプレートへのフォールバックは不合格', not r['publish_ok'])
r = qg.assess(with_sum, dict(good_body, overview='短い'), [])
check('本文が短いと不合格', not r['publish_ok'])
r = qg.assess(with_sum, good_body, [good_body['overview']])
check('直近記事とほぼ同一の本文は不合格（類似度）', (not r['publish_ok']) and r['similarity'] > 0.9)
other = ''.join(chr(0x4e00 + (i * 13) % 500) for i in range(900))
r = qg.assess(with_sum, dict(good_body, overview=other), [good_body['overview']])
check('内容が異なる本文は類似度チェックを通る', r['publish_ok'])

# --- 状態の保存 ---
qg.save_recent_overviews(['a' * 10] * 50)
check('recent_overviews は最大40件に制限される', len(qg.load_recent_overviews()) == 40)
qg.log_report(with_sum, r, 'publish')
check('品質レポート(jsonl)が書かれる', json.loads(Path(qg.REPORT_PATH).read_text(encoding='utf-8').splitlines()[0])['final_status'] == 'publish')

print(f'\nALL {ok} CHECKS PASSED')
