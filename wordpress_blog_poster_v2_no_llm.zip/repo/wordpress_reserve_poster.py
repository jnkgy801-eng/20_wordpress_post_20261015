# -*- coding: utf-8 -*-
"""
📝 FANZA予約作品 → WordPress 記事自動生成・投稿ツール
--------------------------------------------------------------
DMMアフィリエイトAPI(v3)から「発売日/配信日が未来」の予約作品を取得し、
作品ごとに記事（1作品=1記事）を生成して「予約作品」カテゴリーへ投稿する。
発売日は投稿のカスタムフィールド（_onavi_release_date）に保存し、
WordPress側で発売日ごとのタブ表示に利用する。

wordpress_blog_poster.py（発売済み作品用）とは別運用の、姉妹スクリプト。
投稿履歴ファイルも別（POSTED_HISTORY_FILE）にしているため、
同一作品が「予約作品」として投稿された後、発売日を迎えて
wordpress_blog_poster.py 側でも改めて投稿されることがある
（＝予約時と発売後で記事が2本になる）。仕様として許容する場合は
そのままでよいが、1本にまとめたい場合は別途「発売日を迎えた予約投稿の
カテゴリーを差し替える」バッチ処理が必要（未実装）。
--------------------------------------------------------------
"""

import os
import re
import sys
import urllib.parse

# ================================================================
# 📌 スクリプトバージョン（デプロイ確認用）
#    「投稿によって結果が違う」といった不整合が起きた際、
#    どのバージョンのコードで生成された投稿かを確認できるようにする。
#    コードを修正するたびに、この日付/番号を更新すること。
# ================================================================
SCRIPT_VERSION = '2026-10-08-02'
import json
import datetime
JST = datetime.timezone(datetime.timedelta(hours=9))
import requests
from pathlib import Path
from xml.sax.saxutils import escape

from age_safety_filter import is_safe
from indexnow import submit_url

# ================================================================
# ⚙️ 設定（環境変数から読み込み）
# ================================================================

DMM_API_ID       = os.environ.get('DMM_API_ID', '')
DMM_AFFILIATE_ID = os.environ.get('DMM_AFFILIATE_ID', '')

WP_URL           = os.environ.get('WP_URL', '').rstrip('/')      # 例: https://example.com
WP_USERNAME      = os.environ.get('WP_USERNAME', '')             # WordPressのログインユーザー名
WP_APP_PASSWORD  = os.environ.get('WP_APP_PASSWORD', '')         # アプリケーションパスワード（通常のログインパスワードとは別物）

# 投稿ステータス。draft（下書き）/ pending（承認待ち）/ publish（本公開）から選択。
# publishを選ぶと人間の目視確認なしにそのままサイトに公開されるため、
# 記事内容・画像・年齢確認フィルターの精度に十分自信がある場合のみ使用してください。
WP_POST_STATUS   = os.environ.get('WP_POST_STATUS', 'draft').lower()

GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', '')
GEMINI_MODEL   = os.environ.get('GEMINI_MODEL', 'gemini-3.5-flash')

if not DMM_API_ID or not DMM_AFFILIATE_ID:
    print('❌ 環境変数 DMM_API_ID / DMM_AFFILIATE_ID が設定されていません。')
    sys.exit(1)

if not WP_URL or not WP_USERNAME or not WP_APP_PASSWORD:
    print('❌ 環境変数 WP_URL / WP_USERNAME / WP_APP_PASSWORD が設定されていません。')
    sys.exit(1)

if WP_POST_STATUS not in ('draft', 'pending', 'publish'):
    print(f'⚠️ WP_POST_STATUS="{WP_POST_STATUS}" は不明な値です。'
          f' draft / pending / publish のいずれかを指定してください。draft にフォールバックします。')
    WP_POST_STATUS = 'draft'

print('✅ 認証情報を読み込みました。')
if WP_POST_STATUS == 'publish':
    print('🚨 投稿ステータス: publish（本公開）が指定されています。'
          '生成された記事は目視確認なしにそのままサイトへ公開されます。')
else:
    print(f'📌 投稿ステータス: {WP_POST_STATUS}（公開は必ず手動で行ってください）')

DMM_API_BASE = 'https://api.dmm.com/affiliate/v3'

# コンテンツ種別（同人 / AV）を選択。CONTENT_TYPE環境変数で切り替え可能。
#   doujin : FANZA同人（デフォルト）
#   av     : FANZA動画（アダルトビデオ）
CONTENT_TYPE = os.environ.get('CONTENT_TYPE', 'doujin').strip().lower()
_CONTENT_TYPE_TARGETS = {
    'doujin': {'service': 'doujin', 'floor': 'digital_doujin', 'label': 'FANZA同人'},
    'av':     {'service': 'digital', 'floor': 'videoa', 'label': 'FANZA動画'},
}
if CONTENT_TYPE not in _CONTENT_TYPE_TARGETS:
    print(f'⚠️ CONTENT_TYPE="{CONTENT_TYPE}" は不明な値です。doujin にフォールバックします。')
    CONTENT_TYPE = 'doujin'
SERVICE       = _CONTENT_TYPE_TARGETS[CONTENT_TYPE]['service']
FLOOR         = _CONTENT_TYPE_TARGETS[CONTENT_TYPE]['floor']
CONTENT_LABEL = _CONTENT_TYPE_TARGETS[CONTENT_TYPE]['label']
print(f'🏷️ スクリプトバージョン: {SCRIPT_VERSION}')
print(f'📌 コンテンツ種別: {CONTENT_LABEL}（service={SERVICE}, floor={FLOOR}）')

RANK_FETCH_LIMIT = int(os.environ.get('RANK_FETCH_LIMIT', '500'))
DATE_WINDOW_DAYS = int(os.environ.get('DATE_WINDOW_DAYS', '14'))
# 予約作品として対象にする「発売日までの日数」の上限（デフォルト60日先まで）
RESERVE_WINDOW_DAYS = int(os.environ.get('RESERVE_WINDOW_DAYS', '60'))

# DMM APIへ渡すsortパラメータ。rank（人気順）/ date（新着順）から選択。
DMM_SORT_MODE = os.environ.get('DMM_SORT_MODE', 'date').strip().lower()
if DMM_SORT_MODE not in ('rank', 'date'):
    print(f'⚠️ DMM_SORT_MODE="{DMM_SORT_MODE}" は不明な値です。rank にフォールバックします。')
    DMM_SORT_MODE = 'rank'
_SORT_LABEL = {'rank': '人気順', 'date': '新着順'}[DMM_SORT_MODE]

print(f'📌 {_SORT_LABEL}（sort={DMM_SORT_MODE}）で上位{RANK_FETCH_LIMIT}件を取得し、'
      f'発売日/配信日が実行日時より未来（今日から未来{RESERVE_WINDOW_DAYS}日以内）の予約作品のみ投稿対象にします。')

# 価格フィルタ（円）。未設定なら制限なし。price_numが取得できない商品は対象外にはしない。
def _parse_price_env(name: str):
    raw = os.environ.get(name, '').strip()
    if raw.isdigit():
        return int(raw)
    return None

PRICE_MIN = _parse_price_env('PRICE_MIN')
PRICE_MAX = _parse_price_env('PRICE_MAX')
if PRICE_MIN is not None or PRICE_MAX is not None:
    print(f'📌 価格フィルタ: {PRICE_MIN if PRICE_MIN is not None else "指定なし"}円 〜 '
          f'{PRICE_MAX if PRICE_MAX is not None else "指定なし"}円')

# AVでVRコンテンツを除外するかどうか。デフォルトは除外（True）。
# EXCLUDE_VR=false を指定すれば無効化できる（doujinの場合は元々関係なし）。
EXCLUDE_VR = os.environ.get('EXCLUDE_VR', 'true').strip().lower() not in ('false', '0', 'no')
if CONTENT_TYPE == 'av':
    print(f'📌 VR作品の除外: {"する" if EXCLUDE_VR else "しない"}')


def _is_vr_product(product: dict) -> bool:
    """ジャンル名・タイトルにVRを示すキーワードが含まれる作品かどうかを判定する。"""
    vr_keywords = ('VR', 'ＶＲ')
    for genre in product.get('genres', []) or []:
        if any(kw in genre for kw in vr_keywords):
            return True
    title = product.get('title', '') or ''
    if any(kw in title for kw in vr_keywords):
        return True
    return False


FETCH_COUNT = int(os.environ.get('FETCH_COUNT', '100'))
MAX_ARTICLES = int(os.environ.get('MAX_ARTICLES', '5'))  # 1回の実行で投稿する記事数の上限

# 投稿済み作品の重複防止用履歴ファイル（予約作品専用。発売作品用スクリプトとは別ファイル）
POSTED_HISTORY_FILE = Path(os.environ.get('POSTED_HISTORY_FILE', 'outputs/posted_history_reserve.json'))

# ================================================================
# 🗂️ 投稿履歴管理（重複投稿防止）
# ================================================================

def load_posted_history() -> set:
    if not POSTED_HISTORY_FILE.exists():
        return set()
    try:
        with open(POSTED_HISTORY_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return set(data.get('posted', []))
    except Exception as e:
        print(f'⚠️ 投稿履歴の読み込みに失敗しました（新規履歴として扱います）: {e}')
        return set()


def save_posted_history(history: set) -> None:
    POSTED_HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    try:
        with open(POSTED_HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump({'posted': sorted(history)}, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f'⚠️ 投稿履歴の保存に失敗しました: {e}')


def product_history_key(product: dict) -> str:
    return product.get('content_id') or f"title:{product.get('title', '')}"


# ================================================================
# 🔧 DMM API 関連（既存スクリプトと同じロジックを踏襲）
# ================================================================

def fetch_dmm_products(offset: int, sort: str = None, hits: int = None,
                        gte_date: str = None, lte_date: str = None):
    params = {
        'api_id':       DMM_API_ID,
        'affiliate_id': DMM_AFFILIATE_ID,
        'site':         'FANZA',
        'service':      SERVICE,
        'floor':        FLOOR,
        'hits':         hits or FETCH_COUNT,
        'offset':       offset,
        'sort':         sort or 'rank',
        'output':       'json',
    }
    # 発売日/配信日の範囲をDMM API側で絞り込む（未来の予約作品を最初から除外するため）。
    # 形式は 'YYYY-MM-DDTHH:MM:SS'。
    if gte_date:
        params['gte_date'] = gte_date
    if lte_date:
        params['lte_date'] = lte_date
    try:
        resp = requests.get(f'{DMM_API_BASE}/ItemList', params=params, timeout=15)
        data = resp.json()
        items = data.get('result', {}).get('items', [])
        if isinstance(items, dict):
            items = items.get('item', [])
        print(f'✅ DMM APIから {len(items)} 件取得しました（offset={offset}）。')
        return items
    except Exception as e:
        print(f'❌ DMM APIエラー（offset={offset}）: {e}')
        return []


_TITLE_PREFIX_RE = re.compile(r'^【[^】]{1,20}】\s*')


def fetch_rank_items(limit: int, sort: str = None,
                      gte_date: str = None, lte_date: str = None) -> list:
    """指定sort順（rank=人気順 / date=新着順）・指定日付範囲内の上位limit件の
    生アイテム（dict）をリストで返す。"""
    sort = sort or DMM_SORT_MODE
    items_out = []
    offset = 1
    while len(items_out) < limit:
        items = fetch_dmm_products(offset, sort=sort, gte_date=gte_date, lte_date=lte_date)
        if not items:
            break
        items_out.extend(items)
        offset += FETCH_COUNT
    return items_out[:limit]


def _strip_redundant_title_prefix(title: str) -> str:
    """DMMの商品タイトルは【ハイビジョン・独占配信・巨乳】のような接頭辞の直後に、
    同じキーワードを読点区切りでそのまま繰り返す形式が多い。
    一覧表示で全作品のタイトルが同じ書き出しに見えてしまう原因になるため、
    この冒頭の【...】タグ部分だけを取り除く（ジャンル情報はバッジ/カテゴリーで別途表示されるため
    情報は失われない）。"""
    if not title:
        return title
    return _TITLE_PREFIX_RE.sub('', title, count=1).strip()


def _build_affiliate_url(raw_url: str) -> str:
    """DMM APIのレスポンスに 'affiliateURL' が含まれない商品（同人カテゴリ等で
    まれに発生）向けに、計測付きの正しいアフィリエイトリンク（al.dmm.co.jp形式）を
    自前で組み立てる。
    ここを経由しないと、'URL' フィールド（utm_*パラメータ付きだが
    アフィリエイト計測は乗っていない生リンク）がそのまま使われてしまい、
    クリックされても報酬が一切発生しない、という不具合になる。
    """
    if not raw_url:
        return ''
    # utm_* パラメータ（アフィリエイト計測とは無関係）は取り除いてからlurlに使う
    parsed = urllib.parse.urlsplit(raw_url)
    clean_query = '&'.join(
        kv for kv in parsed.query.split('&')
        if kv and not kv.startswith('utm_')
    )
    clean_url = urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, parsed.path, clean_query, '')
    )
    encoded = urllib.parse.quote(clean_url, safe='')
    return f'https://al.dmm.co.jp/?lurl={encoded}&af_id={DMM_AFFILIATE_ID}&ch=api&ch_id=link'


def _resolve_affiliate_url(item: dict) -> str:
    """DMM APIが返す 'affiliateURL' を、そのまま信用せずに検証する。

    同人カテゴリ等: 'affiliateURL' が空で返ってくることがある。
    AV(video.dmm.co.jp)等: 'affiliateURL' が空ではないが、中身が
        utm_*パラメータだけの計測なしURL（al.dmm.co.jpを経由していない）
        のまま返ってくることがある。
    どちらの場合も、クリックされてもアフィリエイト報酬が発生しない生リンクに
    なってしまうため、'al.dmm.co.jp' を経由した正しい形式でなければ、
    自前で組み立て直す。
    """
    raw_affiliate = item.get('affiliateURL', '')
    # DMM APIは商品によって、正しい計測付きリンクを 'al.dmm.co.jp' ではなく
    # 'al.fanza.co.jp' というドメインで返してくることがある。
    # ここを見落とすと、すでに正しいリンクをもう一度 al.dmm.co.jp で
    # 二重に包んでしまい（lurlの中にlurlが入れ子になる）、404の原因になる。
    if raw_affiliate and ('al.dmm.co.jp' in raw_affiliate or 'al.fanza.co.jp' in raw_affiliate):
        return raw_affiliate
    # affiliateURLが空、または計測なしの生リンクだった場合は、
    # 手元にあるURL（affiliateURLかURLフィールド）から正しい形式を組み立て直す
    fallback_source = raw_affiliate or item.get('URL', '')
    return _build_affiliate_url(fallback_source)


def _parse_volume_minutes(raw):
    """DMM APIのvolume（収録時間）を分(int)にして返す。取れなければ0。
    '120' / '120分' / '02:00:00' のどの形式でも対応する。"""
    s = str(raw or '').strip()
    if not s:
        return 0
    if ':' in s:
        parts = [p for p in s.split(':') if p.isdigit()]
        try:
            nums = [int(p) for p in parts]
        except ValueError:
            return 0
        if len(nums) == 3:
            return nums[0] * 60 + nums[1]
        if len(nums) == 2:
            return nums[0]
        return 0
    digits = ''.join(c for c in s if c.isdigit())
    return int(digits) if digits else 0


def parse_product(item):
    content_id    = item.get('content_id', '') or item.get('product_id', '')
    title         = _strip_redundant_title_prefix(item.get('title', ''))
    affiliate_url = _resolve_affiliate_url(item)
    prices        = item.get('prices', {})
    price_str, price_num = '', None
    if prices:
        price_val = prices.get('price') or prices.get('list_price') or ''
        if price_val:
            digits = ''.join(c for c in str(price_val) if c.isdigit())
            if digits:
                price_num = int(digits)
                price_str = f'¥{price_num:,}'

    genres = [g.get('name', '') for g in (item.get('iteminfo', {}).get('genre') or [])]
    maker  = ((item.get('iteminfo', {}).get('maker') or [{}])[0]).get('name', '')
    actors = [a.get('name', '') for a in (item.get('iteminfo', {}).get('actress') or []) if a.get('name')][:3]

    review_info = item.get('review', {}) or {}
    try:
        review_avg   = float(review_info.get('average', 0) or 0)
        review_count = int(review_info.get('count', 0) or 0)
    except (ValueError, TypeError):
        review_avg, review_count = 0.0, 0
    review_avg   = round(review_avg, 2) if review_avg else None
    review_count = review_count if review_count else None

    img = item.get('imageURL', {}) or {}
    package_image = img.get('large') or img.get('small') or ''

    sample_images = []
    sample_url_block = item.get('sampleImageURL', {}) or {}
    for key in ('sample_l', 'sample_s'):
        block = sample_url_block.get(key) or {}
        images = block.get('image') or []
        if isinstance(images, str):
            images = [images]
        if images:
            sample_images = [u for u in images if u]
            break

    # サンプル動画URL（記事に埋め込み用）。取得できるサイズを優先度順に探す。
    sample_movie_url = ''
    movie_block = item.get('sampleMovieURL', {}) or {}
    for key in ('size_720_480', 'size_644_414', 'size_560_360', 'size_476_306'):
        if movie_block.get(key):
            sample_movie_url = movie_block[key]
            break

    return {
        'content_id':    content_id,
        'title':         title,
        'affiliate_url': affiliate_url,
        'price':         price_str,
        'price_num':     price_num,
        'genres':        genres,
        'maker':         maker,
        'actors':        actors,
        'review_avg':    review_avg,
        'review_count':  review_count,
        'package_image': package_image,
        'sample_images': sample_images,
        'sample_movie_url': sample_movie_url,
        'date':          item.get('date', ''),
        'volume':        _parse_volume_minutes(item.get('volume')),
    }


# ================================================================
# 📝 記事本文生成（元スクリプトと同じロジック）
# ================================================================

def get_article_body_ai(product: dict, focus_keyphrase: str = '') -> dict:
    if GEMINI_API_KEY:
        try:
            return _get_article_body_from_api(product, focus_keyphrase)
        except Exception as e:
            print(f'    ⚠️ AI記事生成エラー（テンプレート使用）: {e}')
    else:
        # GEMINI_API_KEY未設定に気づかないままテンプレート運用が続く事故を防ぐため、
        # 実行のたびに明示的に警告を出す。
        print('    ⚠️ GEMINI_API_KEY未設定のため、テンプレート文章を使用します。')
    return _get_article_body_template(product, focus_keyphrase)


def _get_article_body_from_api(product: dict, focus_keyphrase: str = '') -> dict:
    genre_str = '・'.join(product['genres'][:5]) if product['genres'] else '不明'
    review_str = (
        f"平均{product['review_avg']}点（{product['review_count']}件のレビュー）"
        if product.get('review_avg') and product.get('review_count')
        else '不明'
    )
    keyphrase_instruction = ''
    if focus_keyphrase:
        keyphrase_instruction = (
            f"- 「{focus_keyphrase}」というキーフレーズを、OVERVIEWの最初の一文に必ず含め、\n"
            "  かつ本文（OVERVIEW+POINTS）全体でもう1回以上、自然な形で登場させる\n"
        )
    prompt = (
        f"あなたは{CONTENT_LABEL}（成人向け）ジャンルを専門とする、成約率の高いプロの\n"
        "アフィリエイターです。以下の作品の紹介記事の本文材料を作成してください。\n"
        "ゴールは『読ませること』ではなく『購入ボタンを押させること』です。\n"
        "読み手がクスッと笑いながら読み進めつつ、読み終える頃には具体的な使用シーンが\n"
        "頭に浮かび、『これは買うしかない』と自然に思ってしまうような、購買行動に\n"
        "直結する文章にしてください。\n\n"
        f"作品名: {product['title']}\n"
        f"ジャンル: {genre_str}\n"
        f"{'サークル' if CONTENT_TYPE == 'doujin' else 'メーカー/レーベル'}: {product.get('maker') or '不明'}\n"
        f"価格: {product.get('price') or '不明'}\n"
        f"レビュー: {review_str}\n\n"
        "セールスライティングの構成（PASONAの流れを意識する。ラベルは書かず、\n"
        "自然な文章として溶け込ませること）:\n"
        "1. Problem/Affinity: 読者が『わかる…』と共感してしまう欲求・シチュエーションを\n"
        "   ジャンルから想像して切り出す（例: こういう相手にこうされたい、この設定に弱い、等）\n"
        "2. Solution: この作品ならその欲求がどう満たされるかを、具体的な情景が目に浮かぶ\n"
        "   レベルで描写する（誰が・どんな関係性で・どういうシーンか）\n"
        "3. Offer: 価格に対して『このボリューム・満足度なら安い』と感じさせる一言を\n"
        "   さりげなく入れる（具体的な割引率や『業界最安』等の数値断定は禁止。\n"
        "   価格情報は既に別欄で表示されるため、円額そのものはOVERVIEW本文では言及しない）\n"
        "4. Narrowing down/背中押し: 『こんな人には特に刺さる』を1文で提示し、\n"
        "   最後は行動を後押しする一言で締める。ただし決まり文句のテンプレートには\n"
        "   頼らず、その作品の内容に即した具体的な一文を毎回考えて書く\n\n"
        "条件:\n"
        f"{keyphrase_instruction}"
        "- 文体はユーモラスで軽快に。読者にニヤッとしてもらえるような比喩・ツッコミ・\n"
        "  軽い自虐やボケを交えてよい（下品・侮辱的にはしない）\n"
        "- 抽象的な誉め言葉（『魅力的』『必見』『必見の一作』等）だけで終わらせず、\n"
        "  読者の五感・感情・具体的な妄想を刺激する描写を必ず入れる\n"
        "- 文章の読みやすさのため、「さらに」「また」「そのため」「つまり」「一方で」\n"
        "  「ちなみに」「実際」「なぜなら」「ただし」などの転換語（接続表現）は、\n"
        "  意味的に自然な箇所にだけ使う。割合を数える必要はなく、文法的な\n"
        "  つなぎとして必要な場所だけに絞り、同じ転換語を連続する文で繰り返さない\n"
        "  （転換語だらけの文章は機械的で不自然に読まれるため、無理に増やさない）\n"
        "- 文の長さにメリハリをつける（短い一文と、情景描写の長めの文を混在させる）。\n"
        "  全ての文が同じような長さ・同じようなリズムになるのを避ける\n"
        "- 次のような『いかにもAIが書いた感のある』定型フレーズ・言い回しは\n"
        "  一切使わない: 「気づいたら◯◯している」「そんな自分に気づいても」\n"
        "  「買わない理由が見当たらない」「もう指がカートに伸びている」\n"
        "  「開いたが最後」「見逃せない」「唯一無二」「琴線に触れる」\n"
        "  「深く考えさせられる」「非常に」「まさに」\n"
        "- ただし『業界No.1』『絶対』『必ず満足』『今だけ』『期間限定』など、検証不可能な\n"
        "  断定・優良誤認・実際にはない限定性を匂わせる表現（景品表示法に抵触しうる\n"
        "  表現）は使わない\n"
        "- 未成年を想起させる表現は一切使わない（成人向け作品であることを前提にする）\n"
        "- OVERVIEWは作品タイトルを本文中で繰り返さない（タイトルは見出しに既に表示されている）。\n"
        "  代わりに、ジャンルから読み取れる『どんな魅力があるか』『どういうシチュエーション・\n"
        "  関係性の話か』を、ユーモアと具体的な情景描写を交えつつ自然な文章として書く\n"
        "- POINTSに価格やレビュー点数など数値情報は含めない（別欄に表示済みのため）\n"
        "- POINTSは『○○要素が中心のストーリー』のような機械的な言い回しを使わない。\n"
        "  各項目は『その特徴があることで読者にどんな満足・興奮・楽しみが得られるか』を\n"
        "  ベネフィット視点で描写し、ユーモアを効かせつつ項目ごとに違う言い回しで、\n"
        "  思わず読みたくなる一文にする\n"
        "- POINTSのうち少なくとも1項目は、サンプル画像や試し読みを見に行きたくなる\n"
        "  ような『続きが気になる』フックにする\n"
        "- 出力は必ず次のプレーンテキスト形式のみ。前置きや説明・Markdown記法は禁止。\n\n"
        "===OVERVIEW===\n"
        "(280〜380文字程度で、上記PASONAの流れに沿って2〜3段落、ユーモアを交えて。\n"
        "段落間は空行で区切る)\n"
        "===POINTS===\n"
        "(「ここがポイント」として4〜5個、1行1項目、先頭に「- 」を付ける。各項目は40〜60文字程度で)\n"
    )
    # Gemini API呼び出し（課金設定をしない限り無料枠で利用可能）
    # 成人向け作品の紹介文であるため、性的表現に関する安全フィルタの閾値を
    # 緩めておく（デフォルトのままだと、正当な業務利用でも出力がブロックされ
    # 空文字やフォーマット崩れの応答になりやすい）。
    resp = requests.post(
        f'https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent',
        params={'key': GEMINI_API_KEY},
        headers={'content-type': 'application/json'},
        json={
            'contents': [{'parts': [{'text': prompt}]}],
            'generationConfig': {
                'maxOutputTokens': 2048,
                'temperature': 0.9,
                'thinkingConfig': {'thinkingBudget': 0},
            },
            'safetySettings': [
                {'category': 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold': 'BLOCK_NONE'},
                {'category': 'HARM_CATEGORY_HARASSMENT',        'threshold': 'BLOCK_ONLY_HIGH'},
                {'category': 'HARM_CATEGORY_HATE_SPEECH',       'threshold': 'BLOCK_ONLY_HIGH'},
                {'category': 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold': 'BLOCK_ONLY_HIGH'},
            ],
        },
        timeout=30,
    )
    data = resp.json()
    try:
        text = data['candidates'][0]['content']['parts'][0]['text'].strip()
    except (KeyError, IndexError, TypeError):
        text = ''
    if not text or '===OVERVIEW===' not in text or '===POINTS===' not in text:
        raise ValueError('unexpected AI response format')

    overview_part = text.split('===OVERVIEW===', 1)[1].split('===POINTS===', 1)[0].strip()
    points_part = text.split('===POINTS===', 1)[1].strip()
    points = [
        line.strip().lstrip('-').strip()
        for line in points_part.splitlines()
        if line.strip().lstrip('-').strip()
    ]
    if not overview_part or not points:
        raise ValueError('empty overview or points')
    return {'overview': overview_part, 'points': points[:4]}


import hashlib
import random as _random


def _stable_seed(key: str, salt: str) -> int:
    """content_id等から、実行のたびに変わらない安定した疑似乱数シードを算出する。
    同じ作品は常に同じ結果になるが、salt（軸の名前）を変えることで、
    言い回し・順序など複数の軸を互いに独立してばらつかせられる。"""
    digest = hashlib.md5(f'{key}::{salt}'.encode('utf-8')).hexdigest()
    return int(digest[:8], 16)


def _stable_pick(key: str, salt: str, options: list):
    """keyから安定的に選ばれる1要素を返す（テンプレート文言のバリエーション選択用）。"""
    if not options:
        return None
    return options[_stable_seed(key, salt) % len(options)]


def _stable_order(key: str, salt: str, items: list) -> list:
    """itemsを安定的にシャッフルした順序で返す（同じ作品は常に同じ順序になる）。"""
    rng = _random.Random(_stable_seed(key, salt))
    shuffled = list(items)
    rng.shuffle(shuffled)
    return shuffled


# 冒頭文（フォーカスキーフレーズあり／なし）のバリエーション
_INTRO_WITH_KEYPHRASE = [
    '「{kp}」に注目の{kind}。{genre}系の内容です。',
    '{genre}系の{kind}として、いま「{kp}」で探している方にちょうど合いそうな一本です。',
    '「{kp}」が気になった方に向けた、{genre}系の{kind}です。',
    '{genre}が好きな方はもちろん、「{kp}」に惹かれた方にもおすすめの{kind}です。',
]
_INTRO_PLAIN = [
    '{genre}系の{kind}です。',
    '{genre}を軸にした{kind}に仕上がっています。',
    '{genre}好きに向けた{kind}です。',
    '{genre}要素を詰め込んだ{kind}となっています。',
]

# 出演者紹介のバリエーション（AVのみ）
_ACTOR_TEMPLATES = [
    '出演しているのは{actor}。この時点でもう見る理由は十分揃っています。',
    '出演は{actor}。名前を見ただけで期待値が上がる組み合わせです。',
    '{actor}が出演しており、ファンなら見逃せない一本です。',
    'キャストは{actor}。この顔ぶれなら安心して選べます。',
]

# メーカー・サークル紹介のバリエーション
_MAKER_TEMPLATES = [
    'ちなみに、手がけるのは{maker}。',
    '制作は{maker}が担当しています。',
    '{maker}が手がけた作品というのもポイントです。',
    'メーカーは{maker}です。',
]

# 価格訴求のバリエーション
_PRICE_TEMPLATES = [
    'さらに価格は{price}なので、この内容ならコスパも十分満足できるはずです。',
    '価格も{price}と、内容を考えれば手を出しやすい設定です。',
    '{price}という価格も、このボリュームなら納得できる範囲です。',
]

# ジャンル訴求のバリエーション
_GENRE_APPEAL_TEMPLATES = [
    'つまり、{genre}といったジャンルが好きな方はもちろん、'
    '普段あまりこの手のジャンルを見ない方にも新鮮に映る一本というわけです。',
    '{genre}が好きな方には刺さりやすく、初めて触れる方にも入りやすい内容です。',
    '{genre}のファンはもちろん、気分転換に違うジャンルを試したい方にも向いています。',
]

# サンプル画像への言及のバリエーション
_SAMPLE_TEMPLATES = [
    'サンプル画像だけでも見応え十分なので、まずは雰囲気だけでもチェックしてみると早いかもしれません。',
    '購入前にサンプル画像で雰囲気を確認しておくと、選ぶときの参考になります。',
    '気になった方は、まずサンプル画像で作品の空気感を見てみてください。',
]

# レビューへの言及のバリエーション
_REVIEW_TEMPLATES = [
    '実際、レビューでも平均{avg}点（{count}件）と評価は上々で、'
    'すでに多くの人がその魅力に気づいている一本です。',
    'レビューは平均{avg}点（{count}件）と、実際に見た人からの評価も安定しています。',
    '平均{avg}点（{count}件のレビュー）という数字が、内容の安定感を裏付けています。',
]

# 「そのため、」に相当する締めの接続語バリエーション（同じ語の連発を避ける）
_CLOSER_LEAD_TEMPLATES = ['そのため、', 'というわけで、', 'そんなわけで、', '以上を踏まえると、']

_GENRE_POINT_TEMPLATES = [
    '{g}好きなら、うっかり夜更かし確定の内容です',
    '{g}成分が気になる方は、もう指がカートに伸びているはず',
    '{g}のツボを心得た一作。油断してると即決してしまいます',
    '{g}好きにこっそり教えたい、隠れた掘り出し物です',
    '{g}をテーマにした場面が中心で、好きな人にはたまらない構成です',
    '{g}が刺さる人にとっては、外せない一本になりそうです',
]

_REVIEW_POINT_TEMPLATES = [
    'また、レビュー平均{avg}点（{count}件）と、みんなも太鼓判',
    'レビューは平均{avg}点（{count}件）。実際に見た人からの評価も高めです',
    '評価は平均{avg}点（{count}件のレビュー）と、安定した支持を集めています',
]

_MAKER_POINT_TEMPLATES = [
    '制作は{maker}。安定した仕上がりも安心材料のひとつです',
    '{maker}が手がけているので、作風の傾向を知っている方には選びやすい一本です',
    '手がけているのは{maker}。この安心感も見逃せないポイントです',
]

_NO_INFO_POINT_TEMPLATES = [
    '作品ページを開いた時点で、もう半分ハマっています',
    '詳細はサンプル画像や作品ページで確認してみてください',
    '情報だけでは伝わりきらない魅力が詰まっている一本です',
]

_OVERVIEW_CLOSERS = [
    '内容を知ったうえで、あとは値段と相談するだけです。',
    '一度サンプルだけでも見ておくと、判断材料としては十分だと思います。',
    '好みに合うかどうかは人それぞれですが、条件は揃っている一本です。',
    'この手のジャンルが刺さる人には、かなり具体的に刺さる内容です。',
    '過度な期待はせず、素直に内容だけで判断してみてください。',
    '細かい好みが分かれる作品なので、まずは特徴を押さえておくと選びやすくなります。',
    '万人向けではありませんが、刺さる人にはしっかり刺さる作りです。',
    '判断に迷ったら、サンプル画像や紹介文の描写を基準にするとよさそうです。',
    '迷っている時間があるなら、その時間でもう読み終わっているかもしれません。',
]


def _get_article_body_template(product: dict, focus_keyphrase: str = '') -> dict:
    key = product.get('content_id') or product.get('title') or ''
    genre_str = '、'.join(product['genres'][:5]) if product['genres'] else '不明'
    work_kind = '同人作品' if CONTENT_TYPE == 'doujin' else 'AV作品'

    # 冒頭文（フォーカスキーフレーズの有無で使う候補プールを切り替え、
    # Yoastの「冒頭のキーフレーズ」チェック対策は維持しつつ言い回しをばらつかせる）。
    if focus_keyphrase:
        intro_tmpl = _stable_pick(key, 'intro', _INTRO_WITH_KEYPHRASE)
        overview = intro_tmpl.format(kp=focus_keyphrase, kind=work_kind, genre=genre_str)
    else:
        intro_tmpl = _stable_pick(key, 'intro', _INTRO_PLAIN)
        overview = intro_tmpl.format(kind=work_kind, genre=genre_str)

    # 出演者/メーカー/価格/ジャンル訴求/サンプル画像/レビューの各文は、
    # 存在するものだけを対象に、作品ごとに安定した順序でシャッフルして連結する。
    # → 同じ「ちなみに」「さらに」「つまり」が毎回同じ位置に来る単調さを解消する。
    optional_sentences = []
    if product.get('actors') and CONTENT_TYPE == 'av':
        actor_str = '、'.join(product['actors'])
        tmpl = _stable_pick(key, 'actor', _ACTOR_TEMPLATES)
        optional_sentences.append(('actor', tmpl.format(actor=actor_str)))
    if product.get('maker'):
        tmpl = _stable_pick(key, 'maker', _MAKER_TEMPLATES)
        optional_sentences.append(('maker', tmpl.format(maker=product['maker'])))
    if product.get('price'):
        tmpl = _stable_pick(key, 'price', _PRICE_TEMPLATES)
        optional_sentences.append(('price', tmpl.format(price=product['price'])))
    if product.get('genres'):
        tmpl = _stable_pick(key, 'genre_appeal', _GENRE_APPEAL_TEMPLATES)
        optional_sentences.append(('genre_appeal', tmpl.format(genre=genre_str)))
    if product.get('sample_images'):
        tmpl = _stable_pick(key, 'sample', _SAMPLE_TEMPLATES)
        optional_sentences.append(('sample', tmpl))
    if product.get('review_avg') and product.get('review_count'):
        tmpl = _stable_pick(key, 'review', _REVIEW_TEMPLATES)
        optional_sentences.append((
            'review', tmpl.format(avg=product['review_avg'], count=product['review_count']),
        ))

    ordered = _stable_order(key, 'sentence_order', optional_sentences)
    for _, sentence in ordered:
        overview += f" {sentence}"

    closer_lead = _stable_pick(key, 'closer_lead', _CLOSER_LEAD_TEMPLATES)
    closer = _stable_pick(key, 'closer', _OVERVIEW_CLOSERS)
    overview += f"\n\n{closer_lead}{closer}"

    # POINTSも、ジャンル→レビュー→メーカーの固定順ではなく、
    # 存在する要素を安定的にシャッフルした順序で並べる。
    point_candidates = []
    for i, g in enumerate((product.get('genres') or [])[:4]):
        tmpl = _stable_pick(f'{key}::{i}', 'genre_point', _GENRE_POINT_TEMPLATES)
        point_candidates.append(tmpl.format(g=g))
    if product.get('review_avg') and product.get('review_count'):
        tmpl = _stable_pick(key, 'review_point', _REVIEW_POINT_TEMPLATES)
        point_candidates.append(tmpl.format(avg=product['review_avg'], count=product['review_count']))
    if product.get('maker'):
        tmpl = _stable_pick(key, 'maker_point', _MAKER_POINT_TEMPLATES)
        point_candidates.append(tmpl.format(maker=product['maker']))
    if not point_candidates:
        point_candidates = [_stable_pick(key, 'no_info_point', _NO_INFO_POINT_TEMPLATES)]

    points = _stable_order(key, 'point_order', point_candidates)

    # 本文中でもう一度フォーカスキーフレーズに触れる
    # （Yoastの「キーフレーズ分布（最低2回）」チェック対策）。
    # 6件上限で切り捨てられないよう、既に6件ある場合は末尾と差し替える。
    if focus_keyphrase:
        keyphrase_point = f"なお、「{focus_keyphrase}」が気になった方は、ぜひ作品ページもチェックしてみてください"
        if len(points) >= 6:
            points[5] = keyphrase_point
        else:
            points.append(keyphrase_point)

    return {'overview': overview, 'points': points[:6]}


def _paragraphs_to_html(text: str) -> str:
    paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
    html_parts = []
    for p in paragraphs:
        p_html = escape(p).replace('\n', '<br>')
        html_parts.append(
            f'<p style="line-height:1.8;color:#333;margin:0 0 12px;">{p_html}</p>'
        )
    return '\n'.join(html_parts)


_BADGE_COLORS = ['#ff6f91', '#ff9671', '#845ec2', '#4b93ff', '#00c2a8']


def _genre_badges_html(genres: list) -> str:
    if not genres:
        return ''
    badges = []
    for i, g in enumerate(genres[:5]):
        color = _BADGE_COLORS[i % len(_BADGE_COLORS)]
        badges.append(
            f'<span style="display:inline-block;background:{color};color:#fff;'
            'padding:4px 12px;border-radius:999px;font-size:12px;font-weight:bold;'
            f'margin:2px 4px 2px 0;">{escape(g)}</span>'
        )
    return f'<div style="margin:8px 0;">{"".join(badges)}</div>'


def _star_rating_html(avg, count) -> str:
    if not avg or not count:
        return ''
    filled = max(0, min(5, round(avg)))
    stars = '★' * filled + '☆' * (5 - filled)
    return (
        '<div style="margin:6px 0;">'
        f'<span style="color:#f5a623;font-size:18px;letter-spacing:1px;">{stars}</span> '
        f'<span style="color:#888;font-size:13px;">{avg}点（{count}件のレビュー）</span>'
        '</div>'
    )


def _points_list_html(points: list) -> str:
    if not points:
        return ''
    items = ''.join(
        f'<li style="margin:6px 0;line-height:1.6;">{escape(pt)}</li>'
        for pt in points
    )
    return (
        '<div class="ona-points-box">'
        '<h2 class="ona-points-title" style="margin:0 0 8px;font-size:16px;">✓ ここがポイント</h2>'
        f'<ul style="margin:0;padding-left:20px;">{items}</ul>'
        '</div>'
    )


def _sample_gallery_html(affiliate_url: str, sample_images: list, title: str, focus_keyphrase: str = '') -> str:
    imgs = [u for u in (sample_images or []) if u][:8]
    if not imgs:
        return ''
    # altテキストにフォーカスキーフレーズ（や、それと重なりがちな作品タイトル）を
    # 含めるのは最初の1枚だけにする。
    # 2枚目以降はタイトルも繰り返さず「サンプル画像2」のような汎用文言にすることで、
    # Yoastの「キーフレーズ（や同義語）の過剰使用」警告を避ける。
    keyphrase_alt = f'{focus_keyphrase} {title} サンプル画像' if focus_keyphrase else f'{title} サンプル画像'
    cells = []
    for i, url in enumerate(imgs):
        alt_text = keyphrase_alt if i == 0 else f'サンプル画像{i + 1}'
        cells.append(
            f'<a href="{escape(affiliate_url)}" target="_blank" rel="nofollow sponsored noopener" class="ona-sample-cell">'
            f'<img src="{escape(url)}" alt="{escape(alt_text)}" loading="lazy" class="ona-sample-img"></a>'
        )
    return (
        '<div class="ona-sample-gallery">'
        '<h3 class="ona-sample-gallery-title" style="margin:0 0 8px;font-size:15px;">作品サンプル</h3>'
        '<div class="ona-sample-grid">' + ''.join(cells) + '</div>'
        '</div>'
    )


def _make_slug(content_id: str, title: str) -> str:
    """パーマリンクを英数字のみの短いスラッグにする。
    日本語タイトルがそのままURLエンコードされて長く読みにくくなるのを防ぐため、
    content_id（DMM側の商品IDで元々英数字）を優先的に使う。"""
    base = (content_id or '').strip()
    base = re.sub(r'[^A-Za-z0-9\-]+', '-', base).strip('-').lower()
    if base:
        return base
    # content_idが取得できない場合のフォールバック（タイトルのハッシュ的な短縮）
    fallback = re.sub(r'[^A-Za-z0-9]+', '-', title).strip('-').lower()
    return fallback[:60] or 'item'


def _make_excerpt(title: str, max_len: int = 90) -> str:
    """アーカイブページ等で画像の下に表示される抜粋文（プレーンテキスト、HTMLタグなし）。
    以前はジャンル接頭辞＋概要文を独自に組み立てていたが、
    それぞれが同じジャンル名を繰り返してしまい一覧が全部同じ書き出しに見える原因になっていたため、
    シンプルに作品タイトルをそのまま抜粋として使う。"""
    plain = re.sub(r'\s+', ' ', title or '').strip()
    if len(plain) > max_len:
        plain = plain[:max_len - 1].rstrip() + '…'
    return plain


_FOCUS_KEYPHRASE_EXCLUDE = {
    'ハイビジョン', '4K', '4k', 'ＨＤ', 'HD',
    '独占配信', '独占', '専売', '単体', '通販', 'DL版',
    '4時間以上作品', 'デジタル限定', '成人向け', '男性向け',
}


def _build_focus_keyphrase(product: dict, max_words: int = 2, max_chars: int = 12) -> str:
    """Yoast SEOの「フォーカスキーフレーズ」用に、出演者名・ジャンル名から
    最大max_words個の単語を選んでスペース区切りの文字列にする。
    Yoastは12文字前後を推奨しているため、文字数がmax_charsを超える場合は
    単語数をさらに削って収める。
    1文字だけの意味のないジャンル名（例:「P」）や、「ハイビジョン」「4K」など
    画質・属性系のキーワードは除外する。
    出演者名（avのみ）を優先的に含め、残り枠をジャンルで埋める。
    出演者名が無い場合（doujin等）はジャンルのみ、それも無ければサークル/メーカー名を使う。"""
    words = []
    if CONTENT_TYPE == 'av' and product.get('actors'):
        for a in product['actors']:
            a = (a or '').strip()
            if a and a not in words:
                words.append(a)
            if len(words) >= max_words:
                break
    for g in (product.get('genres') or []):
        if len(words) >= max_words:
            break
        g = (g or '').strip()
        if g and len(g) > 1 and g not in words and g not in _FOCUS_KEYPHRASE_EXCLUDE:
            words.append(g)
    if not words and product.get('maker'):
        maker = product['maker'].strip()
        if maker:
            words.append(maker)

    # 文字数がmax_charsを超える場合、収まるまで末尾の単語を削る
    while len(words) > 1 and len(' '.join(words)) > max_chars:
        words.pop()

    return ' '.join(words[:max_words])


def _build_seo_title(product: dict, keyphrase: str = '', max_len: int = 32) -> str:
    """検索結果に表示されるSEOタイトルを生成する。
    キーフレーズが既にタイトル内に含まれる場合は重複させない。"""
    title = (product.get('title') or '').strip()
    if not keyphrase:
        return title[:max_len]

    # キーフレーズが既にタイトルの先頭付近に含まれていれば、
    # 単純にタイトルをそのまま使う（重複防止）
    if keyphrase in title:
        return title[:max_len]

    remaining = max_len - len(keyphrase) - 1
    if remaining <= 0:
        return keyphrase[:max_len]
    return f'{keyphrase} {title[:remaining].rstrip()}'


def _sample_video_html(sample_movie_url: str) -> str:
    """サンプル動画の埋め込み。DMM APIからサンプル動画URLが取得できた作品のみ表示される。

    DMM APIの sampleMovieURL は多くの場合、直接再生できる動画ファイル（.mp4等）ではなく、
    litevideo等のプレイヤーページ（HTML）のURLを返す仕様のため、<video src="..."> ではなく
    <iframe> で埋め込む（<video>のままだと再生されない/真っ黒になることがある）。"""
    if not sample_movie_url:
        return ''
    return (
        '<div class="ona-sample-video" style="margin:14px 0;">'
        '<h3 style="margin:0 0 8px;font-size:15px;">サンプル動画</h3>'
        '<div style="position:relative;width:100%;max-width:560px;aspect-ratio:560/360;">'
        f'<iframe src="{escape(sample_movie_url)}" '
        'style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;border-radius:8px;" '
        'allow="autoplay; fullscreen" allowfullscreen loading="lazy"></iframe>'
        '</div>'
        '</div>'
    )


def build_article(product: dict) -> dict:
    focus_keyphrase = _build_focus_keyphrase(product)
    body_content = get_article_body_ai(product, focus_keyphrase)
    seo_title = _build_seo_title(product, keyphrase=focus_keyphrase, max_len=20)
    # メタディスクリプション・抜粋の冒頭にキーフレーズを含める
    # （Yoastの「メタディスクリプション中のキーフレーズ」チェック対策）。
    # 文字数は、Yoastが日本語（全角）を長めにカウントする傾向があるため、
    # 「80文字を超えています」という警告が出ないよう余裕を持たせて55文字までに抑える。
    _base_excerpt = _make_excerpt(product['title'], max_len=55)
    if focus_keyphrase and focus_keyphrase not in product['title']:
        excerpt = _make_excerpt(f'{focus_keyphrase}｜{product["title"]}', max_len=55)
    else:
        excerpt = _base_excerpt
    overview_html = _paragraphs_to_html(body_content['overview'])
    points_html = _points_list_html(body_content['points'])
    genre_badges_html = _genre_badges_html(product.get('genres', []))
    star_html = _star_rating_html(product.get('review_avg'), product.get('review_count'))
    gallery_html = _sample_gallery_html(
        product.get('affiliate_url', ''), product.get('sample_images', []), product.get('title', ''),
        focus_keyphrase
    )
    video_html = _sample_video_html(product.get('sample_movie_url', ''))

    meta_line_parts = []
    if product.get('maker'):
        meta_line_parts.append(f'サークル: {escape(product["maker"])}')
    meta_line_html = ''
    if meta_line_parts:
        meta_line_html = (
            '<div style="color:#666;font-size:13px;margin:4px 0 10px;">'
            + ' ／ '.join(meta_line_parts) + '</div>'
        )

    price_badge_html = ''
    if product.get('price'):
        price_badge_html = (
            '<div style="display:inline-block;background:#fff0f5;color:#e0507a;'
            'border:1px solid #ffc2d6;border-radius:8px;padding:6px 14px;'
            f'font-size:15px;font-weight:bold;margin:10px 0;">価格 {escape(product["price"])}</div>'
        )

    overview_section_html = (
        '<h2 style="margin:14px 0 8px;font-size:17px;">作品の魅力</h2>'
        '<div>'
        f'{overview_html}</div>'
    )

    cta_html = (
        f'<div style="text-align:center;margin:20px 0 8px;">'
        f'<a href="{escape(product["affiliate_url"])}" target="_blank" rel="nofollow sponsored noopener" '
        'style="display:inline-block;padding:14px 36px;background:linear-gradient(135deg,#ff6f91,#e0507a);'
        'color:#fff;text-decoration:none;border-radius:999px;font-size:16px;font-weight:bold;'
        'box-shadow:0 4px 12px rgba(224,80,122,0.35);">'
        '▶ 作品ページを見る</a></div>'
    )

    disclaimer_html = (
        '<p style="color:#999;font-size:12px;line-height:1.6;margin-top:16px;">'
        '※成人向けコンテンツを含みます。18歳未満の方はご利用いただけません。</p>'
    )

    internal_link_html = ''
    if WP_URL:
        cat_label = '同人' if CONTENT_TYPE == 'doujin' else '動画'
        internal_link_html = (
            f'<p style="font-size:13px;margin-top:14px;">'
            f'<a href="{escape(WP_URL)}/category/{cat_label}/">'
            f'他の{cat_label}作品もチェックする →</a></p>'
        )

    card_inner = '\n'.join(
        part for part in [
            overview_section_html,
            meta_line_html,
            genre_badges_html,
            star_html,
            price_badge_html,
            points_html,
            gallery_html,
            video_html,
            cta_html,
            internal_link_html,
            disclaimer_html,
        ] if part
    )

    body_html = (
        '<div style="max-width:600px;margin:0 auto;padding:20px;border:1px solid #eee;'
        'border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,0.06);font-family:'
        '-apple-system,BlinkMacSystemFont,\'Hiragino Sans\',sans-serif;">'
        f'{card_inner}</div>'
    )

    # タグはジャンルのみ（フィルタなしでそのまま使用、検索性重視）。
    # 出演者名は専用タクソノミー（onavi_actress）に登録するため、タグには含めない。
    tag_source = list(product['genres']) if product['genres'] else []
    actor_source = list(product['actors']) if (CONTENT_TYPE == 'av' and product.get('actors')) else []

    # カテゴリーは常に「予約作品」の1つだけを使う（doujin/avの区別はタグ側のジャンルで表現する）。
    display_category_label = '予約作品'

    # 発売日/配信日（YYYY-MM-DD形式）。WordPress側の日付タブ表示で使用する。
    release_date = ''
    _d = _parse_dmm_date(product.get('date', ''))
    if _d:
        release_date = _d.strftime('%Y-%m-%d')

    return {
        'title':             product['title'],
        'slug':              _make_slug(product.get('content_id', ''), product['title']),
        'excerpt':           excerpt,
        'body':              body_html,
        'tags':              tag_source,
        'actors':            actor_source,
        'category_label':    display_category_label,
        'release_date':      release_date,
        'featured_image_url': product.get('package_image', ''),
        'content_id':        product.get('content_id', ''),
        'volume':            product.get('volume', 0),
        'maker':             product.get('maker', ''),
        'focus_keyphrase':   focus_keyphrase,
        'seo_title':         seo_title,
        'affiliate_url':     product.get('affiliate_url', ''),
    }


# ================================================================
# 🔐 WordPress REST API 投稿（アプリケーションパスワード認証・draft固定）
# ================================================================

_category_cache = {}   # name -> id
_tag_cache = {}        # name -> id
_actress_cache = {}    # name -> id（onavi_actress タクソノミー用）


def _wp_auth():
    return (WP_USERNAME, WP_APP_PASSWORD)


_JSON_HEADERS = {
    'Content-Type': 'application/json; charset=utf-8',
    'Accept': 'application/json',
    # レンタルサーバーのbot対策（Imunify360等）は、見慣れない独自User-Agentを
    # 弾くことがあるため、一般的なブラウザのUser-Agentを名乗る。
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
}


def _get_or_create_term(taxonomy: str, name: str, cache: dict):
    """WordPressのカテゴリー/タグを名前で検索し、無ければ作成してIDを返す。"""
    if not name:
        return None
    if name in cache:
        return cache[name]

    endpoint = f'{WP_URL}/wp-json/wp/v2/{taxonomy}'
    try:
        # まず既存を検索
        resp = requests.get(
            endpoint, params={'search': name, 'per_page': 100},
            auth=_wp_auth(), headers=_JSON_HEADERS, timeout=15,
        )
        if resp.status_code == 200:
            try:
                results = resp.json()
            except ValueError:
                results = None
            # 想定外のレスポンス形状（文字列やdictなど）はスキップして作成処理へ進む。
            # search語に完全一致するタームだけを既存として扱う（前方一致等の誤爆を避けるため）。
            if isinstance(results, list):
                for term in results:
                    if isinstance(term, dict) and term.get('name') == name:
                        cache[name] = term['id']
                        return term['id']

        # 無ければ新規作成
        resp = requests.post(
            endpoint, data=json.dumps({'name': name}).encode('utf-8'),
            auth=_wp_auth(), headers=_JSON_HEADERS, timeout=15,
        )
        if resp.status_code in (200, 201):
            try:
                created = resp.json()
            except ValueError:
                created = None
            if isinstance(created, dict) and 'id' in created:
                term_id = created['id']
                cache[name] = term_id
                return term_id
            print(f'    ⚠️ タクソノミー"{name}"の作成レスポンスが想定外の形式です: {resp.text[:200]}')
            return None

        # WordPressは同名タームが既に存在する場合、
        # status 400 + code:"term_exists" + data.term_id を返す仕様。
        # 検索でヒットしなかった（例: 全角/半角違いなど）場合はここで既存IDを拾う。
        try:
            err = resp.json()
        except ValueError:
            err = None
        if isinstance(err, dict) and err.get('code') == 'term_exists':
            existing_id = (err.get('data') or {}).get('term_id')
            if existing_id:
                cache[name] = existing_id
                return existing_id

        print(f'    ⚠️ タクソノミー"{name}"の作成に失敗 status={resp.status_code}: {resp.text[:200]}')
        return None
    except Exception as e:
        print(f'    ⚠️ タクソノミー"{name}"の取得/作成エラー: {e}')
        return None


def _upload_featured_image(image_url: str, content_id: str):
    """パッケージ画像をWordPressメディアライブラリにアップロードし、attachment IDを返す。"""
    if not image_url:
        return None
    try:
        import mimetypes
        img_resp = requests.get(image_url, timeout=20)
        img_resp.raise_for_status()
        content_type = img_resp.headers.get('Content-Type', 'image/jpeg').split(';')[0].strip()
        ext = mimetypes.guess_extension(content_type) or '.jpg'
        # HTTPヘッダーはASCII(latin-1)のみ許容されるため、日本語タイトルではなく
        # content_id（英数字）ベースのファイル名にする
        safe_id = (content_id or 'item').replace(' ', '_')
        filename = f'featured-{safe_id}{ext}'

        resp = requests.post(
            f'{WP_URL}/wp-json/wp/v2/media',
            data=img_resp.content,
            auth=_wp_auth(),
            headers={
                'Content-Type': content_type,
                'Content-Disposition': f'attachment; filename="{filename}"',
                'Accept': 'application/json',
                'User-Agent': _JSON_HEADERS['User-Agent'],
            },
            timeout=30,
        )
        if resp.status_code in (200, 201):
            return resp.json()['id']
        print(f'    ⚠️ アイキャッチ画像のアップロードに失敗 status={resp.status_code}: {resp.text[:200]}')
        return None
    except Exception as e:
        print(f'    ⚠️ アイキャッチ画像の取得/アップロードエラー: {e}')
        return None


def post_draft_to_wordpress(article: dict) -> bool:
    endpoint = f'{WP_URL}/wp-json/wp/v2/posts'

    # カテゴリーは種別ラベル（doujin:「同人」／av:「動画」）の1つだけを登録する。
    # ジャンル・出演者はタグ側に登録する（build_articleで組み立て済みのarticle['tags']を使用）。
    category_label = article.get('category_label') or CONTENT_LABEL
    category_ids = []
    base_category_id = _get_or_create_term('categories', category_label, _category_cache)
    if base_category_id:
        category_ids.append(base_category_id)

    tag_ids = []
    for tag_name in article.get('tags', []):
        if not tag_name or tag_name == category_label:
            continue
        tid = _get_or_create_term('tags', tag_name, _tag_cache)
        if tid and tid not in tag_ids:
            tag_ids.append(tid)

    # 出演者（avのみ）は専用タクソノミー「onavi_actress」に登録する。
    # ※ WordPress側で register_taxonomy() により rest_base='onavi_actress' として
    #   REST APIに公開されている必要がある（未対応の場合はこの項目は無視される）。
    actress_ids = []
    for actor_name in article.get('actors', []):
        if not actor_name:
            continue
        aid = _get_or_create_term('onavi_actress', actor_name, _actress_cache)
        if aid and aid not in actress_ids:
            actress_ids.append(aid)

    payload = {
        'title':      article['title'],
        'slug':       article.get('slug') or '',
        'excerpt':    article.get('excerpt') or '',
        'content':    article['body'],
        'status':     WP_POST_STATUS,   # 'draft' / 'pending' / 'publish'（WP_POST_STATUSの設定に従う）
        'categories': category_ids,
        'tags':       tag_ids,
    }
    if actress_ids:
        payload['onavi_actress'] = actress_ids

    # Yoast SEOの「フォーカスキーフレーズ」「SEOタイトル」「メタディスクリプション」を
    # 投稿と同時に設定する。
    # ※ WordPress側で '_yoast_wpseo_focuskw' / '_yoast_wpseo_title' / '_yoast_wpseo_metadesc'
    #   メタフィールドが register_post_meta() 等でREST APIに公開されている必要がある。
    meta = {}
    focus_keyphrase = article.get('focus_keyphrase') or ''
    if focus_keyphrase:
        meta['_yoast_wpseo_focuskw'] = focus_keyphrase
    seo_title = article.get('seo_title') or ''
    if seo_title:
        meta['_yoast_wpseo_title'] = seo_title
    metadesc = article.get('excerpt') or ''
    if metadesc:
        meta['_yoast_wpseo_metadesc'] = metadesc
    # デプロイ確認用: この投稿がどのバージョンのスクリプトで生成されたかを記録する
    meta['_onavi_script_version'] = SCRIPT_VERSION

    # 記事一覧のアイキャッチ画像から直接アフィリエイトリンクへ飛ばせるように、
    # アフィリエイトURLをカスタムフィールドとしても保存しておく。
    # ※ WordPress側で '_onavi_affiliate_url' を register_post_meta() 等で
    #   REST APIに公開しておく必要がある（下記functions.php例を参照）。
    if article.get('affiliate_url'):
        meta['_onavi_affiliate_url'] = article['affiliate_url']

    # 新デザインのカード表示用（再生時間・品番・メーカー）。
    # WordPress側で register_post_meta() 済み（otona-navi-redesign.php の「N」節）。
    if article.get('volume'):
        meta['_onavi_volume'] = str(article['volume'])
    if article.get('content_id'):
        meta['_onavi_content_id'] = str(article['content_id'])
    if article.get('maker'):
        meta['_onavi_maker'] = str(article['maker'])

    # 発売日/配信日（YYYY-MM-DD）。WordPress側の予約作品ページで
    # 日付タブごとに記事をグループ化する際のキーとして使用する。
    # ※ WordPress側で '_onavi_release_date' を register_post_meta() 等で
    #   REST APIに公開しておく必要がある。
    if article.get('release_date'):
        meta['_onavi_release_date'] = article['release_date']

    if meta:
        payload['meta'] = meta

    # アイキャッチ画像（featured_media）を設定する。
    # 本文側からは同じ画像を削除したので、重複表示にはならない。
    media_id = _upload_featured_image(article.get('featured_image_url', ''), article.get('content_id', ''))
    if media_id:
        payload['featured_media'] = media_id

    try:
        resp = requests.post(
            endpoint, data=json.dumps(payload).encode('utf-8'),
            auth=_wp_auth(), headers=_JSON_HEADERS, timeout=20,
        )

        # --- 診断ログ（原因切り分け用） -------------------------------
        # ・resp.history に何か入っていれば、途中でリダイレクトが発生している
        #   （POSTがGETに化ける典型パターン）。
        # ・resp.url がendpointと異なれば、リダイレクト先URLが分かる。
        # ・Cache関連ヘッダーがあれば、プロキシ/CDN層のキャッシュが疑われる。
        if resp.history:
            redirect_chain = ' -> '.join(r.url for r in resp.history) + f' -> {resp.url}'
            print(f"    🔎 リダイレクトが発生しています: {redirect_chain}")
        if resp.url != endpoint:
            print(f"    🔎 最終アクセスURLがendpointと異なります: endpoint={endpoint} / 実際={resp.url}")
        cache_headers = {
            k: v for k, v in resp.headers.items()
            if k.lower() in (
                'x-cache', 'x-cache-status', 'age', 'cf-cache-status',
                'x-litespeed-cache', 'x-proxy-cache', 'server', 'via',
            )
        }
        if cache_headers:
            print(f"    🔎 キャッシュ/プロキシ関連ヘッダー: {cache_headers}")
        print(f"    🔎 HTTPステータス: {resp.status_code}")
        # ---------------------------------------------------------------

        if resp.status_code in (200, 201):
            try:
                result = resp.json()
            except ValueError:
                result = None
            # レンタルサーバーのbot対策（Imunify360等）にブロックされた場合、
            # HTTPステータスは200/201でも本文が {"message": "..."} のような
            # エラーメッセージだけのことがある。実際に投稿されたことを保証するため、
            # 本物のWordPress投稿レスポンス（'id'キーを持つdict）かどうかを確認する。
            if not isinstance(result, dict) or 'id' not in result:
                print(f"    ❌ 投稿失敗：WordPressから投稿データが返りませんでした"
                      f"（サーバー側のbot対策等でブロックされた可能性があります）: {resp.text[:300]}")
                return False
            actual_status = result.get('status')
            # WordPressから返ってきたステータスが、こちらが指定したWP_POST_STATUSと
            # 一致しているかどうかだけを確認する（想定外の値が返った場合のみ警告）。
            if actual_status != WP_POST_STATUS:
                print(f"    ⚠️ 指定したステータス（{WP_POST_STATUS}）と異なる値が返りました"
                      f"（status={actual_status}）。念のため内容をご確認ください: {result.get('link', '')}")
            print(f"    ✅ {actual_status}として投稿成功: {article['title'][:40]}")
            if actual_status == 'publish':
                submit_url(WP_URL, result.get('link', ''))
            return True
        else:
            print(f"    ❌ 投稿失敗 status={resp.status_code}: {resp.text[:300]}")
            return False
    except Exception as e:
        print(f"    ❌ 投稿エラー: {e}")
        return False


# ================================================================
# 🚀 メイン実行
# ================================================================

def _parse_dmm_date(date_str):
    """DMMの date フィールド（例: 'YYYY-MM-DD HH:MM:SS'）をdatetimeに変換する。
    パースできない・空の場合はNoneを返す。"""
    if not date_str:
        return None
    date_str = date_str.strip()
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
        try:
            return datetime.datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None


def main():
    posted_history = load_posted_history()
    print(f'📚 投稿済み履歴: {len(posted_history)}件')

    now_jst = datetime.datetime.now(JST)
    today = now_jst.date()
    window_end = today + datetime.timedelta(days=RESERVE_WINDOW_DAYS)
    # 比較用に、実行時刻（JST）をtzなしdatetimeにしておく（DMMのdateフィールドはtz情報を持たないため）
    now_naive = now_jst.replace(tzinfo=None)
    # DMM API側で発売日/配信日の範囲を絞り込み、「今より未来」〜「RESERVE_WINDOW_DAYS日後まで」の
    # 予約作品のみを取得対象にする（発売済み・遠い未来すぎる作品は最初から除外）。
    gte_date_str = now_naive.strftime('%Y-%m-%dT%H:%M:%S')
    lte_date_str = datetime.datetime.combine(window_end, datetime.time.max).strftime('%Y-%m-%dT%H:%M:%S')
    print(f'\n📅 {_SORT_LABEL}（sort={DMM_SORT_MODE}）で上位{RANK_FETCH_LIMIT}件を取得します...'
          f'（DMM APIへ日付範囲指定: {gte_date_str} 〜 {lte_date_str}）')
    raw_items = fetch_rank_items(RANK_FETCH_LIMIT, sort=DMM_SORT_MODE,
                                  gte_date=gte_date_str, lte_date=lte_date_str)
    print(f'📅 {len(raw_items)}件を取得しました。'
          f'（対象期間: 実行日時（{now_naive}）より未来 〜 {window_end} の発売日/配信日のみ投稿対象）')

    # 発売日が近い順（昇順）に並べ替える。直近の予約作品から優先的に記事化するため。
    raw_items_with_date = []
    for item in raw_items:
        d = _parse_dmm_date(item.get('date', ''))
        raw_items_with_date.append((d or datetime.datetime.max, item))
    raw_items_with_date.sort(key=lambda x: x[0])
    raw_items = [item for _, item in raw_items_with_date]

    safe_products = []
    seen_in_run = set()
    all_skipped = []
    out_of_window_skipped = []
    dup_skipped = 0

    for item in raw_items:
        if len(safe_products) >= MAX_ARTICLES:
            break

        product = parse_product(item)
        key = product_history_key(product)

        # 【重複防止】過去に投稿済みの作品、および今回の実行内で既に選ばれた作品はスキップする
        if key in posted_history or key in seen_in_run:
            dup_skipped += 1
            continue

        ok, matched = is_safe(product)
        if not ok:
            all_skipped.append((product, matched))
            continue

        # 発売日/配信日が「実行日時（now）より未来」かつ「今日から未来RESERVE_WINDOW_DAYS日以内」の
        # 予約作品のみを対象にする。
        # ・実行日時より過去（＝すでに発売済み）は自動的に対象外になる
        # ・window_endより先の作品も対象外になる
        product_date = _parse_dmm_date(product.get('date', ''))
        if (
            product_date is None
            or product_date <= now_naive
            or product_date.date() > window_end
        ):
            out_of_window_skipped.append(product)
            continue

        price_num = product.get('price_num')
        if PRICE_MIN is not None and (price_num is None or price_num < PRICE_MIN):
            continue
        if PRICE_MAX is not None and (price_num is None or price_num > PRICE_MAX):
            continue

        if CONTENT_TYPE == 'av' and EXCLUDE_VR and _is_vr_product(product):
            continue

        seen_in_run.add(key)
        safe_products.append(product)

    print(f'\n📊 検索結果: {len(safe_products)}/{MAX_ARTICLES}件 集まりました '
          f'（安全フィルター除外 {len(all_skipped)}件・対象期間外のため除外 {len(out_of_window_skipped)}件・'
          f'投稿済み重複のため除外 {dup_skipped}件）')

    if out_of_window_skipped:
        print(f'   📅 対象期間（{today}〜{window_end}）外のためスキップ（例）:')
        for p in out_of_window_skipped[:10]:
            print(f"      - {p['title'][:40]}（発売日/配信日: {p.get('date')}）")
        if len(out_of_window_skipped) > 10:
            print(f'      …他{len(out_of_window_skipped) - 10}件')

    if all_skipped:
        Path('outputs').mkdir(exist_ok=True)
        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        skip_path = Path('outputs') / f'skipped_{ts}.txt'
        with open(skip_path, 'w', encoding='utf-8') as f:
            f.write('# 年少者連想ワードにより除外された作品一覧\n\n')
            for p, matched in all_skipped:
                f.write(f"- {p['title']}\n  マッチ語: {', '.join(matched)}\n")
        print(f'📄 除外ログ: {skip_path}')

    if not safe_products:
        print('⚠️ 投稿対象の作品がありませんでした（フィルター/重複除外で全件除外、または対象期間内に該当作品なし）。')
        sys.exit(0)

    if len(safe_products) < MAX_ARTICLES:
        print(f'⚠️ {_SORT_LABEL}上位{RANK_FETCH_LIMIT}件・対象期間{DATE_WINDOW_DAYS}日以内の中では'
              f'{MAX_ARTICLES}件に届きませんでした。集まった{len(safe_products)}件のみ投稿します。')

    posted = 0
    for p in safe_products:
        print(f"\n📝 記事生成中: {p['title'][:40]}（発売日/配信日: {p.get('date') or '不明'}）")
        article = build_article(p)
        if post_draft_to_wordpress(article):
            posted += 1
            posted_history.add(product_history_key(p))
            save_posted_history(posted_history)

    print(f'\n✅ 完了！{posted}/{len(safe_products)} 件をWordPressに{WP_POST_STATUS}として投稿しました。')
    print(f'   📚 累計投稿履歴: {len(posted_history)}件（{POSTED_HISTORY_FILE}）')
    print('   ※ 公開前に必ず内容をご確認ください。')


if __name__ == '__main__':
    main()
