# -*- coding: utf-8 -*-
"""
作品の「実データ」（公式の紹介文）を各ソースのレスポンスから取り出す共通モジュール。

目的:
  AIに記事を書かせるとき、タイトル・ジャンルだけを渡すと、AIは内容を想像で
  補ってしまう（存在しない設定・展開の描写＝捏造）。これはGoogleから見ても
  「商品データを言い換えただけの量産記事」になりやすい。
  そこで、APIやページが公式に提供している紹介文があれば取り出し、記事の
  唯一の根拠として使う。無ければ空文字を返し、呼び出し側が「内容は書かない」
  モードに切り替える。

環境変数:
  SUMMARY_DEBUG=1  各ソースの先頭数件で、どのキーが取れたか／紹介文が取れたかをログに出す
                   （初回実行時に、実際のAPIレスポンスの項目名を確認するために使う）
"""
import html
import os
import re
from typing import Any, Iterable

MIN_SUMMARY_CHARS = 40     # これ未満は「紹介文」と見なさない（キャッチコピー程度の文字列を除外）
MAX_SUMMARY_CHARS = 700    # プロンプトに渡す上限（長すぎる場合は切る）

# APIごとに紹介文の項目名が違うため、候補を広めに持つ（先に見つかったものを採用）。
SUMMARY_KEYS = (
    'caption', 'comment', 'description', 'summary', 'story',
    'introduction', 'intro', 'explain', 'synopsis', 'memo',
)

_TAG_RE = re.compile(r'<[^>]+>')
_WS_RE = re.compile(r'\s+')

# サイト共通の定型文（作品固有ではない説明）を紹介文として拾わないための除外語。
_BOILERPLATE_HINTS = (
    '会員登録', 'ダウンロード販売', 'ご利用ガイド', 'MGS動画（', 'の通販・購入はこちら',
    '動画配信サイト', '無料サンプル動画',
)


def clean_summary(raw: Any) -> str:
    """HTMLタグ・空白を除去し、長さを整えた紹介文を返す。紹介文として不十分なら空文字。"""
    if raw is None:
        return ''
    if isinstance(raw, dict):
        for k in ('text', 'value', 'content', 'body'):
            if raw.get(k):
                return clean_summary(raw[k])
        return ''
    if isinstance(raw, (list, tuple)):
        return clean_summary('\n'.join(str(x) for x in raw if x))
    text = html.unescape(_TAG_RE.sub('', str(raw)))
    text = _WS_RE.sub(' ', text).strip()
    if len(text) < MIN_SUMMARY_CHARS:
        return ''
    if any(h in text for h in _BOILERPLATE_HINTS) and len(text) < 120:
        return ''
    if len(text) > MAX_SUMMARY_CHARS:
        text = text[:MAX_SUMMARY_CHARS].rstrip() + '…'
    return text


def pick_summary(item: dict, keys: Iterable[str] = SUMMARY_KEYS) -> str:
    """item（APIの1件分）から紹介文を取り出す。見つからなければ空文字。"""
    if not isinstance(item, dict):
        return ''
    for key in keys:
        if key in item:
            cleaned = clean_summary(item.get(key))
            if cleaned:
                return cleaned
    return ''


_debug_count = 0


def debug_log(source: str, item: Any, summary: str, limit: int = 3) -> None:
    """SUMMARY_DEBUG=1 のとき、先頭数件だけ項目名と紹介文の取得結果を出力する。"""
    global _debug_count
    if os.environ.get('SUMMARY_DEBUG', '').strip() not in ('1', 'true'):
        return
    if _debug_count >= limit:
        return
    _debug_count += 1
    keys = sorted(item.keys()) if isinstance(item, dict) else []
    print(f'    🔎 [SUMMARY_DEBUG:{source}] item keys = {keys}')
    print(f'    🔎 [SUMMARY_DEBUG:{source}] 紹介文: '
          f'{(summary[:80] + "…") if summary else "（取得できず）"}')
